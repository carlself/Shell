﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IGUID
	{
		string GUID
		{
			get;
			set;
		}
	}
}
