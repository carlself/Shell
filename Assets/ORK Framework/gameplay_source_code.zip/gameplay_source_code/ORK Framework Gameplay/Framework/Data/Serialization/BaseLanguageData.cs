
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BaseLanguageData : BaseIndexData, IContentSimple
	{
		[ORKEditorInfo("Content Information", "Set the name, description and icon.", "", endFoldout=true, hide=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageContent[] languageInfo;

		public BaseLanguageData()
		{
			this.SetLanguageName("Default");
		}

		public BaseLanguageData(string name)
		{
			this.SetLanguageName(name);
		}

		public void SetLanguageName(string name)
		{
			this.languageInfo = new LanguageContent[ORK.Languages.Count];
			for(int i = 0; i < this.languageInfo.Length; i++)
			{
				this.languageInfo[i] = new LanguageContent(name);
			}
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public virtual int ID
		{
			get { return this.realID; }
		}

		public virtual string GetName()
		{
			return this.languageInfo[ORK.Game.Language].GetName();
		}

		public virtual string GetShortName()
		{
			return this.languageInfo[ORK.Game.Language].GetShortName();
		}

		public virtual string GetDescription()
		{
			return this.languageInfo[ORK.Game.Language].GetDescription();
		}

		public virtual string GetIconTextCode()
		{
			return "";
		}

		public virtual Texture GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public virtual GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}
	}
}
