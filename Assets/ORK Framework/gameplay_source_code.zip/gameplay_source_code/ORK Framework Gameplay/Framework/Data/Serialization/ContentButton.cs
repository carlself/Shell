﻿
using UnityEngine;
using ORKFramework.UI;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ContentButton : BaseData
	{
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public TextImageDescriptionContent[] button = ArrayHelper.CreateArray<TextImageDescriptionContent>(ORK.Languages.Count);

		[ORKEditorInfo(separator=true)]
		public PlaceCustomChoiceSkin customSkin = new PlaceCustomChoiceSkin();

		public ContentButton()
		{

		}

		public ContentButton(string name)
		{
			for(int i = 0; i < this.button.Length; i++)
			{
				this.button[i].name = name;
			}
		}

		public void DataUpgrade(DataObject[] data)
		{
			if(data != null)
			{
				for(int i = 0; i < data.Length; i++)
				{
					if(i < this.button.Length)
					{
						this.button[i].SetData(data[i]);
					}
				}
			}
		}

		public ChoiceContent GetChoiceContent()
		{
			ChoiceContent content = new ChoiceContent(this.button[ORK.Game.Language].GetContent());
			this.customSkin.SetSkin(content);
			return content;
		}
	}
}
