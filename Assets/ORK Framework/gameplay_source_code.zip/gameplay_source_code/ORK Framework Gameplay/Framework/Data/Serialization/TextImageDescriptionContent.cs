
using UnityEngine;

namespace ORKFramework
{
	public class TextImageDescriptionContent : BaseData
	{
		[ORKEditorHelp("Name", "Define the name.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";

		[ORKEditorHelp("Description", "Define the description.", "")]
		[ORKEditorInfo(isTextArea=true, callbackBefore="textcodes:description")]
		public string description = "";

		[ORKEditorHelp("Icon", "Select the icon.", "")]
		public AssetSource<Texture> icon = new AssetSource<Texture>();

		public TextImageDescriptionContent()
		{

		}

		public TextImageDescriptionContent(string n)
		{
			this.name = n;
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.icon.Upgrade(data, "icon");
		}

		public string GetName()
		{
			return this.name;
		}

		public string GetDescription()
		{
			return this.description;
		}

		public Texture GetIcon()
		{
			return this.icon;
		}

		public GUIContent GetContent()
		{
			return new GUIContent(this.name, this.icon);
		}
	}
}
