﻿
using UnityEngine;

namespace ORKFramework
{
	public class LanguageContent : BaseData
	{
		[ORKEditorHelp("Name", "Define the name.", "")]
		[ORKEditorInfo(expandWidth=true, callbackBefore="textcodes:name")]
		public string name = "";

		[ORKEditorHelp("Short Name", "Define the short name.\n" +
			"The name is used if no short name is defined.", "")]
		[ORKEditorInfo(expandWidth=true, callbackBefore="textcodes:name")]
		public string shortName = "";

		[ORKEditorHelp("Description", "Define the description.", "")]
		[ORKEditorInfo(isTextArea=true, callbackBefore="textcodes:description")]
		public string description = "";

		[ORKEditorHelp("Icon", "Select the icon.", "")]
		public AssetSource<Texture> icon = new AssetSource<Texture>();

		public LanguageContent()
		{

		}

		public LanguageContent(string n)
		{
			this.name = n;
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.icon.Upgrade(data, "icon");
		}

		public string GetName()
		{
			return this.name;
		}

		public string GetShortName()
		{
			return this.shortName == "" ? this.name : this.shortName;
		}

		public string GetDescription()
		{
			return this.description;
		}

		public Texture GetIcon()
		{
			return this.icon;
		}

		public GUIContent GetContent()
		{
			return new GUIContent(this.name, this.icon);
		}
	}
}
