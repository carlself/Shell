
using UnityEngine;
using System.Collections.Generic;
using System.Reflection;

namespace ORKFramework.Reflection
{
	public class ChangeField : BaseData
	{
		[ORKEditorHelp("Field Name", "The name of the field that will be changed.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string fieldName = "";

		[ORKEditorHelp("Is Property", "Change the value of a property.\n" +
			"If disabled, the value of a field will be changed.", "")]
		public bool isProperty = false;

		[ORKEditorHelp("Is Array", "The field/property is an array.\n" +
			"A defined index of the array is used.", "")]
		public bool isArray = false;

		[ORKEditorHelp("Increase Size", "Increase the array's size if the array index exceed's the current size.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("isArray", true)]
		public bool increaseArraySize = false;

		[ORKEditorInfo(labelText="Array Index")]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public FloatValue arrayIndex;


		// field type
		[ORKEditorHelp("Field Type", "Select the type of the field.", "")]
		[ORKEditorInfo(separator=true)]
		public ParameterType type = ParameterType.String;

		[ORKEditorInfo(separator=true, labelText="String Value", expandWidth=true)]
		[ORKEditorLayout("type", ParameterType.String, endCheckGroup=true)]
		public StringValue stringValue = new StringValue();

		[ORKEditorHelp("Bool Value", "Define the bool the field will be set to.", "")]
		[ORKEditorLayout("type", ParameterType.Bool, endCheckGroup=true)]
		public bool boolValue = false;

		[ORKEditorInfo(separator=true, labelText="Int/Float Value")]
		[ORKEditorLayout(new string[] { "type", "type" },
			new object[] { ParameterType.Int, ParameterType.Float },
			needed=Needed.One, endCheckGroup=true)]
		public FloatValue floatValue = new FloatValue();

		[ORKEditorInfo(separator=true, labelText="Vector Value")]
		[ORKEditorLayout(new string[] { "type", "type" },
			new object[] { ParameterType.Vector2, ParameterType.Vector3 },
			needed=Needed.One, endCheckGroup=true)]
		public Vector3Value vectorValue = new Vector3Value();

		public ChangeField()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<string>("stringValue"))
			{
				if(ParameterType.String == this.type)
				{
					data.Get("stringValue", ref this.stringValue.value);
				}
				else if(ParameterType.Int == this.type)
				{
					int tmp = 0;
					data.Get("intValue", ref tmp);
					this.floatValue.value = tmp;
				}
				else if(ParameterType.Float == this.type)
				{
					data.Get("floatValue", ref this.floatValue.value);
				}
				else if(ParameterType.Vector2 == this.type)
				{
					float[] tmp;
					data.Get("vector2Value", out tmp);
					if(tmp != null)
					{
						this.vectorValue.value = ArrayHelper.GetVector2(tmp);
					}
				}
				else if(ParameterType.Vector3 == this.type)
				{
					float[] tmp;
					data.Get("vector3Value", out tmp);
					if(tmp != null)
					{
						this.vectorValue.value = ArrayHelper.GetVector3(tmp);
					}
				}
			}
		}

		public System.Object GetValue()
		{
			if(ParameterType.String == this.type)
			{
				return this.stringValue.GetValue();
			}
			else if(ParameterType.Bool == this.type)
			{
				return this.boolValue;
			}
			else if(ParameterType.Int == this.type)
			{
				return (int)this.floatValue.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader);
			}
			else if(ParameterType.Float == this.type)
			{
				return this.floatValue.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader); ;
			}
			else if(ParameterType.Vector2 == this.type)
			{
				return (Vector2)this.vectorValue.GetValue();
			}
			else if(ParameterType.Vector3 == this.type)
			{
				return this.vectorValue.GetValue();
			}
			return null;
		}

		private bool SetArrayValue(ref object value)
		{
			bool changed = false;
			System.Array array = value as System.Array;
			if(array != null)
			{
				int index = (int)this.arrayIndex.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader);
				if(this.increaseArraySize &&
					array.Length <= index)
				{
					changed = true;
					System.Type elementType = array.GetType().GetElementType();
					System.Array tmp = System.Array.CreateInstance(elementType, index + 1);
					System.Array.Copy(array, tmp, array.Length);
					for(int i = array.Length; i < tmp.Length; i++)
					{
						tmp.SetValue(ReflectionTypeHandler.Instance.CreateInstance(elementType), i);
					}
					tmp.SetValue(this.GetValue(), index);
					value = System.Convert.ChangeType(tmp, array.GetType());
				}
				else
				{
					array.SetValue(this.GetValue(), index);
				}
			}
			else
			{
				System.Collections.IList list = value as System.Collections.IList;
				if(list != null)
				{
					int index = (int)this.arrayIndex.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader);
					if(this.increaseArraySize &&
						list.Count <= index)
					{
						System.Type elementType = list.GetType().IsGenericType ?
							list.GetType().GetGenericArguments()[0] :
							list.GetType().GetElementType();
						if(elementType != null)
						{
							for(int i = list.Count; i <= index; i++)
							{
								list.Add(ReflectionTypeHandler.Instance.CreateInstance(elementType));
							}
						}
					}
					list[index] = this.GetValue();
				}
			}
			return changed;
		}

		public void Change(System.Object instance, System.Type instanceType)
		{
			if(this.fieldName != "")
			{
				if(this.isProperty)
				{
					PropertyInfo propertyInfo = instanceType.GetProperty(this.fieldName,
						BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
					if(propertyInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								object value = propertyInfo.GetValue(instance, null);
								if(this.SetArrayValue(ref value))
								{
									propertyInfo.SetValue(instance, value, null);
								}
							}
							else
							{
								propertyInfo.SetValue(instance, this.GetValue(), null);
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Property change failed (" + instanceType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
					}
				}
				else
				{
					FieldInfo fieldInfo = instanceType.GetField(this.fieldName,
						BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
					if(fieldInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								object value = fieldInfo.GetValue(instance);
								if(this.SetArrayValue(ref value))
								{
									fieldInfo.SetValue(instance, value);
								}
							}
							else
							{
								fieldInfo.SetValue(instance, this.GetValue());
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Field change failed (" + instanceType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
					}
				}
			}
		}

		public void ChangeStatic(System.Type classType)
		{
			if(classType != null && this.fieldName != "")
			{
				if(this.isProperty)
				{
					PropertyInfo propertyInfo = classType.GetProperty(this.fieldName,
						BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
					if(propertyInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								object value = propertyInfo.GetValue(null, null);
								if(this.SetArrayValue(ref value))
								{
									propertyInfo.SetValue(null, value, null);
								}
							}
							else
							{
								propertyInfo.SetValue(null, this.GetValue(), null);
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Property change failed (" + classType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Property not found (" + classType + "): " + this.fieldName);
					}
				}
				else
				{
					FieldInfo fieldInfo = classType.GetField(this.fieldName,
						BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
					if(fieldInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								object value = fieldInfo.GetValue(null);
								if(this.SetArrayValue(ref value))
								{
									fieldInfo.SetValue(null, value);
								}
							}
							else
							{
								fieldInfo.SetValue(null, this.GetValue());
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Field change failed (" + classType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Field not found (" + classType + "): " + this.fieldName);
					}
				}
			}
		}
	}
}
