
using UnityEngine;
using ORKFramework.Events;
using System.Collections.Generic;
using System.Reflection;

namespace ORKFramework.Reflection
{
	public class EventCheckField : BaseData
	{
		[ORKEditorHelp("Field Name", "The name of the field that will be checked.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string fieldName = "";

		[ORKEditorHelp("Is Property", "Check the value of a property.\n" +
			"If disabled, the value of a field will be checked.", "")]
		public bool isProperty = false;

		[ORKEditorHelp("Is Array", "The field/property is an array.\n" +
			"A defined index of the array is used.", "")]
		public bool isArray = false;

		[ORKEditorInfo(labelText="Array Index")]
		[ORKEditorLayout("isArray", true, endCheckGroup=true, autoInit=true)]
		public EventInteger arrayIndex;


		// field type
		[ORKEditorHelp("Field Type", "Select the type of the field.", "")]
		[ORKEditorInfo(separator=true)]
		public ParameterType type = ParameterType.String;

		[ORKEditorInfo(separator=true, labelText="String Value", expandWidth=true)]
		[ORKEditorLayout("type", ParameterType.String, endCheckGroup=true)]
		public EventString stringValue = new EventString();

		[ORKEditorHelp("Bool Value", "Define the bool the field will be set to.", "")]
		[ORKEditorLayout("type", ParameterType.Bool, endCheckGroup=true)]
		public bool boolValue = false;

		[ORKEditorInfo(separator=true, labelText="Int Value")]
		[ORKEditorLayout("type", ParameterType.Int, endCheckGroup=true)]
		public EventInteger intValue = new EventInteger();

		[ORKEditorInfo(separator=true, labelText="Float Value")]
		[ORKEditorLayout("type", ParameterType.Float, endCheckGroup=true)]
		public EventFloat floatValue = new EventFloat();

		[ORKEditorInfo(separator=true, labelText="Vector Value")]
		[ORKEditorLayout(new string[] { "type", "type" },
			new object[] { ParameterType.Vector2, ParameterType.Vector3 },
			needed=Needed.One, endCheckGroup=true)]
		public EventVector3 vectorValue = new EventVector3();

		public EventCheckField()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<string>("stringValue"))
			{
				if(ParameterType.String == this.type)
				{
					data.Get("stringValue", ref this.stringValue.value);
				}
				else if(ParameterType.Int == this.type)
				{
					data.Get("intValue", ref this.intValue.value);
				}
				else if(ParameterType.Float == this.type)
				{
					data.Get("floatValue", ref this.floatValue.value);
				}
				else if(ParameterType.Vector2 == this.type)
				{
					float[] tmp;
					data.Get("vector2Value", out tmp);
					if(tmp != null)
					{
						this.vectorValue.value = ArrayHelper.GetVector2(tmp);
					}
				}
				else if(ParameterType.Vector3 == this.type)
				{
					float[] tmp;
					data.Get("vector3Value", out tmp);
					if(tmp != null)
					{
						this.vectorValue.value = ArrayHelper.GetVector3(tmp);
					}
				}
			}
		}

		public object GetValue(BaseEvent baseEvent)
		{
			if(ParameterType.String == this.type)
			{
				return this.stringValue.GetValue(baseEvent);
			}
			else if(ParameterType.Bool == this.type)
			{
				return this.boolValue;
			}
			else if(ParameterType.Int == this.type)
			{
				return this.intValue.GetValue(baseEvent);
			}
			else if(ParameterType.Float == this.type)
			{
				return this.floatValue.GetValue(baseEvent); ;
			}
			else if(ParameterType.Vector2 == this.type)
			{
				return this.vectorValue.GetValue(baseEvent);
			}
			else if(ParameterType.Vector3 == this.type)
			{
				return this.vectorValue.GetValue(baseEvent);
			}
			return null;
		}

		private bool CheckArrayValue(BaseEvent baseEvent, object value)
		{
			System.Array array = value as System.Array;
			if(array != null)
			{
				object checkValue = array.GetValue(this.arrayIndex.GetValue(baseEvent));
				return checkValue != null && checkValue.Equals(this.GetValue(baseEvent));
			}
			else
			{
				System.Collections.IList list = value as System.Collections.IList;
				if(list != null)
				{
					object checkValue = list[this.arrayIndex.GetValue(baseEvent)];
					return checkValue != null && checkValue.Equals(this.GetValue(baseEvent));
				}
			}
			return false;
		}

		public bool Check(object instance, System.Type instanceType, BaseEvent baseEvent)
		{
			if(this.fieldName != "")
			{
				if(this.isProperty)
				{
					PropertyInfo propertyInfo = instanceType.GetProperty(this.fieldName,
						BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
					if(propertyInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								return this.CheckArrayValue(baseEvent, propertyInfo.GetValue(instance, null));
							}
							else
							{
								object value = propertyInfo.GetValue(instance, null);
								return value != null && value.Equals(this.GetValue(baseEvent));
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Property change failed (" + instanceType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
					}
				}
				else
				{
					FieldInfo fieldInfo = instanceType.GetField(this.fieldName,
						BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
					if(fieldInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								return this.CheckArrayValue(baseEvent, fieldInfo.GetValue(instance));
							}
							else
							{
								object value = fieldInfo.GetValue(instance);
								return value != null && value.Equals(this.GetValue(baseEvent));
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Field change failed (" + instanceType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
					}
				}
			}
			return false;
		}

		public bool CheckStatic(System.Type classType, BaseEvent baseEvent)
		{
			if(classType != null && this.fieldName != "")
			{
				if(this.isProperty)
				{
					PropertyInfo propertyInfo = classType.GetProperty(this.fieldName,
						BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
					if(propertyInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								return this.CheckArrayValue(baseEvent, propertyInfo.GetValue(null, null));
							}
							else
							{
								object value = propertyInfo.GetValue(null, null);
								return value != null && value.Equals(this.GetValue(baseEvent));
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Property change failed (" + classType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Property not found (" + classType + "): " + this.fieldName);
					}
				}
				else
				{
					FieldInfo fieldInfo = classType.GetField(this.fieldName,
						BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
					if(fieldInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								return this.CheckArrayValue(baseEvent, fieldInfo.GetValue(null));
							}
							else
							{
								object value = fieldInfo.GetValue(null);
								return value != null && value.Equals(this.GetValue(baseEvent));
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Field change failed (" + classType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Field not found (" + classType + "): " + this.fieldName);
					}
				}
			}
			return false;
		}
	}
}
