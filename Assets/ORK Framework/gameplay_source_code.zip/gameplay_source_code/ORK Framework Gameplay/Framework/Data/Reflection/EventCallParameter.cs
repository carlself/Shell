﻿
using UnityEngine;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Reflection
{
	public class EventCallParameter : BaseData
	{
		[ORKEditorHelp("Parameter Type", "Select the type of the parameter value.", "")]
		public ParameterType type = ParameterType.String;

		[ORKEditorInfo(separator=true, labelText="String Value", expandWidth=true)]
		[ORKEditorLayout("type", ParameterType.String, endCheckGroup=true)]
		public EventString stringValue = new EventString();

		[ORKEditorHelp("Bool Value", "Define the bool the field will be set to.", "")]
		[ORKEditorLayout("type", ParameterType.Bool, endCheckGroup=true)]
		public bool boolValue = false;

		[ORKEditorInfo(separator=true, labelText="Int Value")]
		[ORKEditorLayout("type", ParameterType.Int, endCheckGroup=true)]
		public EventInteger intValue = new EventInteger();

		[ORKEditorInfo(separator=true, labelText="Float Value")]
		[ORKEditorLayout("type", ParameterType.Float, endCheckGroup=true)]
		public EventFloat floatValue = new EventFloat();

		[ORKEditorInfo(separator=true, labelText="Vector Value")]
		[ORKEditorLayout(new string[] { "type", "type" },
			new object[] { ParameterType.Vector2, ParameterType.Vector3 },
			needed=Needed.One, endCheckGroup=true)]
		public EventVector3 vectorValue = new EventVector3();

		public EventCallParameter()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<string>("stringValue"))
			{
				if(ParameterType.String == this.type)
				{
					data.Get("stringValue", ref this.stringValue.value);
				}
				else if(ParameterType.Int == this.type)
				{
					data.Get("intValue", ref this.intValue.value);
				}
				else if(ParameterType.Float == this.type)
				{
					data.Get("floatValue", ref this.floatValue.value);
				}
				else if(ParameterType.Vector2 == this.type)
				{
					float[] tmp;
					data.Get("vector2Value", out tmp);
					if(tmp != null)
					{
						this.vectorValue.value = ArrayHelper.GetVector2(tmp);
					}
				}
				else if(ParameterType.Vector3 == this.type)
				{
					float[] tmp;
					data.Get("vector3Value", out tmp);
					if(tmp != null)
					{
						this.vectorValue.value = ArrayHelper.GetVector3(tmp);
					}
				}
			}
		}

		public object GetValue(BaseEvent baseEvent)
		{
			if(ParameterType.String == this.type)
			{
				return this.stringValue.GetValue(baseEvent);
			}
			else if(ParameterType.Bool == this.type)
			{
				return this.boolValue;
			}
			else if(ParameterType.Int == this.type)
			{
				return this.intValue.GetValue(baseEvent);
			}
			else if(ParameterType.Float == this.type)
			{
				return this.floatValue.GetValue(baseEvent); ;
			}
			else if(ParameterType.Vector2 == this.type)
			{
				return (Vector2)this.vectorValue.GetValue(baseEvent);
			}
			else if(ParameterType.Vector3 == this.type)
			{
				return this.vectorValue.GetValue(baseEvent);
			}
			return null;
		}


		public System.Type GetType()
		{
			if(ParameterType.String == this.type)
			{
				return typeof(string);
			}
			else if(ParameterType.Bool == this.type)
			{
				return typeof(bool);
			}
			else if(ParameterType.Int == this.type)
			{
				return typeof(int);
			}
			else if(ParameterType.Float == this.type)
			{
				return typeof(float);
			}
			else if(ParameterType.Vector2 == this.type)
			{
				return typeof(Vector2);
			}
			else if(ParameterType.Vector3 == this.type)
			{
				return typeof(Vector3);
			}
			return null;
		}
	}
}
