
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DummyContentSimple : IContentSimple
	{
		public string name = "";

		public string shortName = "";

		public string description = "";

		public string iconTextCode = "";

		public Texture icon;

		public DummyContentSimple()
		{

		}

		public DummyContentSimple(string name, string shortName, string description, string iconTextCode, Texture icon)
		{
			this.name = name;
			this.shortName = shortName;
			this.description = description;
			this.iconTextCode = iconTextCode;
			this.icon = icon;
		}

		public DummyContentSimple(TextImageDescriptionContent content)
		{
			this.name = content.name;
			this.shortName = content.name;
			this.description = content.description;
			this.icon = content.icon;
		}

		public void Replace(string oldText, string newText)
		{
			this.name = this.name.Replace(oldText, newText);
			this.shortName = this.shortName.Replace(oldText, newText);
			this.description = this.description.Replace(oldText, newText);
		}

		public string GetName()
		{
			return this.name;
		}

		public string GetShortName()
		{
			return this.shortName;
		}

		public string GetDescription()
		{
			return this.description;
		}

		public string GetIconTextCode()
		{
			return this.iconTextCode;
		}

		public Texture GetIcon()
		{
			return this.icon;
		}

		public GUIContent GetContent()
		{
			return new GUIContent(this.name, this.icon);
		}

		public int ID
		{
			get { return -1; }
		}
	}
}
