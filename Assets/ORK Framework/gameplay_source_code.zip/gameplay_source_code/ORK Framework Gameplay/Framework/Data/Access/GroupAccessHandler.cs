﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GroupAccessHandler
	{
		public GroupAccessHandler()
		{

		}


		/*
		============================================================================
		Member functions
		============================================================================
		*/
		/// <summary>
		/// Lets a combatant join a group.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="combatant">The combatant that will join.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed (player groups only).</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added (player groups only).</param>
		public virtual void Join(Group group, Combatant combatant,
			bool showNotification, bool showConsole)
		{
			group.Join(combatant, showNotification, showConsole);
		}

		/// <summary>
		/// Lets a combatant leave a group.
		/// The combatant will be added to the group's inactive members.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="combatant">The combatant that will leave.</param>
		/// <param name="destroyPrefab"><c>true</c> if the combatant's spawned prefab should be destroyed</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed (player groups only).</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added (player groups only).</param>
		public virtual void Leave(Group group, Combatant combatant,
			bool destroyPrefab, bool showNotification, bool showConsole)
		{
			group.Leave(combatant, destroyPrefab, showNotification, showConsole);
		}

		/// <summary>
		/// Removes a combatant from a group completely (i.e. no inactive member).
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="combatant">The combatant that will be removed.</param>
		/// <param name="setGroup"><c>true</c> if the combatant's group should be cleared.</param>
		/// <param name="destroyPrefab"><c>true</c> if the combatant's spawned prefab should be destroyed</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed (player groups only).</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added (player groups only).</param>
		public virtual void Remove(Group group, Combatant combatant,
			bool setGroup, bool destroyPrefab, bool showNotification, bool showConsole)
		{
			group.Remove(combatant, setGroup, destroyPrefab, showNotification, showConsole);
		}

		/// <summary>
		/// Switches combatants between 2 groups.
		/// </summary>
		/// <param name="group">The 1st group.</param>
		/// <param name="oldCombatant">The combatant from the 1st group. If <c>null</c>, only the 'newCombatant' will be transfered to the 1st group.</param>
		/// <param name="newCombatant">The combatant from the 2nd group. If <c>null</c>, only the 'oldCombatant' will be transfered to the 2nd group.</param>
		/// <param name="otherGroup">The 2nd group.</param>
		public virtual void SwitchGroup(Group group, Combatant oldCombatant, Combatant newCombatant, Group otherGroup)
		{
			group.SwitchGroup(oldCombatant, newCombatant, otherGroup);
		}

		/// <summary>
		/// Moves a combatant in front of another combatant in a group (members).
		/// Both combatants must be members of the group.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="combatant">The first combatant.</param>
		/// <param name="otherCombatant">The second combatant.</param>
		public virtual void ChangeMemberSort(Group group, Combatant combatant, Combatant otherCombatant)
		{
			group.ChangeMemberSort(combatant, otherCombatant);
		}


		/*
		============================================================================
		Battle group functions
		============================================================================
		*/
		/// <summary>
		/// Sets the battle group of a group.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="list">The combatants that will be used as battle group.</param>
		/// <param name="enterBattle">The combatants will enter the running battle.</param>
		public virtual void SetBattleGroup(Group group, List<Combatant> list, bool enterBattle)
		{
			group.SetBattleGroup(list, enterBattle);
		}

		/// <summary>
		/// Lets a combatant join the battle group of a group.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="combatant">The combatant that will join the battle group.</param>
		public virtual void JoinBattle(Group group, Combatant combatant)
		{
			group.JoinBattle(combatant);
		}

		/// <summary>
		/// Changes a member of the battle group with another combatant currently not in the battle group.
		/// Both combatants must be members of the group.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="oldCombatant">The combatant currently in the battle group.</param>
		/// <param name="newCombatant">The combatant replacing the old combatant.</param>
		public virtual void ChangeBattle(Group group, Combatant oldCombatant, Combatant newCombatant)
		{
			group.ChangeBattle(oldCombatant, newCombatant);
		}

		/// <summary>
		/// Lets a combatant leave the battle group of a group.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="combatant">The combatant that will leave the battle group.</param>
		/// <param name="destroyPrefab"><c>true</c> if the combatant's spawned prefab should be destroyed.</param>
		public virtual void LeaveBattle(Group group, Combatant combatant, bool destroyPrefab)
		{
			group.LeaveBattle(combatant, destroyPrefab);
		}

		/// <summary>
		/// Moves a combatant in front of another combatant in the battle group of a group.
		/// Both combatants must be members of the battle group.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="combatant">The first combatant.</param>
		/// <param name="otherCombatant">The second combatant.</param>
		public virtual void ChangeBattleSort(Group group, Combatant combatant, Combatant otherCombatant)
		{
			group.ChangeBattleSort(combatant, otherCombatant);
		}


		/*
		============================================================================
		Battle reserve functions
		============================================================================
		*/
		/// <summary>
		/// Lets a combatant join the battle reserve (only for player groups).
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="combatant">The combatant that will join the battle reserve.</param>
		public virtual void JoinBattleReserve(Group group, Combatant combatant)
		{
			group.JoinBattleReserve(combatant);
		}

		/// <summary>
		/// Lets a combatant leave the battle reserve (only for player groups).
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="combatant">The combatant that will leave the battle reserve.</param>
		/// <param name="destroyPrefab"><c>true</c> if the combatant's spawned prefab should be destroyed.</param>
		public virtual void LeaveBattleReserve(Group group, Combatant combatant, bool destroyPrefab)
		{
			group.LeaveBattleReserve(combatant, destroyPrefab);
		}

		/// <summary>
		/// Changes a member of the battle reserve with another combatant currently not in the battle reserve (only for player groups).
		/// Both combatants must be members of the group.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="oldCombatant">The combatant currently in the battle reserve.</param>
		/// <param name="newCombatant">The combatant replacing the old combatant.</param>
		public virtual void ChangeBattleReserve(Group group, Combatant oldCombatant, Combatant newCombatant)
		{
			group.ChangeBattleReserve(oldCombatant, newCombatant);
		}

		/// <summary>
		/// Sets a combatant as the (field) leader of the group and locks it as the leader.
		/// The locked (field) leader will remain the group's leader, even if the first member is changed.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="combatant">The new, locked leader of the group, or <c>null</c> to reset/remove the locked leader.</param>
		public void SetLockedLeader(Group group, Combatant combatant)
		{
			group.SetLockedLeader(combatant);
		}

		/// <summary>
		/// Set the (field) leader of the group.
		/// The (field) leader is the first member of the group.
		/// Has no effect if a locked leader is set.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="newLeader">The new leader combatant.</param>
		/// <param name="moveOldBack"><c>true</c> if the old leader should be moved to the back of the group.</param>
		public virtual void SetLeader(Group group, Combatant newLeader, bool moveOldBack)
		{
			group.SetLeader(newLeader, moveOldBack);
		}


		/*
		============================================================================
		Other functions
		============================================================================
		*/
		/// <summary>
		/// Sets the 'Consumable' type status values of members of a group to their maximum value.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="onlyBattle"><c>true</c> if only members of the battle group should be used.</param>
		/// <param name="revive"><c>true</c> if dead combatants should be revived.</param>
		public virtual void Regenerate(Group group, bool onlyBattle, bool revive)
		{
			group.Regenerate(onlyBattle, revive);
		}

		/// <summary>
		/// Locks or unlocks a member of the battle group of a group.
		/// A locked battle group member can't be removed.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="combatant">The combatant that will be locked/unlocked</param>
		/// <param name="doLock"><c>true</c> if the combatant will be locked.</param>
		public virtual void LockBattleMember(Group group, Combatant combatant, bool doLock)
		{
			group.LockBattleMember(combatant, doLock);
		}

		/// <summary>
		/// Hides or unhides a member of a group.
		/// A hidden combatant isn't visible in any UI (e.g. menus).
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="combatant">The combatant that will be hidden/unhidden</param>
		/// <param name="doHide"><c>true</c> if the combatant will be hidden.</param>
		public virtual void HideMember(Group group, Combatant combatant, bool doHide)
		{
			group.HideMember(combatant, doHide);
		}


		/*
		============================================================================
		Spawn functions
		============================================================================
		*/
		/// <summary>
		/// Spawns members of a group.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="onlyBattle"><c>true</c> if only battle group members should be spawned.</param>
		/// <param name="onlyNonCreated"><c>true</c> if only not yet spawned members should be spawned.</param>
		public virtual void SpawnGroup(Group group, bool onlyBattle, bool onlyNonCreated)
		{
			group.SpawnGroup(onlyBattle, onlyNonCreated);
		}

		/// <summary>
		/// Destroys all spawned members of a group.
		/// </summary>
		/// <param name="group">The group that will be used.</param>
		/// <param name="includeLeader"><c>true</c> if the group's leader should also be destroyed.</param>
		public virtual void DestroyInstances(Group group, bool includeLeader)
		{
			group.DestroyInstances(includeLeader);
		}
	}
}
