﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class StatusValueSorter : IComparer<Combatant>
	{
		private int statusID = 0;

		private StatusValueGetValue usedValue = StatusValueGetValue.CurrentValue;

		private bool inverse = false;

		public StatusValueSorter(int statusID, StatusValueGetValue usedValue, bool inverse)
		{
			this.statusID = statusID;
			this.usedValue = usedValue;
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(inverse)
			{
				return y.Status[this.statusID].GetTypeValue(this.usedValue).CompareTo(
					x.Status[this.statusID].GetTypeValue(this.usedValue)); ;
			}
			else
			{
				return x.Status[this.statusID].GetTypeValue(this.usedValue).CompareTo(
					y.Status[this.statusID].GetTypeValue(this.usedValue)); ;
			}
		}
	}
}
