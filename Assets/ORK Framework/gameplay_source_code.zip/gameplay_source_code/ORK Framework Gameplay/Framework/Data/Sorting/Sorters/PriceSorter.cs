﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BuyPriceSorter : IComparer<IShortcut>
	{
		private Combatant user;

		private bool invert = false;

		public BuyPriceSorter(Combatant user, bool invert)
		{
			this.user = user;
			this.invert = invert;
		}

		public int Compare(IShortcut x, IShortcut y)
		{
			if(this.invert)
			{
				int result = y.BuyPrice(user).CompareTo(x.BuyPrice(user));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
			else
			{
				int result = x.BuyPrice(user).CompareTo(y.BuyPrice(user));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
		}
	}

	public class SellPriceSorter : IComparer<IShortcut>
	{
		private Combatant user;

		private bool invert = false;

		public SellPriceSorter(Combatant user, bool invert)
		{
			this.user = user;
			this.invert = invert;
		}

		public int Compare(IShortcut x, IShortcut y)
		{
			if(this.invert)
			{
				int result = y.SellPrice(user).CompareTo(x.SellPrice(user));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
			else
			{
				int result = x.SellPrice(user).CompareTo(y.SellPrice(user));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
		}
	}
}
