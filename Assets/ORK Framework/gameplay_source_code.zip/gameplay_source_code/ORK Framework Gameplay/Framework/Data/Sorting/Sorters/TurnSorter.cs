
using System.Collections.Generic;

namespace ORKFramework
{
	public class TurnSorter : IComparer<Combatant>
	{
		private bool inverse = false;

		private bool leadersFirst = false;

		private int secondaryFormulaID = -1;

		private float secondaryInitialValue = 0;

		public TurnSorter(bool inverse, int secondaryFormulaID, float secondaryInitialValue)
		{
			this.inverse = inverse;
			this.secondaryFormulaID = secondaryFormulaID;
			this.secondaryInitialValue = secondaryInitialValue;
		}

		public TurnSorter(bool inverse, int secondaryFormulaID, float secondaryInitialValue, bool leadersFirst)
		{
			this.inverse = inverse;
			this.leadersFirst = leadersFirst;
			this.secondaryFormulaID = secondaryFormulaID;
			this.secondaryInitialValue = secondaryInitialValue;
		}

		public int Compare(Combatant x, Combatant y)
		{
			// leaders first
			if(this.leadersFirst)
			{
				if(x.IsLeader &&
					!y.IsLeader)
				{
					return this.inverse ? 1 : -1;
				}
				else if(!x.IsLeader &&
					y.IsLeader)
				{
					return this.inverse ? -1 : 1;
				}
			}

			// regular sort
			if(x.Battle.TurnValue < y.Battle.TurnValue)
			{
				return this.inverse ? -1 : 1;
			}
			else if(x.Battle.TurnValue > y.Battle.TurnValue)
			{
				return this.inverse ? 1 : -1;
			}
			else if(this.secondaryFormulaID >= 0)
			{
				float xValue = ORK.Formulas.Get(this.secondaryFormulaID).Calculate(
					new FormulaCall(this.secondaryInitialValue, x, x));
				float yValue = ORK.Formulas.Get(this.secondaryFormulaID).Calculate(
					new FormulaCall(this.secondaryInitialValue, y, y));
				if(xValue < yValue)
				{
					return this.inverse ? -1 : 1;
				}
				else if(xValue > yValue)
				{
					return this.inverse ? 1 : -1;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return 0;
			}
		}
	}

	public class DummyTurnSorter : IComparer<Combatant>
	{
		private bool inverse = false;

		private bool leadersFirst = false;

		private int secondaryFormulaID = -1;

		private float secondaryInitialValue = 0;

		public DummyTurnSorter(bool inverse, int secondaryFormulaID, float secondaryInitialValue)
		{
			this.inverse = inverse;
			this.secondaryFormulaID = secondaryFormulaID;
			this.secondaryInitialValue = secondaryInitialValue;
		}

		public DummyTurnSorter(bool inverse, int secondaryFormulaID, float secondaryInitialValue, bool leadersFirst)
		{
			this.inverse = inverse;
			this.leadersFirst = leadersFirst;
			this.secondaryFormulaID = secondaryFormulaID;
			this.secondaryInitialValue = secondaryInitialValue;
		}

		public int Compare(Combatant x, Combatant y)
		{
			// leaders first
			if(this.leadersFirst)
			{
				if(x.IsLeader &&
					!y.IsLeader)
				{
					return this.inverse ? 1 : -1;
				}
				else if(!x.IsLeader &&
					y.IsLeader)
				{
					return this.inverse ? -1 : 1;
				}
			}

			// regular sort
			if(x.Battle.TurnValueDummy < y.Battle.TurnValueDummy)
			{
				return this.inverse ? -1 : 1;
			}
			else if(x.Battle.TurnValueDummy > y.Battle.TurnValueDummy)
			{
				return this.inverse ? 1 : -1;
			}
			else if(this.secondaryFormulaID >= 0)
			{
				float xValue = ORK.Formulas.Get(this.secondaryFormulaID).Calculate(
					new FormulaCall(this.secondaryInitialValue, x, x));
				float yValue = ORK.Formulas.Get(this.secondaryFormulaID).Calculate(
					new FormulaCall(this.secondaryInitialValue, y, y));
				if(xValue < yValue)
				{
					return this.inverse ? -1 : 1;
				}
				else if(xValue > yValue)
				{
					return this.inverse ? 1 : -1;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return 0;
			}
		}
	}

	public class GroupLeaderSorter : IComparer<Combatant>
	{
		private bool inverse = false;

		public GroupLeaderSorter(bool inverse)
		{
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(x.IsLeader &&
				!y.IsLeader)
			{
				return this.inverse ? 1 : -1;
			}
			else if(!x.IsLeader &&
				y.IsLeader)
			{
				return this.inverse ? -1 : 1;
			}
			return 0;
		}
	}
}
