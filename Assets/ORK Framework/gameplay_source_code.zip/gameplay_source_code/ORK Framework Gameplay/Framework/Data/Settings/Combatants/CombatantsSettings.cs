
using UnityEngine;

namespace ORKFramework
{
	public class CombatantsSettings : BaseLanguageSettings<CombatantSetting>
	{
		public CombatantsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "combatants"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Combatant; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.CombatantTypes.GetName(this.data[i].typeID) +
						"/" + i + ": " + this.data[i].GetName();
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public Combatant Create(int index, Group group, bool showNotification, bool showConsole)
		{
			if(index >= 0 && index < this.Count)
			{
				Combatant c = new Combatant();
				c.BaseInit(this.data[index], index, group, showNotification, showConsole, false);
				return c;
			}
			return null;
		}

		public void SetStatusValueType(int index, StatusValueType val)
		{
			for(int i = 0; i < this.data.Length; i++)
			{
				if(this.data[i].noStatusDevelopment)
				{
					this.data[i].startValue[index] = 0;
				}
				if(this.data[i].expReward != null)
				{
					for(int j = 0; j < this.data[i].expReward.Length; j++)
					{
						if(this.data[i].expReward[j].statusID == index)
						{
							ArrayHelper.RemoveAt(ref this.data[i].expReward, j--);
						}
					}
				}
				for(int j = 0; j < this.data[i].fieldStatusChange.Length; j++)
				{
					if(this.data[i].fieldStatusChange[j].statusID == index)
					{
						ArrayHelper.RemoveAt(ref this.data[i].fieldStatusChange, j--);
					}
				}
				for(int j = 0; j < this.data[i].battleStatusChange.Length; j++)
				{
					if(this.data[i].battleStatusChange[j].statusID == index)
					{
						ArrayHelper.RemoveAt(ref this.data[i].battleStatusChange, j--);
					}
				}
			}
		}

		public void StatusDevelopmentLevels(int index)
		{
			for(int i = 0; i < this.data.Length; i++)
			{
				if(this.data[i].statusDevelopmentID == index)
				{
					ORK.StatusDevelopments.Get(index).AdjustLevel(ref this.data[i].startLevel);
				}
			}
		}
	}
}
