
using UnityEngine;

namespace ORKFramework
{
	public class EquipmentPartsSettings : BaseLanguageSettings<EquipmentPart>
	{
		public EquipmentPartsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "equipmentParts"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.EquipmentPart; }
		}
	}
}

