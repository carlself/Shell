
using UnityEngine;

namespace ORKFramework
{
	public class QuestTypesSettings : BaseLanguageSettings<QuestType>
	{
		public QuestTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "questTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.QuestType; }
		}
	}
}

