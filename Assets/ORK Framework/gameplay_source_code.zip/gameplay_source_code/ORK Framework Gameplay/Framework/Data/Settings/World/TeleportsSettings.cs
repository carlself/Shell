
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TeleportsSettings : BaseLanguageSettings<Teleport>
	{
		public TeleportsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "teleports"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Teleport; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.AreaTypes.GetName(this.data[i].typeID) +
						"/" + i + ": " + this.data[i].GetName();
				}
				else
				{
					names[i] = this.data[i].GetName();
				}
			}
			return names;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public List<int> GetTeleportIDs(bool ignoreConditions)
		{
			List<int> list = new List<int>();
			for(int i = 0; i < this.data.Length; i++)
			{
				if(ignoreConditions || this.data[i].Available())
				{
					list.Add(i);
				}
			}
			return list;
		}

		public List<ChoiceContent> GetChoicesForIDs(List<int> list, ContentLayout layout)
		{
			List<ChoiceContent> cc = new List<ChoiceContent>();
			for(int i = 0; i < list.Count; i++)
			{
				cc.Add(layout.GetChoiceContent(this.data[list[i]]));
			}
			return cc;
		}

		public List<Teleport> GetTeleports(bool checkParent, int typeID, bool ignoreConditions)
		{
			List<Teleport> list = new List<Teleport>();
			this.GetTeleports(checkParent, typeID, ignoreConditions, ref list);
			return list;
		}

		public void GetTeleports(bool checkParent, int typeID, bool ignoreConditions, ref List<Teleport> list)
		{
			for(int i = 0; i < this.data.Length; i++)
			{
				if((typeID < 0 ||
					this.data[i].typeID == typeID ||
					(checkParent &&
						ORK.AreaTypes.Get(this.data[i].typeID).IsSubTypeOf(typeID))) &&
					(ignoreConditions || this.data[i].Available()))
				{
					list.Add(this.data[i]);
				}
			}
		}

		public List<int> GetAreaTypes(int parentType, bool ignoreConditions)
		{
			List<int> list = new List<int>();
			for(int i = 0; i < this.data.Length; i++)
			{
				if(ignoreConditions || this.data[i].Available())
				{
					ORK.AreaTypes.Get(this.data[i].typeID).AddTypeToList(parentType, ref list);
				}
			}
			return list;
		}

		public bool HasAreaType(bool checkParent, int typeID, bool ignoreConditions)
		{
			List<int> types = new List<int>();
			for(int i = 0; i < this.data.Length; i++)
			{
				if(ignoreConditions || this.data[i].Available())
				{
					if(typeID == -2 || this.data[i].typeID == typeID)
					{
						return true;
					}
					else if(checkParent)
					{
						if(!types.Contains(this.data[i].typeID))
						{
							if(ORK.AreaTypes.Get(this.data[i].typeID).IsSubTypeOf(typeID))
							{
								return true;
							}
							else
							{
								types.Add(this.data[i].typeID);
							}
						}
					}
				}
			}
			return false;
		}
	}
}

