
using UnityEngine;

namespace ORKFramework
{
	public class CurrenciesSettings : BaseLanguageSettings<Currency>
	{
		// general setting
		[ORKEditorInfo("Exchange Rates", "The exchange rates between the different currencies.\n" +
			"The first currency is used as base and always set to 1. " +
			"All other currencies will use the base currency for calculating exchange rates, " +
			"e.g. Currency A is the base currency, currency B has an exchange rate of 1.5 - " +
			"1 money of currency A will be worth 1.5 money in currency B.", "", endFoldout=true)]
		[ORKEditorArray(ORKDataType.Currency, defaultAddValue=1.0f)]
		[ORKEditorLimit(0.0001f, false)]
		public float[] exchangeRate = new float[] {1};

		public CurrenciesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "currencies"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Currency; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.ItemTypes.GetName(this.data[i].itemType) + "/" + i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}
	}
}
