
using UnityEngine;

namespace ORKFramework
{
	public class ConsoleTypesSettings : BaseLanguageSettings<ConsoleType>
	{
		public ConsoleTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "consoleTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.ConsoleType; }
		}
	}
}

