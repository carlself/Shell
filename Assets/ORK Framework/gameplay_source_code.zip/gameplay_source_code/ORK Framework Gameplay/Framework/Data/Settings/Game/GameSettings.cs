
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GameSettings : BaseSettings
	{
		// base settings
		[ORKEditorHelp("Default Horizontal Plane", "Select the default horizontal plane (i.e. which axes are used as the ground/horizontal level):\n" +
			"- XZ: The X and Z axes define the ground, i.e. default 3D behaviour.\n" +
			"- XY: The X and Y axes define the ground, i.e. default 2D behaviour.", "")]
		[ORKEditorInfo("Base Settings", "Base game settings, e.g. default screen size.", "")]
		public HorizontalPlaneType horizontalPlane = HorizontalPlaneType.XZ;

		// access functionality
		[ORKEditorHelp("Access Type", "Select which type of access handler is used.\n" +
			"The access handler is used to funnel some of ORK's functionality through overridable functions. " +
			"This allows you to interject custom functionality when e.g. creating a combatant, adding an item to an inventory and many other things.\n\n" +
			"You can create custom handlers by extending the 'AccessHandler' classes and overriding the functions you want to replace.", "")]
		[ORKEditorInfo(settingBaseType=typeof(AccessHandler), settingAutoSetup="accessHandler")]
		public string accessHandlerType = typeof(AccessHandler).ToString();

		public AccessHandler accessHandler = new AccessHandler();

		// gui settings
		[ORKEditorHelp("Default Screen Size", "The width and height of the screen size you are designing for.\n" +
			"This setting is used to calculate the GUIMatrix and affect every GUI and HUD.\n" +
			"If you run your game on a different screen resolution, ORK will scale all GUI and HUD elements to fit the new screen size.", "")]
		[ORKEditorInfo(separator=true, labelText="Screen/GUI Settings")]
		public Vector2 defaultScreen = new Vector2(1920.0f, 1080.0f);

		[ORKEditorHelp("GUI Padding", "The padding added to GUI at the borders of the screen - " +
			"left (x), top (y), right (z) and bottom (w).", "")]
		public Vector4 guiPadding = Vector4.zero;

		[ORKEditorHelp("GUI Scale Mode", "Select how the GUI will be changed to match different screen resolutions:\n" +
			"- Stretch To Fill: The GUI will be stretched to fill the complete screen. " +
			"The GUI always fits the screen, but can be distorted.\n" +
			"- Scale And Crop: The GUI will be scaled to match the biggest value (width or height) of the screen. " +
			"Some parts of the GUI can be placed outside of the screen.\n" +
			"- Scale To Fit: The GUI will be scaled to match the smallest value (width or height) of the screen. " +
			"The GUI always fits the screen.\n" +
			"- No Scale: The GUI wont be scaled. Some parts of the GUI can be placed outside of the screen.", "")]
		public GUIScaleMode guiScaleMode = GUIScaleMode.StretchToFill;

		[ORKEditorHelp("GUI Anchor", "Select the anchor of the GUI when scaling/placing " +
			"for different resolutions and aspect ratios.", "")]
		[ORKEditorLayout("guiScaleMode", GUIScaleMode.StretchToFill, elseCheckGroup=true, endCheckGroup=true)]
		public TextAnchor guiAnchor = TextAnchor.UpperLeft;

		[ORKEditorHelp("Secure Drag", "Drag windows can't be dragged outside the screen.", "")]
		public bool secureWindowDrag = true;

		// start volumes
		[ORKEditorHelp("Global Volume (0-1)", "Define the global volume (between 0 and 1) that will be used when ORK is initialized.\n" +
			"The global volume scales both music and sound volume.", "")]
		[ORKEditorInfo(separator=true, labelText="Start Volume Settings")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float startGlobalVolume = 1;

		[ORKEditorHelp("Music Volume (0-1)", "Define the music volume (between 0 and 1) that will be used when ORK is initialized.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float startMusicVolume = 1;

		[ORKEditorHelp("Sound Volume (0-1)", "Define the sound volume (between 0 and 1) that will be used when ORK is initialized.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float startSoundVolume = 1;

		[ORKEditorHelp("Initial Music Channels", "Define the number of music channels that will be initialized when starting the game.\n" +
			"E.g. 1 will initialize music channel 0, 2 will initialize channel 0 and 1, etc.", "")]
		[ORKEditorLimit(1, false)]
		public int initialMusicChannels = 1;

		[ORKEditorHelp("Initial Sound Channels", "Define the number of sound channels that will be initialized when starting the game.\n" +
			"E.g. 1 will initialize sound channel 0, 2 will initialize channel 0 and 1, etc.", "")]
		[ORKEditorLimit(1, false)]
		public int initialSoundChannels = 1;

		// random range
		[ORKEditorHelp("Min. Random Range", "The minimum number used for calculating a random number " +
			"for chance checks (e.g. hit chance, counter chance, item drop chance, etc.).", "")]
		[ORKEditorInfo(separator=true, labelText="Chance Settings")]
		public float minRandomRange = 0;

		[ORKEditorHelp("Max. Random Range", "The maximum number used for calculating a random number " +
			"for chance checks (e.g. hit chance, counter chance, item drop chance, etc.).", "")]
		public float maxRandomRange = 100;

		// raycast settings
		[ORKEditorHelp("Raycast Type", "Select the type of raycast that is used:\n" +
			"- Only 3D: Only 3D raycasts are used.\n" +
			"- Only 2D: Only 2D raycasts are used.\n" +
			"- First 3D: Uses a 3D raycast first, if no object is found, a 2D raycast are used.\n" +
			"- First 2D: Uses a 2D raycast first, if no object is found, a 3D raycast is used.", "")]
		[ORKEditorInfo(separator=true, labelText="Raycast Settings")]
		public RaycastType raycastType = RaycastType.Only3D;

		// visibility settings
		[ORKEditorInfo(separator=true, labelText="Visibility Settings")]
		public VisibilityCheck visibilityCheck = new VisibilityCheck();

		// data encryption
		[ORKEditorHelp("Encrypt Data", "The ORK project data files will be encrypted.\n" +
			"If disabled, the files are saved in plain text.", "")]
		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Data Settings")]
		public bool encryptData = false;


		// area notification display
		[ORKEditorHelp("Show Once", "Area notifications will only be displayed when first entering an area.\n" +
			"Once the player visited an area, the notification will not be displayed again.", "")]
		[ORKEditorInfo("Area Settings", "The default layout for area notifications.\n" +
			"The layout can be overridden by each area.", "")]
		public bool showAreasOnce = false;

		[ORKEditorHelp("Use New Area Notification", "Show a different notification when first entering an area.", "")]
		[ORKEditorLayout("showAreasOnce", false, endCheckGroup=true)]
		public bool useNewAreaNotification = false;

		[ORKEditorHelp("Queue Area Notifications", "Select how multiple notifications are displayed:\n" +
			"- Add: Notifications are displayed immediately while previous notifications are still displayed.\n" +
			"- Replace: Notifications are displayed immediately, closing the previous notification.\n" +
			"- Queue: Notifications are queued, displaying them after previous notifications where closed.", "")]
		public NotificationQueueType queueAreaNotifications = NotificationQueueType.Queue;

		[ORKEditorHelp("Close On Scene Change", "Immediately close area notifications when changing scenes.\n" +
			"This will drop all queued notifications and close the used GUI box without any closing behaviour (e.g. fade out).", "")]
		public bool closeAreaNotificationSceneChange = false;

		[ORKEditorInfo("Area Notification Layout", "Notification shown when entering an area.", "",
			endFoldout=true, label=new string[] {
				"%n = area name, %d = area description, %i = area icon",
				"%tn = type name, %td = type description, %ti = type icon"
		})]
		public AreaNotificationLayout areaNotificationLayout = new AreaNotificationLayout();

		[ORKEditorInfo("New Area Notification Layout", "Notification shown when entering an area for the first time.", "",
			endFoldout=true, endFolds=2, label=new string[] {
				"%n = area name, %d = area description, %i = area icon",
				"%tn = type name, %td = type description, %ti = type icon"
		})]
		[ORKEditorLayout(new string[] { "showAreasOnce", "useNewAreaNotification", },
			new object[] { false, true },
			needed=Needed.All, endCheckGroup=true)]
		public AreaNotificationLayout newAreaNotificationLayout = new AreaNotificationLayout();


		// player group
		[ORKEditorInfo("Player/Group Settings", "Player group spawn and player components.", "",
			endFoldout=true)]
		public PlayerGroupSettings playerGroup = new PlayerGroupSettings();


		// statistics
		[ORKEditorInfo("Statistic Settings", "Select which statistics the game will keep.", "", endFoldout=true)]
		public GameStatistic statistic = new GameStatistic();


		// bestiary
		[ORKEditorInfo("Bestiary Settings", "Define if the bestiary is used and how information on enemies is learned.\n" +
			"The bestiary provides information about encountered enemy combatants, e.g. status values and attack/defence attributes.", "",
			endFoldout=true)]
		public BestiarySettings bestiary = new BestiarySettings();


		// game over
		[ORKEditorInfo("Game Over Settings", "Game over scene and retry/load choice.", "", endFoldout=true)]
		public GameOverChoice gameOver = new GameOverChoice();


		// initial game variables
		[ORKEditorInfo("Initial Game Variables",
			"Define game variables that will be automatically set when starting the game.\n" +
			"The variables will be set when ORK is initialized, " +
			"i.e. before the main menu - you can use this to set up custom options.\n" +
			"The variables will be kept when starting a new game - " +
			"but keep in mind that loading a saved game will clear all previous game variables.", "",
			endFoldout=true)]
		public VariableSetter initialVariables = new VariableSetter();


		// asset settings
		[ORKEditorInfo("Asset Settings", "Define base asset settings that are used in this project.\n" +
			"E.g. setting the default path for asset bundles.", "",
			endFoldout=true)]
		public AssetSettings assetSettings = new AssetSettings();


		// Unity functionality
		[ORKEditorInfo("Unity Wrapper", "You can optionally use custom functions when ORK calls standard Unity functionality " +
			"(e.g. instantiating game objects).", "",
			endFoldout=true)]
		public UnityWrapper unityWrapper = new UnityWrapper();

		public GameSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("maxSteps"))
			{
				data.Get("maxSteps", ref ORK.GameControls.interaction.maxSteps);
				data.Get("maxClickDistance", ref ORK.GameControls.interaction.maxClickDistance);
			}
			if(data.Contains<int>("activeQuests"))
			{
				ORK.QuestSettings.SetData(data);
			}

			if(data.Contains<bool>("queueAreaNotifications"))
			{
				bool tmp = false;
				data.Get("queueAreaNotifications", ref tmp);
				this.queueAreaNotifications = tmp ? NotificationQueueType.Queue : NotificationQueueType.Replace;
			}

			if(this.accessHandler == null)
			{
				this.accessHandler = new AccessHandler();
				this.accessHandlerType = this.accessHandler.GetType().ToString();
			}
			if(data.Contains<int>("playerFactionID"))
			{
				this.playerGroup.SetData(data);
			}
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(this.accessHandler == null ||
				!this.accessHandler.IsType(this.accessHandlerType))
			{
				DataObject data = this.accessHandler != null ?
					this.accessHandler.GetData() : null;
				object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
					this.accessHandlerType, typeof(AccessHandler));
				if(tmpSettings is AccessHandler)
				{
					this.accessHandler = (AccessHandler)tmpSettings;
					this.accessHandler.SetData(data);
				}
				else
				{
					this.accessHandler = new AccessHandler();
					this.accessHandler.SetData(data);
					this.accessHandlerType = this.accessHandler.GetType().ToString();
				}
			}
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "gameSettings"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}

		public void CheckDragWindowPosition(ref Rect windowRect)
		{
			if(windowRect.x < 0)
			{
				windowRect.x = 0;
			}
			else if((windowRect.x + windowRect.width) > this.defaultScreen.x)
			{
				windowRect.x = this.defaultScreen.x - windowRect.width;
			}
			if(windowRect.y < 0)
			{
				windowRect.y = 0;
			}
			else if((windowRect.y + windowRect.height) > this.defaultScreen.y)
			{
				windowRect.y = this.defaultScreen.y - windowRect.height;
			}
		}

		public Vector3 GetScreenCenter()
		{
			return new Vector3(this.defaultScreen.x / 2, this.defaultScreen.y / 2, 0);
		}


		/*
		============================================================================
		Chance/Random functions
		============================================================================
		*/
		public float GetRandom()
		{
			return UnityWrapper.Range(this.minRandomRange, this.maxRandomRange);
		}

		public bool CheckRandom(float chance)
		{
			float rnd = this.GetRandom();
			if(rnd > this.minRandomRange && rnd <= chance)
			{
				return true;
			}
			return false;
		}
	}
}
