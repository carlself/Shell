
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class LogsSettings : BaseLanguageSettings<Log>
	{
		public LogsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "logs"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Log; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.LogTypes.GetName(this.data[i].logTypeID) + "/" + i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}


		/*
		============================================================================
		Log functions
		============================================================================
		*/
		public List<int> GetLogs(int logTypeID)
		{
			List<int> list = new List<int>();

			for(int i = 0; i < this.data.Length; i++)
			{
				if(this.data[i].logTypeID == logTypeID)
				{
					list.Add(i);
				}
			}

			return list;
		}
	}
}

