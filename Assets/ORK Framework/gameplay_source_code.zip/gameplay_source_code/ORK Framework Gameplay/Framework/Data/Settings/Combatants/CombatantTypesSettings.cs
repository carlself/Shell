﻿
using UnityEngine;

namespace ORKFramework
{
	public class CombatantTypesSettings : BaseLanguageSettings<CombatantType>
	{
		public CombatantTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "combatantTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.CombatantType; }
		}
	}
}
