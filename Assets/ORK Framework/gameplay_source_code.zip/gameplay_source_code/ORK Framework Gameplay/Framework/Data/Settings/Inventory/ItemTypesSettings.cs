
using UnityEngine;

namespace ORKFramework
{
	public class ItemTypesSettings : BaseLanguageSettings<ItemType>
	{
		public ItemTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "itemTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.ItemType; }
		}
	}
}

