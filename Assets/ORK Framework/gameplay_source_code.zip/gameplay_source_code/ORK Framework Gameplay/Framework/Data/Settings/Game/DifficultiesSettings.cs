
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DifficultiesSettings : BaseLanguageSettings<Difficulty>
	{
		public DifficultiesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "difficulties"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Difficulty; }
		}


		/*
		============================================================================
		In-game functions
		============================================================================
		*/
		public float GetTimeFactor()
		{
			float factor = 1;
			if(ORK.Game.Difficulty >= 0 &&
				ORK.Game.Difficulty < this.data.Length)
			{
				factor = this.data[ORK.Game.Difficulty].timeFactor;
			}
			return factor;
		}

		public float GetMovementFactor()
		{
			float factor = 1;
			if(ORK.Game.Difficulty >= 0 &&
				ORK.Game.Difficulty < this.data.Length)
			{
				factor = this.data[ORK.Game.Difficulty].movementFactor;
			}
			return factor;
		}

		public float GetBattleFactor()
		{
			float factor = 1;
			if(ORK.Game.Difficulty >= 0 &&
				ORK.Game.Difficulty < this.data.Length)
			{
				factor = this.data[ORK.Game.Difficulty].battleFactor;
			}
			return factor;
		}

		public float GetAnimationFactor()
		{
			float factor = 1;
			if(ORK.Game.Difficulty >= 0 &&
				ORK.Game.Difficulty < this.data.Length)
			{
				factor = this.data[ORK.Game.Difficulty].animationFactor;
			}
			return factor;
		}

		public ChoiceContent[] GetDifficultyChoice(ContentLayout layout)
		{
			ChoiceContent[] choice = new ChoiceContent[this.data.Length+1];
			for(int i = 0; i < this.data.Length; i++)
			{
				choice[i] = layout.GetChoiceContent(this.data[i]);
			}
			choice[choice.Length - 1] = layout.GetChoiceContent(ORK.GUI.Settings.defaultButtons.cancelButton);
			return choice;
		}


		/*
		============================================================================
		Add, remove callbacks
		============================================================================
		*/
		public void SetStatusValueType(int index, StatusValueType type)
		{
			if(StatusValueType.Consumable == type)
			{
				for(int i = 0; i < this.data.Length; i++)
				{
					for(int j = 0; j < this.data[i].faction.Length; j++)
					{
						this.data[i].faction[j].statusMultiplier[index] = 1;
					}
				}
			}
		}
	}
}

