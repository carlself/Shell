
using UnityEngine;

namespace ORKFramework
{
	public class AbilityTypesSettings : BaseLanguageSettings<AbilityType>
	{
		public AbilityTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "abilityTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.AbilityType; }
		}
	}
}

