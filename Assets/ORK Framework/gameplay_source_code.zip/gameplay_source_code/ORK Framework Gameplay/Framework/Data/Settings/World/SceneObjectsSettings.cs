
using UnityEngine;

namespace ORKFramework
{
	public class SceneObjectsSettings : BaseLanguageSettings<SceneObject>
	{
		public SceneObjectsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "sceneObjects"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.SceneObject; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.SceneObjectTypes.GetName(this.data[i].typeID) + "/" + i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}
	}
}

