﻿
using UnityEngine;
using ORKFramework.AI;
using System.Collections.Generic;

namespace ORKFramework
{
	public class AIRulesetsSettings : BaseLanguageSettings<AIRuleset>
	{
		public AIRulesetsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "aiRulesets"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.AIRuleset; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.AITypes.GetName(this.data[i].typeID) +
						"/" + i + ": " + this.data[i].GetName();
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}
	}
}
