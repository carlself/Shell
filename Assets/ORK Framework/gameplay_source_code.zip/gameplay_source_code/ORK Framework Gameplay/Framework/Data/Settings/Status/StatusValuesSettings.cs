
using UnityEngine;

namespace ORKFramework
{
	public class StatusValuesSettings : BaseLanguageSettings<StatusValueSetting>
	{
		public StatusValuesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "statusValues"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.StatusValue; }
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public StatusValue Create(int index, Combatant owner)
		{
			if(index >= 0 && index < this.Count)
			{
				return new StatusValue(index, this.data[index], owner);
			}
			return null;
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.StatusTypes.GetName(this.data[i].statusTypeID) +
						"/" + i + ": " + this.data[i].GetName();
				}
				else
				{
					names[i] = this.data[i].GetName();
				}
			}
			return names;
		}


		/*
		============================================================================
		Add, remove callbacks
		============================================================================
		*/
		public void SetStatusValueType(int index, StatusValueType val)
		{
			for(int i = 0; i < this.data.Length; i++)
			{
				if(this.data[i].IsConsumable() &&
					this.data[i].barrier != null)
				{
					for(int j = 0; j < this.data[i].barrier.Length; j++)
					{
						if(this.data[i].barrier[j].statusID == index)
						{
							ArrayHelper.RemoveAt(ref this.data[i].barrier, j--);
						}
					}
				}
			}
		}
	}
}
