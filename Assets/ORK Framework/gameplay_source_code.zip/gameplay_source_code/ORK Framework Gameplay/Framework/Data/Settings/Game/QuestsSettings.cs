
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class QuestsSettings : BaseLanguageSettings<QuestSetting>
	{
		public QuestsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "quests"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Quest; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.QuestTypes.GetName(this.data[i].questTypeID) + "/" + i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}

		public string GetText(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].text[ORK.Game.Language];
			}
			else
			{
				return "Quest " + index + " not found";
			}
		}


		/*
		============================================================================
		Quest functions
		============================================================================
		*/
		public List<int> GetQuests(int questTypeID)
		{
			List<int> list = new List<int>();

			for(int i = 0; i < this.data.Length; i++)
			{
				if(this.data[i].questTypeID == questTypeID)
				{
					list.Add(i);
				}
			}

			return list;
		}
	}
}
