
using UnityEngine;

namespace ORKFramework
{
	public class InputKeysSettings : BaseSettings
	{
		public InputKey[] data = new InputKey[] {
			new InputKey("None"),
			new InputKey("Horizontal", KeyCode.RightArrow, KeyCode.LeftArrow, InputHandling.Hold),
			new InputKey("Vertical", KeyCode.UpArrow, KeyCode.DownArrow, InputHandling.Hold),
			new InputKey("Accept", KeyCode.Return, KeyCode.None, InputHandling.Down),
			new InputKey("Cancel", KeyCode.RightControl, KeyCode.None, InputHandling.Down)
		};

		public InputKeysSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}

		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "inputKeys"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].name;
			}
			else
			{
				return "InputKey(" + index + ") not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.data[i].name;
				}
				else
				{
					names[i] = this.data[i].name;
				}
			}
			return names;
		}

		public override int Count
		{
			get { return this.data.Length; }
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			ArrayHelper.Add(ref this.data, new InputKey("New"));
			DataHelper.Added(ORKDataType.InputKey);
			return this.data.Length - 1;
		}

		public override int Copy(int index)
		{
			ArrayHelper.Add(ref this.data, this.GetCopy(index));
			DataHelper.Added(ORKDataType.InputKey);
			return this.data.Length - 1;
		}

		public InputKey GetCopy(int index)
		{
			InputKey t = new InputKey();
			if(index >= 0 && index < this.data.Length)
			{
				t.SetData(this.data[index].GetData());
			}
			return t;
		}

		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.InputKey, index);
		}

		public InputKey Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else
			{
				return this.data[0];
			}
		}

		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.InputKey, down, index);
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public void Tick()
		{
			for(int i = 0; i < this.data.Length; i++)
			{
				this.data[i].Tick();
			}
			for(int i = 0; i < this.data.Length; i++)
			{
				this.data[i].TickCollection();
			}

			ORK.GUI.Drag.CheckCancelDragKey();
		}

		public void ResetAxisHUD()
		{
			for(int i = 0; i < this.data.Length; i++)
			{
				this.data[i].SetAxisHUD(0);
			}
		}

		public void ResetInputAxes(bool resetUnityInputs)
		{
			ORK.GUI.Drag.CancelDrag();
			if(resetUnityInputs)
			{
				Input.ResetInputAxes();
			}
			ORK.Control.Touch.Clear();
			for(int i = 0; i < this.data.Length; i++)
			{
				this.data[i].Received = false;
			}
		}
	}
}
