
using UnityEngine;
using ORKFramework.Combatants;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleSettings : BaseSettings
	{
		// base settings
		[ORKEditorHelp("Enemy Counter", "Enemies of the same type can have a counter " +
			"added to their name to differentiate them from another:\n" +
			"- None: No counter is added.\n" +
			"- Letters: Letters are used (A, B, C, ...).\n" +
			"- Numbers: Numbers are used (1, 2, 3, ...).\n" +
			"The enemy counter is only used in arena battles.", "")]
		[ORKEditorInfo("Base Settings", "Base battle system settings.", "",
			isEnumToolbar=true, toolbarWidth=75)]
		public EnemyCounting enemyCounter = EnemyCounting.None;

		[ORKEditorHelp("Count Type", "Select how enemies are counted:\n" +
			"- ID: Based on their combatant ID.\n" +
			"- Name: Based on their name (i.e. matching names are counted together).", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("enemyCounter", EnemyCounting.None, elseCheckGroup=true, endCheckGroup=true)]
		public EnemyCountingType enemyCounterType = EnemyCountingType.ID;

		[ORKEditorHelp("Play Damage Animation", "Combatants currently performing a battle action " +
			"(and by this a battle animation) will play their damage animation when receiving damage.\n" +
			"If disabled, damage animations will be ignored for combatants that are in action while receiving damage.", "")]
		public bool playDamageAnim = false;

		[ORKEditorHelp("Play Victory Animation", "The combatants that won the battle will play the victory animation type.\n" +
			"Disable this setting to not automatically play a victory animation, e.g. if you want to handle this in the battle end event.", "")]
		public bool playVictoryAnimation = true;


		// combatant links
		[ORKEditorHelp("Clear Battle End", "All combatant links of a combatant will be removed when leaving/ending battles.", "")]
		[ORKEditorInfo("Combatant Links", "Combatants can be linked to others via the " +
			"'Link Combatants' node in the event system.\n" +
			"These links can be automatically released to free up memory.", "")]
		public bool clearCombatantLinksBattleEnd = true;

		[ORKEditorHelp("Auto Clear Dead", "Dead combatants will clear their own combatant links.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool autoClearDeadCombatantLinks = false;


		// base defend rate
		[ORKEditorInfo("Base Defend Rate", "Define the base defence rate when using the defend command.\n" +
			"It's used as percent value - i.e. if the value is 100, " +
			"the damage will do 100 % of it's original damage, if the result is 50, the damage " +
			"will only do 50 % of it's original damage.", "",
			endFoldout=true)]
		public FloatValue defendRate = new FloatValue(50);

		// base counter chance
		[ORKEditorInfo("Base Counter Chance", "Define the base counter chance.\n" +
			"The counter chance decides if a combatant counters an attack (i.e. when received damage).\n" +
			"The counter is performed if a random float number between two values (default 0 and 100, you can change " +
			"this in the game settings) is less or equal to this value.\n" +
			"When using a formula, the attacked combatant (who will counter) will be used as the user in the calculation, " +
			"while the attacker is the target.\n" +
			"Each combatant can individually override this setting.", "",
			endFoldout=true)]
		public FloatValue counterChance = new FloatValue();

		// base block chance
		[ORKEditorInfo("Base Block Chance", "Define the base block chance.\n" +
			"Attacks and abilities can be blocked (if enabled) if a random float number between two values " +
			"(default 0 and 100, you can change this in the game settings) is less or equal to this value.\n" +
			"When using a formula, the attacked combatant will be used as the target in the calculation, " +
			"while the attacker is the user.\n" +
			"Each combatant can individually override this setting.", "",
			endFoldout=true)]
		public FloatValue blockChance = new FloatValue();

		// escape chance
		[ORKEditorInfo("Base Escape Chance", "Define the base escape chance when using the escape command.\n" +
			"The escape is performed if a random float number between two values " +
			"(default 0 and 100, you can change this in the game settings) " +
			"is less or equal to this value.\n" +
			"Each combatant can individually override this setting.", "",
			endFoldout=true)]
		public FloatValue escapeChance = new FloatValue(50);

		// experience factor
		[ORKEditorInfo("Base Experience Factor", "Define the base experience factor.\n" +
			"The experience factor influences the experience a combatant gains from battle. E.g.:\n" +
			"- factor 1: The combatant gets 100 % of the experience.\n" +
			"- factor 0.5: The combatant gets 50 % of the experience.\n" +
			"- factor 2: The combatant gets 200 % of the experience.\n" +
			"A negative experience factor is not possible, the smallest factor is 0.\n" +
			"Each combatant can individually override this setting.", "",
			endFoldout=true)]
		public FloatValue experienceFactor = new FloatValue(1);

		// random battle factor
		[ORKEditorInfo("Random Battle Factor", "Define the random battle factor.\n" +
			"The random battle factor is used to influence the chance of random battles occurring. " +
			"The factor is influenced by the player battle group's random battle factor bonuses.\n" +
			"When using a formula, the player combatant (i.e. leader of the player group) will be used as user and target.\n\n" +
			"E.g.:\n" +
			"The random battle chance is 10 %, the factor is 100 % - the final chance is 10 %." +
			"The chance is 10 %, the factor is 50 % - the final chance is 5 %.", "",
			endFoldout=true)]
		public FloatValue randomBattleFactor = new FloatValue(100);


		// ranges
		// battle range
		[ORKEditorHelp("Use Battle Range", "The battle range is used to determine participating combatants.\n" +
			"If disabled, all combatants will participate in battle.", "")]
		[ORKEditorInfo("Battle Range", "The distance (in world units) a combatant can " +
			"have to the player to participate in a battle.", "")]
		public bool useBattleRange = true;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useBattleRange", true, endCheckGroup=true)]
		public Range battleRange = new Range(20.0f);

		// AI settings
		[ORKEditorHelp("Use AI Range", "The AI range is used to determine if a combatant can perform AI actions.\n" +
			"If disabled, the distance to the player doesn't prevent performing AI actions.", "")]
		[ORKEditorInfo("AI Range", "The distance (in world units) a combatant can " +
			"have to the player to perform AI actions.", "")]
		public bool useAIRange = true;

		[ORKEditorHelp("AI Recheck Time (s)", "The time in seconds between AI range checks.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("useAIRange", true)]
		public float aiRecheckTime = 4.0f;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public Range aiRange = new Range(100.0f);

		// move AI range
		[ORKEditorHelp("Use Move AI Range", "The move AI range is used to determine if a combatant can use the move AI.\n" +
			"If disabled, the distance to the player doesn't prevent using the move AI.", "")]
		[ORKEditorInfo("Move AI Range", "The distance (in world units) a combatant can " +
			"have to the player to use the move AI.\n" +
			"This will be used while not in battle - " +
			"each battle system type can define it's own move AI settings.", "")]
		public bool useMoveAIRange = true;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useMoveAIRange", true, endCheckGroup=true)]
		public Range moveAIRange = new Range(100.0f);

		// auto join
		[ORKEditorInfo("Auto Join Settings", "Combatants within range of a starting battle can " +
			"automatically join the battle.\n" +
			"This setting can be overridden by individual 'Battle' components in the scene.\n" +
			"Note that this is only used in arena battles (i.e. using the 'Battle' component), " +
			"and not in real time area battles.", "",
			endFoldout=true, endFolds=2)]
		public AutoJoinBattle autoJoin = new AutoJoinBattle();


		// auto start battles
		[ORKEditorInfo("Auto Start Battles", "A combatant can automatically start battles with the player upon defined conditions.\n" +
			"Only used when the player and the combatant are enemies and there is currently no battle running.", "",
			endFoldout=true)]
		public AutoStartBattleSettings autoStartBattles = new AutoStartBattleSettings(true);


		// default use range
		[ORKEditorInfo("Default Use Range", "The default use range settings for using abilities and items.\n" +
			"The use range determines the maximum distance between user and target to allow using an ability or item. " +
			"The range can be defined for each battle system type." +
			"Can be overridden by each ability and item individually.", "", endFoldout=true)]
		public UseRangeSettings useRange = new UseRangeSettings();


		// default cast times
		[ORKEditorInfo("Cast Time Settings", "You can optionally use cast times for basic commands like defending or escaping.", "",
			"Default Ability Cast Time", "An ability can be casted for a set amount of time before it is used.\n" +
			"This is the default setting for all abilities, each individual ability can override it.\n"+
			"The cast time can be displayed in a HUD (either as a number or a bar).", "",
			endFoldout=true)]
		public CastTimeSettings abilityCastTime = new CastTimeSettings();

		[ORKEditorInfo("Default Item Cast Time", "An item can be casted for a set amount of time before it is used.\n" +
			"This is the default setting for all items, each individual item can override it.\n"+
			"The cast time can be displayed in a HUD (either as a number or a bar).", "",
			endFoldout=true)]
		public CastTimeSettings itemCastTime = new CastTimeSettings();

		[ORKEditorInfo("Defend Cast Time", "The defend command can be casted for a set amount of time before it is used.\n" +
			"The cast time can be displayed in a HUD (either as a number or a bar).", "",
			endFoldout=true)]
		public CastTimeSettings defendCastTime = new CastTimeSettings();

		[ORKEditorInfo("Escape Cast Time", "The escape command can be casted for a set amount of time before it is used.\n" +
			"The cast time can be displayed in a HUD (either as a number or a bar).", "",
			endFoldout=true)]
		public CastTimeSettings escapeCastTime = new CastTimeSettings();

		[ORKEditorInfo("None Cast Time", "The none command (doing nothing) can be casted for a set amount of time before it is used.\n" +
			"The cast time can be displayed in a HUD (either as a number or a bar).", "",
			endFoldout=true)]
		public CastTimeSettings noneCastTime = new CastTimeSettings();

		[ORKEditorInfo("Grid Move Cast Time", "The grid move command can be casted for a set amount of time before it is used.\n" +
			"The cast time can be displayed in a HUD (either as a number or a bar).", "",
			endFoldout=true, endFolds=2)]
		public CastTimeSettings gridMoveCastTime = new CastTimeSettings();


		// level up
		[ORKEditorInfo("Level Up Settings", "A combatant can receive bonuses when reaching a new base or class level.", "",
			"Base Level Up", "Settings for base level ups.\n" +
			"Can be overridden by each combatant individually.", "", endFoldout=true)]
		public LevelUpBonus lvlUp = new LevelUpBonus();

		[ORKEditorInfo("Class Level Up", "Settings for class level ups.\n" +
			"Can be overridden by each class individually.", "", endFoldout=true, endFolds=2)]
		public LevelUpBonus cLvlUp = new LevelUpBonus();


		// battle advantages
		[ORKEditorInfo("Player Advantage", "Battle advantage settings for the player group.\n" +
			"Battle advantages can change 'Consumable' type status values, " +
			"status effects and the turn order ('Turn Based' type battles) or timebar ('Active Time' type battles) at the start of a battle.\n" +
			"Advantages are available in arena battles and are decided on a chance basis at the start of a battle.\n" +
			"Arenas can override the chances and block advantages completely.", "", endFoldout=true)]
		public BattleAdvantage playerAdvantage = new BattleAdvantage();

		[ORKEditorInfo("Enemy Advantage", "Battle advantage settings for the enemy group.\n" +
			"Battle advantages can change 'Consumable' type status values, " +
			"status effects and the turn order ('Turn Based' type battles) or timebar ('Active Time' type battles) at the start of a battle.\n" +
			"Advantages are available in arena battles and are decided on a chance basis at the start of a battle.\n" +
			"Arenas can override the chances and block advantages completely.", "", endFoldout=true)]
		public BattleAdvantage enemyAdvantage = new BattleAdvantage();


		// menu settings
		[ORKEditorInfo("Battle Menu Settings", "Define the default battle menu settings.", "")]
		public BattleMenuSelection battleMenu = new BattleMenuSelection();

		// drag/drop
		[ORKEditorHelp("Enable Drag", "The attack command, abilities and items can be " +
			"dragged from the menu on a target to use them.", "")]
		[ORKEditorInfo(separator=true, labelText="Control Settings")]
		public bool bmDrag = false;

		[ORKEditorHelp("Enable Clicking", "Clicking on the attack command, " +
			"an ability or an item and clicking on a target uses the command on the target.", "")]
		public bool bmClick = false;

		[ORKEditorHelp("Click Count", "Define the number of clicks needed.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("bmClick", true, endCheckGroup=true)]
		public int bmClickCount = 2;

		[ORKEditorHelp("Enable Tooltip", "A tooltip HUD can be displayed when the mouse position is over a battle menu item.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool bmTooltip = false;


		// default start turn events
		[ORKEditorInfo("Combatant Settings", "Various default combatant settings that can be overridden by each individual combatant.", "",
			"Default Events", "Combatants can perform game events at the start and end of their turn.\n" +
			"Define the default events here, each combatant can individually override these events.", "",
			"Init Events", "Define the game events that will be performed when first initializing a combatant.\n" +
			"The combatant will be used as 'Starting Object'.\n" +
			"The events are separated into player group, ally group and enemy group combatants.\n" +
			"Each combatant can individually override these default events.", "",
			endFoldout=true)]
		public FactionEventSetting initEvents = new FactionEventSetting();

		[ORKEditorInfo("Spawn Events", "Define the game events that will be performed when spawning a combatant.\n" +
			"The combatant will be used as 'Starting Object'.\n" +
			"The events are separated into player group, ally group and enemy group combatants.\n" +
			"Each combatant can individually override these default events.", "",
			endFoldout=true)]
		public FactionEventSetting spawnEvents = new FactionEventSetting();

		[ORKEditorInfo("Turn Start Events", "Define the game events that will be performed at the " +
			"start of a combatant's turn (after the grid cell events).\n" +
			"The combatant will be used as 'Starting Object'.\n" +
			"The events are separated into player group, ally group and enemy group combatants.\n" +
			"Each combatant can individually override these default events.", "",
			endFoldout=true)]
		public FactionEventSetting turnStartEvents = new FactionEventSetting();

		[ORKEditorInfo("Turn End Events", "Define the game events that will be performed at the " +
			"end of a combatant's turn (before the grid cell events).\n" +
			"The combatant will be used as 'Starting Object'.\n" +
			"The events are separated into player group, ally group and enemy group combatants.\n" +
			"Each combatant can individually override these default events.", "",
			endFoldout=true)]
		public FactionEventSetting turnEndEvents = new FactionEventSetting();

		[ORKEditorInfo("Custom Events", "Custom events can be used in other events using a 'Custom Combatant Event' node.\n" +
			"The combatant will be used as 'Starting Object'.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorArray(false, "Add Custom Events", "Adds custom events.", "",
			"Remove", "Removes the custom events.", "", isCopy=true, isMove=true,
			removeType=ORKDataType.StatusValue, removeCheckField="statusID",
			foldout=true, foldoutText=new string[] {
				"Custom Events", "Define the game events that will be performed when using a " +
				"'Custom Combatant Event' node with a matching key.\n" +
				"The combatant will be used as 'Starting Object'.\n" +
				"The events are separated into player group, ally group and enemy group combatants.\n" +
				"Each combatant can individually override these default events.", ""
		})]
		public KeyFactionEventSetting[] customEvents = new KeyFactionEventSetting[0];


		// default action combos
		[ORKEditorHelp("Action Combo", "Select the action combo that will be available.", "")]
		[ORKEditorInfo("Default Action Combos", "Define action combos that will be available for all combatants.\n" +
			"Combatants can optionally add or replace the default combos.", "",
			ORKDataType.ActionCombo, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Action Combo", "Adds an action combo.", "",
			"Remove", "Removes the action combo.", "", isHorizontal=true)]
		public int[] defaultActionCombo = new int[0];


		// default battle animations
		[ORKEditorInfo("Battle Animations", "Define the battle events used to animate default actions, e.g. defend, escape or a combatant's death.\n" +
			"Combatants can override the default animations.", "",
			endFoldout=true)]
		public DefaultBattleAnimations battleAnimations = new DefaultBattleAnimations();


		// auto animation
		[ORKEditorInfo("Default Auto Animation", "ORK can automatically handle movement animations " +
			"(idle, walk, run, sprint, fall, land) based on the combatant's movement.\n" +
			"If disabled, you'll have to manage the movement animations with your own scripts.\n" +
			"The auto animation can also be enabled/disabled using the event system.\n" +
			"Combatants can override the default settings in their animation settings.", "",
			endFoldout=true)]
		public AutoAnimationSetting autoAnimation = new AutoAnimationSetting();


		// find ground
		[ORKEditorInfo("Default Find Ground", "Define how combatants check if their game object is on the ground or in the air.\n" +
			"This is e.g. used by auto animations and control maps.\n" +
			"Combatants can override the default settings in their movement settings.", "",
			endFoldout=true, endFolds=2)]
		public FindGroundSettings findGround = new FindGroundSettings();


		// battle statistics
		[ORKEditorInfo("Combatant Battle Statistics", "Dealing and taking damage can be tracked to be e.g. used in the battle AI or formulas.\n" +
			"Beside tracking the total damage dealt/taken of a combatant, you can also track damage dealt and take from individual combatants.", "",
			endFoldout=true)]
		public BattleStatisticSettings battleStatistics = new BattleStatisticSettings();

		public BattleSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("bmDoubleClick"))
			{
				data.Get("bmDoubleClick", ref this.bmClick);
			}
			if(data.Contains<DataObject>("camera"))
			{
				ORK.BattleCamera.SetData(data.GetFile("camera"));
			}
			if(data.Contains<bool>("useTargetMenu"))
			{
				ORK.TargetSettings.SetData(data);
			}
			if(data.Contains<int>("menuID"))
			{
				this.battleMenu.SetData(data);
			}
		}

		public override void SetRealIDs()
		{

		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "battleSettings"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}
	}
}
