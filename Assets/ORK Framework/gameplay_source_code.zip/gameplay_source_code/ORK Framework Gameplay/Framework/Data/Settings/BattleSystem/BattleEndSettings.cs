
using UnityEngine;
using ORKFramework.UI;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleEndSettings : BaseSettings
	{
		// general settings
		// experience
		[ORKEditorHelp("Experience For Killer", "The experience points of a killed enemy will go to the (player) combatant that killed it.\n" +
			"If disabled, the whole group or battle group will get the experience points.", "")]
		[ORKEditorInfo("Base Settings", "Define the experience and normal status value gain options.", "",
			labelText="Experience Reward Settings")]
		public bool expForKiller = false;

		[ORKEditorHelp("Split Experience Rewards", "The experience points gained from enemies will be split through " +
			"the battle group members, i.e. every group member will only get a part of the experience.", "")]
		[ORKEditorLayout("expForKiller", false)]
		public bool splitExp = false;

		[ORKEditorHelp("Whole Party", "The whole (active) group will receive experience.\n" +
			"If the experience is splitted, it will be splitted by all (active) group members.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool wholePartyExp = false;

		[ORKEditorHelp("Dead Receive Exp.", "Dead group members will also receive experience.\n" +
			"If disabled, only group members who are alive will receive experience.", "")]
		public bool deadExp = false;

		// normal
		[ORKEditorHelp("Split Normal Rewards", "The 'Normal' status value points gained from enemies will be split through " +
			"the battle group members, i.e. every group member will only get a part of the 'Normal' status value reward.", "")]
		[ORKEditorInfo(separator=true, labelText="Normal Status Value Reward Settings")]
		public bool splitNormalSV = false;

		[ORKEditorHelp("Whole Party", "The whole (active) group will receive 'Normal' status value rewards.\n" +
			"If the 'Normal' status value rewards are splitted, it will be splitted by all (active) group members.", "")]
		public bool wholePartyNormalSV = false;

		[ORKEditorHelp("Dead Receive Normal", "Dead group members will also receive 'Normal' status value rewards.\n" +
			"If disabled, only group members who are alive will receive 'Normal' status value rewards.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool deadNormalSV = false;



		// loot dialogue
		[ORKEditorArray(false, "Add Loot Dialogue", "Adds a loot dialogue setting.\n" +
			"You can set up different loot dialogues for different battle outcomes (e.g. victory and defeat).", "",
			"Remove", "Removes this loot dialogue setting.", "",
			noRemoveCount=1, isCopy=true, isMove=true, foldout=true, foldoutText=new string[] {
				"Loot Dialogue", "Select which loot dialogue should be used in which battle outcomes.", ""
		})]
		public LootDialogueSettings[] loot = new LootDialogueSettings[]
		{
			new LootDialogueSettings()
		};


		// level up
		[ORKEditorInfo("Level Up Texts", "The texts used by level up notifications to show a combatant's status changes.\n" +
			"The order of the single texts can be changed by changing the total level up text.\n" +
			"All texts will be displayed in one message.", "",
			endFoldout=true)]
		public LevelUpText levelUp = new LevelUpText();

		public BattleEndSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("showGains") ||
				data.Contains<DataObject>("end") ||
				data.Contains<DataObject>("victoryGains"))
			{
				SimpleLootDialogueSettings tmpSettings = new SimpleLootDialogueSettings();
				this.loot = new LootDialogueSettings[] { new LootDialogueSettings() };
				this.loot[0].settings = tmpSettings;
				this.loot[0].settings.SetData(data);
				this.loot[0].type = this.loot[0].settings.GetType().ToString();

				DataObject tmpData = data.GetFile("victoryGains");
				if(tmpData != null)
				{
					tmpData.Get("showGains", ref tmpSettings.showBattleGains);
				}
				tmpData = data.GetFile("combatantGains");
				if(tmpData != null)
				{
					tmpData.Get("showGains", ref tmpSettings.showCombatantGains);
				}
				tmpData = data.GetFile("levelUp");
				if(tmpData != null)
				{
					tmpData.Get("showLevelUp", ref tmpSettings.showLevelUpNotification);
					tmpSettings.levelUpNotification.SetData(tmpData);
				}
				tmpData = data.GetFile("end");
				if(tmpData != null)
				{
					bool tmp = false;
					tmpData.Get("useLevelUpBox", ref tmp);
					if(tmp)
					{
						tmpData.Get("levelUpBoxID", ref tmpSettings.levelUpNotification.guiBoxID);
					}
					else
					{
						tmpData.Get("guiBoxID", ref tmpSettings.levelUpNotification.guiBoxID);
					}

					data.Get("useTitle", ref tmpSettings.levelUpNotification.useTitle);
					if(tmpSettings.levelUpNotification.useTitle)
					{
						data.Get("title", out tmpSettings.levelUpNotification.title);
					}
				}
			}
			if(data.Contains<bool>("showGains"))
			{
				this.levelUp.SetData(data);
			}
			if(data.Contains<string>("lootDialogueType"))
			{
				this.loot = new LootDialogueSettings[] { new LootDialogueSettings() };
				data.Get("lootDialogueType", ref this.loot[0].type);
				this.loot[0].EditorAutoSetup("settings");
				this.loot[0].settings.SetData(data.GetFile("lootDialogue"));
			}
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "battleEnd"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}


		/*
		============================================================================
		Loot dialogue functions
		============================================================================
		*/
		/// <summary>
		/// Collects the current battle loot.
		/// </summary>
		/// <param name="collectLoot">Loot will be collected (e.g. items, equipment, etc.).</param>
		/// <param name="collectExp">Experience and 'Normal' type status value rewards will be collected.</param>
		/// <param name="showGains">The loot dialogue will be displayed.</param>
		/// <param name="autoClose">The auto close time for the loot dialoge, use a value below 0 to not use auto closing.</param>
		/// <param name="autoCloseControlable"><c>true</c> if auto close loot dialogues can still be accepted to close them sooner.</param>
		/// <param name="useItemBox">Store the loot into an item box.</param>
		/// <param name="itemBoxAddType">Use the item stacking options when storing loot in an item box.</param>
		/// <param name="itemBoxID">The box ID of the item box.</param>
		/// <param name="baseEvent">The event that started the loot collection, or <c>null</c> if no event was used or should be notified.</param>
		/// <param name="next">The index of the event node that should be started after the loot collection finished.</param>
		/// <param name="immediateCollection"><c>true</c> if this loot collection is an immediate collection (i.e. not at the end of the battle).</param>
		public void CollectGains(bool collectLoot, bool collectExp,
			bool showGains, float autoClose, bool autoCloseControlable,
			bool useItemBox, bool itemBoxAddType, string itemBoxID,
			BaseEvent baseEvent, int next, bool immediateCollection)
		{
			for(int i = 0; i < this.loot.Length; i++)
			{
				if(this.loot[i].CheckOutcome(immediateCollection))
				{
					this.loot[i].settings.CollectGains(collectLoot, collectExp,
						showGains, autoClose, autoCloseControlable,
						useItemBox, itemBoxAddType, itemBoxID,
						baseEvent, next);
					break;
				}
			}
		}

		public void CloseLootDialogues()
		{
			for(int i = 0; i < this.loot.Length; i++)
			{
				this.loot[i].settings.Close();
			}
		}
	}
}
