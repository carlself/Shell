
using UnityEngine;

namespace ORKFramework
{
	public class CraftingRecipesSettings : BaseLanguageSettings<CraftingRecipe>
	{
		public CraftingRecipesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "craftingRecipes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.CraftingRecipe; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.CraftingTypes.GetName(this.data[i].typeID) + "/" + i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}
	}
}
