
using UnityEngine;

namespace ORKFramework
{
	public class FactionsSettings : BaseLanguageSettings<FactionSetting>
	{
		public FactionsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}

		public override void LoadProject(ORKProjectAsset project)
		{
			this.SetData(project.GetData(this.FILENAME).ToDataObject());

			if(this.data.Length == 0)
			{
				this.data = new FactionSetting[] {
					new FactionSetting("Player"),
					new FactionSetting("Enemies"),
					new FactionSetting("Allies")
				};
			}
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "factions"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Faction; }
		}
	}
}

