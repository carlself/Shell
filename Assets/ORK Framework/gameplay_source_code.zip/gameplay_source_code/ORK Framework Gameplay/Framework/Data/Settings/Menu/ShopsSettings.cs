
using UnityEngine;
using ORKFramework.Shop;

namespace ORKFramework
{
	public class ShopsSettings : BaseLanguageSettings<ShopSetting>
	{
		public ShopsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "shops"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Shop; }
		}
	}
}

