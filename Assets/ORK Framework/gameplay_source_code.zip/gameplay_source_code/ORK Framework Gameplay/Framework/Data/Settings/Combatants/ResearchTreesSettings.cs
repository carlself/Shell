﻿
using UnityEngine;

namespace ORKFramework
{
	public class ResearchTreesSettings : BaseLanguageSettings<ResearchTreeSetting>
	{
		public ResearchTreesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "researchTrees"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.ResearchTree; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.ResearchTypes.GetName(this.data[i].researchTypeID) +
						"/" + i + ": " + this.data[i].GetName();
				}
				else
				{
					names[i] = this.data[i].GetName();
				}
			}
			return names;
		}

		public string GetName(int index, int index2)
		{
			ResearchTreeSetting tree = this.Get(index);
			if(tree != null)
			{
				if(index2 >= 0 && index2 < tree.item.Length)
				{
					return tree.GetName(index2);
				}
				else
				{
					return "ResearchTree " + index + ", ResearchItem " + index2 + " not found";
				}
			}
			else
			{
				return "ResearchTree " + index + " not found";
			}
		}

		public string[] GetNames(int index, bool addIndex)
		{
			string[] names = new string[0];
			ResearchTreeSetting tree = this.Get(index);
			if(tree != null)
			{
				names = new string[tree.item.Length];
				for(int i = 0; i < names.Length; i++)
				{
					if(addIndex)
					{
						names[i] = i + ": " + this.GetName(index, i);
					}
					else
					{
						names[i] = this.GetName(index, i);
					}
				}
			}
			return names;
		}

		public string GetShortName(int index, int index2)
		{
			ResearchTreeSetting tree = this.Get(index);
			if(tree != null)
			{
				if(index2 >= 0 && index2 < tree.item.Length)
				{
					return tree.GetShortName(index2);
				}
				else
				{
					return "ResearchTree " + index + ", ResearchItem " + index2 + " not found";
				}
			}
			else
			{
				return "ResearchTree " + index + " not found";
			}
		}

		public string GetDescription(int index, int index2)
		{
			ResearchTreeSetting tree = this.Get(index);
			if(tree != null && index2 >= 0 && index2 < tree.item.Length)
			{
				return tree.GetDescription(index2);
			}
			else
			{
				return "ResearchTree " + index + ", ResearchItem " + index2 + " not found";
			}
		}

		public Texture GetIcon(int index, int index2)
		{
			Texture tex = null;
			ResearchTreeSetting tree = this.Get(index);
			if(tree != null && index2 >= 0 && index2 < tree.item.Length)
			{
				return tree.GetIcon(index2);
			}
			return tex;
		}

		public int ItemCount(int index)
		{
			ResearchTreeSetting list = this.Get(index);
			if(list != null)
			{
				return list.item.Length;
			}
			else
			{
				return 0;
			}
		}
	}
}
