
using UnityEngine;
using UnityEngine.SceneManagement;

/*public class CustomSave
{
	public static void Save(int index, string data)
	{
		// your save handling, gets the XML formatted save data in the 'data' parameter
	}

	public static string Load(int index)
	{
		// your load handling, has to return the saved XML formatted save data
	}

	public static bool Exists(int index)
	{
		// should return true if a save game for save file 'index' exists
	}

	public static void Delete(int index)
	{
		// should delete the save file 'index'
	}
}*/

namespace ORKFramework
{
	public class SaveGameMenuSettings : BaseSettings
	{
		[ORKEditorHelp("Save Slots", "The number of available slots to save the game.\n" +
			"Setting the save slots to 0 will only allow using AUTO save games and retry.", "")]
		[ORKEditorInfo("Save Game Settings", "Base save game settings, " +
			"e.g. number of available save slots, game load screen fading, etc.", "")]
		[ORKEditorLimit(0, false)]
		public int saveSlots = 3;

		[ORKEditorHelp("Auto Save Slots", "The number of available auto save game slots.\n" +
			"The auto save slot used in a running game can optionally be selected at the start of the game.\n" +
			"Using AUTOSAVE in the game (e.g. in save points or events) " +
			"will save to the auto save slot selected at the game's start.\n" +
			"If no auto save slot selection is used when starting a new game, the first auto save slot (0) will be used.", "")]
		[ORKEditorLimit(1, false)]
		public int autoSaveSlots = 1;


		// load game scene load
		[ORKEditorHelp("Load Scene Mode", "Select how the scene of a save game will be loaded:\n" +
			"- Single: Closes all current loaded scenes and loads a scene.\n" +
			"- Additive: Adds the scene to the current loaded scenes.", "")]
		[ORKEditorInfo(separator=true, labelText="Load Scene Settings")]
		public LoadSceneMode loadSceneMode = LoadSceneMode.Single;

		[ORKEditorHelp("Load Async", "Loads the scene of the save game asynchronously in the background.", "")]
		public bool loadAsync = false;


		// data settings
		[ORKEditorHelp("Save To", "Select where the save games will be stored:\n" +
			"- PlayerPrefs: The Unity PlayerPrefs are used.\n" +
			"- File Persistent Data Path: A file is saved using Application.persistentDataPath.\n" +
			"- Custom: A custom save game solution using static functions to save, load and delete save games.\n" +
			"- File Data Path: A file is saved using Application.dataPath.\n" +
			"See the Unity Documentation for more information about where the file will be stored on the different platforms.", "")]
		[ORKEditorInfo(separator=true, labelText="Data Settings")]
		public SaveGameType saveGameType = SaveGameType.FilePersistentDataPath;

		[ORKEditorHelp("Save Folder", "Optionally define a folder that will be used (in the selected data path) to store save games in.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(new string[] { "saveGameType", "saveGameType" },
			new object[] { SaveGameType.FilePersistentDataPath, SaveGameType.FileDataPath },
			needed=Needed.One, endCheckGroup=true)]
		public string saveFolder = "";

		// custom save functions
		[ORKEditorHelp("Class Name", "The name of the class that contains the static functions.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("saveGameType", SaveGameType.Custom)]
		public string className = "";

		[ORKEditorHelp("Save Function Name", "The name of the static save function that will be called.\n" +
			"The function must have an int parameter for the file index and a string parameter for the save data, e.g.:\n" +
			"public static void Save(int index, string data)", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string saveFunctionName = "";

		[ORKEditorHelp("Load Function Name", "The name of the static load function that will be called.\n" +
			"The function must have an int parameter for the file index and return a string containing the save data, e.g.:\n" +
			"public static string Load(int index)", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string loadFunctionName = "";

		[ORKEditorHelp("Exists Function Name", "The name of the static exists function that will be called.\n" +
			"The function must have an int parameter for the file index and return a bool indicating if the file exists (true) or not (false), e.g.:\n" +
			"public static bool Exists(int index)", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string existsFunctionName = "";

		[ORKEditorHelp("Delete Function Name", "The name of the static delete function that will be called.\n" +
			"The function must have an int parameter for the file index, e.g.:\n" +
			"public static void Delete(int index)", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string deleteFunctionName = "";

		[ORKEditorHelp("Encrypt Data", "The save game data will be encrypted.\n" +
			"If not selected, the data is saved in plain text.", "")]
		public bool encryptData = false;

		// game settings
		[ORKEditorHelp("Language", "The language will also be stored outside of save games in the PlayerPrefs.", "")]
		[ORKEditorInfo(separator=true, labelText="Store Game Options (in PlayerPrefs)")]
		public bool storeOptionLanguage = false;

		[ORKEditorHelp("Global Volume", "The global volume will also be stored outside of save games in the PlayerPrefs.", "")]
		public bool storeOptionGlobalVolume = false;

		[ORKEditorHelp("Sound Volume", "The sound volume will also be stored outside of save games in the PlayerPrefs.", "")]
		public bool storeOptionSoundVolume = false;

		[ORKEditorHelp("Music Volume", "The music volume will also be stored outside of save games in the PlayerPrefs.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool storeOptionMusicVolume = false;


		// screen fade out
		[ORKEditorHelp("Fade Out", "The screen will fade out.", "")]
		[ORKEditorInfo("Screen Fade Out", "The screen can fade out before loading the saved scene.", "")]
		public bool useFadeOut = true;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useFadeOut", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings fadeOut = new FadeColorSettings(0.5f, 0, 1);


		// screen fade in
		[ORKEditorHelp("Fade In", "The screen will fade in.", "")]
		[ORKEditorInfo("Screen Fade In", "The screen can fade in after loading the saved scene.", "")]
		public bool useFadeIn = true;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useFadeIn", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings fadeIn = new FadeColorSettings(0.5f, 1, 0);


		// save settings
		[ORKEditorHelp("Statistics", "Game statistics will be saved.", "")]
		[ORKEditorInfo("Save Settings", "Select the data of a running game that will be saved in a save game.", "",
			labelText="Game Data")]
		public bool saveStatistics = true;

		[ORKEditorHelp("Game Time", "The current game time will be saved.", "")]
		public bool saveTime = true;

		[ORKEditorHelp("Groups", "The player groups (i.e. all combatants and their current levels, equipment, etc.) will be saved.", "")]
		public bool saveGroups = true;

		[ORKEditorHelp("Factions", "The factions (i.e. the sympathy values.) will be saved.", "")]
		public bool saveFactions = true;

		[ORKEditorHelp("Logs", "The learned logs will be saved.", "")]
		public bool saveLogs = true;

		[ORKEditorHelp("Quests", "The learned/finished quests will be saved.", "")]
		public bool saveQuests = true;

		[ORKEditorHelp("Bestiary", "The learned enemy combatant information will be saved.", "")]
		public bool saveBestiary = true;

		[ORKEditorHelp("Battle Gains", "The uncollected battle gains will be saved.", "")]
		public bool saveBattleGains = true;

		[ORKEditorHelp("Max Battle Group/Reserve", "The maximum battle group/reserve size of player groups will be saved.", "")]
		public bool savePlayerMaxBattleGroupSize = true;

		[ORKEditorHelp("Group Positions", "The position of all group members will be saved.", "")]
		[ORKEditorLayout("saveGroups", true)]
		public bool saveGroupPosition = true;

		[ORKEditorHelp("Camera Position", "The position of the camera will be saved.", "")]
		[ORKEditorLayout("saveGroupPosition", true)]
		public bool saveCameraPosition = true;

		[ORKEditorHelp("Music", "Save the currently playing music and playing time.", "")]
		public bool saveMusic = true;

		[ORKEditorHelp("Load Scene", "The scene that will be loaded when loading a game without group positions.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public string saveSceneName = "";

		[ORKEditorHelp("Spawn ID", "The spawn point ID where the group (if saved) will spawn.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public int saveSpawnID = 0;

		[ORKEditorHelp("Block States", "The state of blocked Input Keys, Control Maps and HUDs will be saved.", "")]
		public bool saveBlockStates = false;

		[ORKEditorHelp("HUD Toggle States", "The toggle state of HUDs will be saved.", "")]
		public bool saveHUDToggleStates = false;

		// scene data
		[ORKEditorHelp("Save Item Boxes", "Select how the content of item boxes will be saved (using the box ID of item collectors):\n" +
			"- None: The content wont be saved, i.e. boxes will fill again when reentering a scene.\n" +
			"- Game: The content will be remebered in a running game.\n" +
			"- Save: The content will be saved in a save game.", "")]
		[ORKEditorInfo(separator=true, labelText="Scene Data", isEnumToolbar=true, toolbarWidth=75)]
		public SaveOption boxSaveOption = SaveOption.Save;

		[ORKEditorHelp("Save Items", "Select how collected items will be saved (using the scene ID of item collectors):\n" +
			"- None: Collected items wont be saved, i.e. they will reappear when reentering a scene.\n" +
			"- Game: Collected items will be remebered in a running game.\n" +
			"- Save: Collected items will be saved in a save game.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public SaveOption itemSaveOption = SaveOption.Save;

		[ORKEditorHelp("Auto Remove", "Auto remove collected item data after a defined number of scene changes " +
			"without coming back to the scene.\n" +
			"When returning to the scene, the counter will be reset (if the data wasn't removed already).", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("itemSaveOption", SaveOption.None, elseCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool itemAutoRemove = false;

		[ORKEditorHelp("After Scene Changes", "The number of scene changes before resetting the data.\n" +
			"E.g. setting it to 1 will allow leaving the scene and returning to it (keeping the data), " +
			"but making another scene change to a different scene will remove the data.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout("itemAutoRemove", true, endCheckGroup=true, endGroups=2)]
		public int itemAutoRemoveAfter = 3;

		[ORKEditorHelp("Save Drops", "Select how the item drops will be saved:\n" +
			"- None: Drops wont be saved, i.e. they will be gone when reentering a scene.\n" +
			"- Game: Drops will be remebered in a running game.\n" +
			"- Save: Drops will be saved in a save game.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public SaveOption dropSaveOption = SaveOption.None;

		[ORKEditorHelp("Auto Remove", "Auto remove item drop data after a defined number of scene changes " +
			"without coming back to the scene.\n" +
			"When returning to the scene, the counter will be reset (if the data wasn't removed already).", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("dropSaveOption", SaveOption.None, elseCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool dropAutoRemove = false;

		[ORKEditorHelp("After Scene Changes", "The number of scene changes before resetting the data.\n" +
			"E.g. setting it to 1 will allow leaving the scene and returning to it (keeping the data), " +
			"but making another scene change to a different scene will remove the data.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout("dropAutoRemove", true, endCheckGroup=true, endGroups=2)]
		public int dropAutoRemoveAfter = 3;

		[ORKEditorHelp("Save Battles", "Select how the battles using a scene ID will be saved:\n" +
			"- None: Finished battles wont be saved, i.e. they will reappear when reentering a scene.\n" +
			"- Game: Finished battles will be remebered in a running game.\n" +
			"- Save: Finished battles will be saved in a save game.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public SaveOption battlesSaveOption = SaveOption.Save;

		[ORKEditorHelp("Auto Remove", "Auto remove finished battle data after a defined number of scene changes " +
			"without coming back to the scene.\n" +
			"When returning to the scene, the counter will be reset (if the data wasn't removed already).", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("battlesSaveOption", SaveOption.None, elseCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool battleAutoRemove = false;

		[ORKEditorHelp("After Scene Changes", "The number of scene changes before resetting the data.\n" +
			"E.g. setting it to 1 will allow leaving the scene and returning to it (keeping the data), " +
			"but making another scene change to a different scene will remove the data.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout("battleAutoRemove", true, endCheckGroup=true, endGroups=2)]
		public int battleAutoRemoveAfter = 3;

		[ORKEditorHelp("Save Shops", "Select how the content of shops will be saved (using the shop ID):\n" +
			"- None: The content wont be saved, i.e. shops will reset again when opening them.\n" +
			"- Game: The content will be remebered in a running game.\n" +
			"- Save: The content will be saved in a save game.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public SaveOption shopsSaveOption = SaveOption.Save;

		[ORKEditorHelp("Object Variables", "Select how game variables bound to objects will be saved:\n" +
			"- None: The variables wont be saved, i.e. they wont be used at all.\n" +
			"- Game: The variables will be remebered in a running game.\n" +
			"- Save: The variables will be saved in a save game.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public SaveOption objectVariableOption = SaveOption.Save;

		[ORKEditorHelp("Spawned Combatants", "When using 'Remember Combatants' in 'Combatant Spawner' and 'Add Combatant' components, " +
			"the spawned combatants of the current scene will be saved with the save game:\n" +
			"- None: Spawned combatants aren't saved.\n" +
			"- Current: Only combatants spawned in the current scene are saved.\n" +
			"- All: All stored combatants will be saved (this can massively increase the save file).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public CombatantSaveOption saveSpawnedCombatants = CombatantSaveOption.None;

		[ORKEditorHelp("Auto Remove", "Auto remove spawned combatant data after a defined number of scene changes " +
			"without coming back to the scene.\n" +
			"When returning to the scene, the counter will be reset (if the data wasn't removed already).", "")]
		[ORKEditorInfo(indent=true)]
		public bool combatantAutoRemove = false;

		[ORKEditorHelp("After Scene Changes", "The number of scene changes before resetting the data.\n" +
			"E.g. setting it to 1 will allow leaving the scene and returning to it (keeping the data), " +
			"but making another scene change to a different scene will remove the data.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout("combatantAutoRemove", true, endCheckGroup=true)]
		public int combatantAutoRemoveAfter = 3;

		[ORKEditorHelp("Scene Positions", "Save the stored scene positions of all scenes.", "")]
		public bool saveScenePosition = true;

		[ORKEditorHelp("Scene Name", "Define the name of the scene where auto removal of scene data isn't used.", "")]
		[ORKEditorInfo(hideName=true, setWidth=true, fieldWidth=400)]
		[ORKEditorArray(false, "Add No Auto Remove Scene", "Adds a scene where auto removal of scene data isn't used.", "",
			"Remove", "Removes the scene.", "", isHorizontal=true)]
		public string[] noAutoRemoveScene = new string[0];

		// inventory
		[ORKEditorHelp("Items", "All items in the inventory will be saved.", "")]
		[ORKEditorInfo(separator=true, labelText="Inventory Data")]
		public bool saveItems = true;

		[ORKEditorHelp("Weapons", "All weapons in the inventory will be saved.\n" +
			"Equipped weapons will only be saved if the party is saved.", "")]
		public bool saveWeapons = true;

		[ORKEditorHelp("Armors", "All armors in the inventory will be saved.\n" +
			"Equipped armors will only be saved if the party is saved.", "")]
		public bool saveArmors = true;

		[ORKEditorHelp("Recipes", "All learned crafting recipes will be saved", "")]
		public bool saveRecipes = true;

		[ORKEditorHelp("Money", "The current amount of money will be saved.", "")]
		public bool saveMoney = true;

		[ORKEditorHelp("AI Behaviours", "The currently collected and equipped AI behaviours and AI behaviour slots will be saved.", "")]
		public bool aiBehaviours = true;

		[ORKEditorHelp("AI Rulesets", "The currently collected and equipped AI rulesets and AI ruleset slots will be saved.", "")]
		public bool aiRulesets = true;

		// game variables
		[ORKEditorHelp("Game Variables", "Select which game variables will be saved:\n" +
			"- None: No game variable will be saved.\n" +
			"- Select: Select which game variables will be saved.\n" +
			"- All: All game variables will be saved, but you can exclude specific variables.", "")]
		[ORKEditorInfo(separator=true, labelText="Game Variable Data", callbackAfter="check:gamevariables")]
		public Selector gameVariableSelector = Selector.All;

		[ORKEditorHelp("Game Variable Key", "The key (name) of the game variable.", "")]
		[ORKEditorInfo(endFoldout=true, hideName=true, setWidth=true, fieldWidth=400, isVariableField=true)]
		[ORKEditorArray(false, "Add Game Variable", "Adds a game variable to the list.", "",
			"Remove", "Removes the game variable.", "", isHorizontal=true)]
		[ORKEditorLayout("gameVariableSelector", Selector.None, elseCheckGroup=true, endCheckGroup=true)]
		public string[] gameVariableList = new string[0];


		// file settings
		[ORKEditorHelp("File Name", "This text is used to display the index text of the auto save file.", "")]
		[ORKEditorInfo("File Settings", "Set the content of the file buttons.", "",
			"Save File Name", "This text is used to display the index text of the save file.", "",
			endFoldout=true, expandWidth=true, label=new string[] {"% = file number"})]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] saveFileName = ArrayHelper.CreateArray(ORK.Languages.Count, "%");

		// file button
		[ORKEditorInfo("File Info", "Text displayed for saved save game files.", "",
			endFoldout=true, label=new string[] {
				"% = save/auto file name, %s = save number",
				"%n = player name, %l = player level, %c = player class, %cl = player class level",
				"%a = area name, %t = game time"
		})]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public TextImageContent[] fileInfo = ArrayHelper.CreateArray<TextImageContent>(ORK.Languages.Count,
			new System.Type[] {typeof(string)}, new System.Object[] {"File %"});

		// empty button
		[ORKEditorInfo("Empty File Info", "Text displayed for empty save game slots/files.", "",
			endFoldout=true, endFolds=2, label=new string[] { "% = file number" })]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public TextImageContent[] emptyInfo = ArrayHelper.CreateArray<TextImageContent>(ORK.Languages.Count,
			new System.Type[] {typeof(string)}, new System.Object[] {"Empty %"});


		// auto save
		// auto file name
		[ORKEditorHelp("File Name", "This text is used to display the index text of the auto save file.", "")]
		[ORKEditorInfo("Auto Save Settings", "The game can be automatically saved " +
			"by using 'Auto Save' type save points and 'Auto Save Game' event steps.", "",
			"Auto File Name", "This text is used to display the index text of the auto save file.", "",
			endFoldout=true, expandWidth=true, label=new string[] {"% = auto save slot"})]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] autoFileName = ArrayHelper.CreateArray(ORK.Languages.Count, "AUTO %");

		// auto save message
		[ORKEditorHelp("Show Message", "A message will be displayed when auto saving the game.", "")]
		[ORKEditorInfo("Auto Save Message", "A message can be displayed when auto saving the game.", "")]
		public bool showAutoSaveMessage = false;

		[ORKEditorHelp("GUI Box", "Select the GUI box used to display the message.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("showAutoSaveMessage", true)]
		public int autoBoxID = 0;

		[ORKEditorHelp("Visibility Time (s)", "The time in seconds the message will be displayed.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float autoVisibilityTime = 3;

		[ORKEditorHelp("Message", "The message that will be displayed.", "")]
		[ORKEditorInfo("Auto Save Message", "The message that will be displayed when using auto save.", "",
			endFoldout=true, endFolds=3, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string[] autoSaveMessage = ArrayHelper.CreateArray(ORK.Languages.Count, "Autosave");


		// pause
		[ORKEditorHelp("Pause Game", "The game will be paused while save menus are opened.", "")]
		[ORKEditorInfo("Pause Settings", "Optionally pause the game while displaying save menus.", "")]
		public bool pauseGame = false;

		[ORKEditorHelp("Pause Time", "The game time (play time) will pause when the game is paused.", "")]
		[ORKEditorLayout("pauseGame", true)]
		public bool pauseTime = false;

		[ORKEditorHelp("Freeze Pause", "The game freezes in pause, i.e. animations, movements, etc. will stop.", "")]
		public bool freezePause = false;

		[ORKEditorHelp("Change Time Scale", "Change the time scale while displaying save menus.\n" +
			"This can be used to slow down or speed up the game.", "")]
		[ORKEditorLayout(elseCheckGroup=true)]
		public bool setTimeScale = false;

		[ORKEditorHelp("Set ORK Scale", "Set the ORK Framework time scale - " +
			"it's used only for ORK Framework related things, like battles, events, etc.\n" +
			"If disabled, the Unity time scale will be set, affecting everything in the game.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("setTimeScale", true)]
		public bool setORKScale = false;

		[ORKEditorHelp("Time Scale", "Define the time scale that will be used while displaying the menu screen.\n" +
			"A time scale of 1 is normal speed, 0.5 is half speed, 2 is double speed.\n" +
			"A time scale of 0 will freeze time (same as using freeze pause).", "")]
		[ORKEditorInfo(indent=true, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, false)]
		public float timeScale = 1;


		// save game menu
		[ORKEditorInfo("Save Game Menu", "Settings for the save file selection menu.", "",
			endFoldout=true)]
		public SaveGameChoice saveMenu = new SaveGameChoice();


		// load game menu
		[ORKEditorInfo("Load Game Menu", "Settings for the load file selection menu.", "",
			endFoldout=true)]
		public LoadGameChoice loadMenu = new LoadGameChoice();


		// delete key
		[ORKEditorInfo("Delete File Settings", "Optionally use an input key to delete the currently selected save file " +
			"in 'Save Game Menu' and 'Load Game Menu' dialogues.", "",
			endFoldout=true)]
		public DeleteSaveFileSetting deleteFile = new DeleteSaveFileSetting();


		// save point
		[ORKEditorHelp("Show Choice", "A choice dialogue (save, load, cancel) is displayed when the player " +
			"interacts with a save point.\n" +
			"If not set, the save menu is shown.", "")]
		[ORKEditorInfo("Save Point Settings", "This settings determine the options " +
			"and appearance of the save point dialogue.", "")]
		public bool showSPChoice = true;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("showSPChoice", true, endCheckGroup=true)]
		public SavePointChoice savePoint = new SavePointChoice();

		public SaveGameMenuSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "saveGameMenu"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public GUIContent GetFileInfo()
		{
			return this.fileInfo[ORK.Game.Language].GetContent();
		}

		public GUIContent GetEmptyInfo()
		{
			return this.emptyInfo[ORK.Game.Language].GetContent();
		}

		public string GetSaveName(int index)
		{
			return this.saveFileName[ORK.Game.Language].
				Replace("%", ORK.TextDisplaySettings.numberFormatting.FormatInt(index + 1));
		}


		/*
		============================================================================
		Auto save functions
		============================================================================
		*/
		public void ShowAutoSaveMessage()
		{
			ORK.GUI.CreateInfoBox(this.autoSaveMessage[ORK.Game.Language], "",
				this.autoBoxID, this.autoVisibilityTime, null, null, Vector2.zero).InitIn();
		}

		public string GetAutoName(int index)
		{
			return this.autoFileName[ORK.Game.Language].
				Replace("%", ORK.TextDisplaySettings.numberFormatting.FormatInt(index + 1));
		}


		/*
		============================================================================
		Save file type functions
		============================================================================
		*/
		public bool IsPlayerPrefs
		{
			get { return SaveGameType.PlayerPrefs == this.saveGameType; }
		}

		public bool IsFilePersistentDataPath
		{
			get { return SaveGameType.FilePersistentDataPath == this.saveGameType; }
		}

		public bool IsFileDataPath
		{
			get { return SaveGameType.FileDataPath == this.saveGameType; }
		}

		public bool IsCustom
		{
			get { return SaveGameType.Custom == this.saveGameType; }
		}

		public string GetSavePath()
		{
			if(this.IsFilePersistentDataPath)
			{
				if(string.IsNullOrEmpty(this.saveFolder))
				{
					return Application.persistentDataPath + "/";
				}
				else
				{
					return Application.persistentDataPath + "/" + this.saveFolder + "/";
				}
			}
			else if(this.IsFileDataPath)
			{
				if(string.IsNullOrEmpty(this.saveFolder))
				{
					return Application.dataPath + "/";
				}
				else
				{
					return Application.dataPath + "/" + this.saveFolder + "/";
				}
			}
			return "";
		}


		/*
		============================================================================
		Save data functions
		============================================================================
		*/
		public bool CanSaveGameVariable(string key)
		{
			bool save = Selector.All == this.gameVariableSelector;
			for(int i = 0; i < this.gameVariableList.Length; i++)
			{
				if(this.gameVariableList[i] == key)
				{
					save = !save;
					break;
				}
			}
			return save;
		}

		public bool BlockAutoRemoveSceneData(string sceneName)
		{
			for(int i = 0; i < this.noAutoRemoveScene.Length; i++)
			{
				if(this.noAutoRemoveScene[i] == sceneName)
				{
					return true;
				}
			}
			return false;
		}

		public void SaveMenuPause(bool pause)
		{
			if(pause)
			{
				if(this.pauseGame)
				{
					ORK.Game.PauseGame(true, this.pauseTime, this.freezePause);
				}
				else if(this.setTimeScale)
				{
					if(this.setORKScale)
					{
						ORK.Game.TimeScale = this.timeScale;
					}
					else
					{
						ORK.Game.UnityTimeScale = this.timeScale;
					}
				}
			}
			else
			{
				if(this.pauseGame)
				{
					ORK.Game.PauseGame(false, this.pauseTime, this.freezePause);
				}
				else if(this.setTimeScale)
				{
					if(this.setORKScale)
					{
						ORK.Game.ResetTimeScale();
					}
					else
					{
						ORK.Game.ResetUnityTimeScale();
					}
				}
			}
		}
	}
}
