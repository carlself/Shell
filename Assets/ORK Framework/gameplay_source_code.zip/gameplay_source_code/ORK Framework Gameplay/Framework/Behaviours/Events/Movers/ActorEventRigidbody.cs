
using ORKFramework;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class ActorEventRigidbody : MonoBehaviour
	{
		private Rigidbody actor;
		
		private Rigidbody2D actor2D;
	
		private float time;

		private float time2;
		
		private Vector3 force;
		
		private Vector3 forcePosition;
		
		private Vector2 force2D;
		
		private Vector2 forcePosition2D;
		
		private float torque2D;
		
		private ForceMode forceMode;
		
		
		// modes
		private bool is2D = false;
		
		private bool limitTime = false;
		
		private bool addForce = false;
		
		private bool addRelativeForce = false;
		
		private bool addForceAtPosition = false;
		
		private bool addTorque = false;
	
		public void Stop()
		{
			this.actor = null;
			
			this.is2D = false;
			this.limitTime = false;
			this.addForce = false;
			this.addRelativeForce = false;
			this.addForceAtPosition = false;
			this.addTorque = false;
			
			this.time = 0;
			this.time2 = 0;
		}
		
		
		/*
		============================================================================
		3D functions
		============================================================================
		*/
		public void AddForce(Rigidbody actor, Vector3 force, ForceMode forceMode, bool relative, float time)
		{
			this.Stop();
		
			this.actor = actor;
			this.force = force;
			this.forceMode = forceMode;
			
			if(time > 0)
			{
				this.limitTime = true;
				this.time = 0;
				this.time2 = time;
			}
			else
			{
				this.limitTime = false;
			}
			
			if(relative)
			{
				this.addRelativeForce = true;
			}
			else
			{
				this.addForce = true;
			}
		}
		
		public void AddForceAtPosition(Rigidbody actor, Vector3 force, 
			Vector3 forcePosition, ForceMode forceMode, float time)
		{
			this.Stop();
		
			this.actor = actor;
			this.force = force;
			this.forcePosition = forcePosition;
			this.forceMode = forceMode;
			
			if(time > 0)
			{
				this.limitTime = true;
				this.time = 0;
				this.time2 = time;
			}
			else
			{
				this.limitTime = false;
			}
			
			this.addForceAtPosition = true;
		}
		
		public void AddTorque(Rigidbody actor, Vector3 force, ForceMode forceMode, float time)
		{
			this.Stop();
		
			this.actor = actor;
			this.force = force;
			this.forceMode = forceMode;
			
			if(time > 0)
			{
				this.limitTime = true;
				this.time = 0;
				this.time2 = time;
			}
			else
			{
				this.limitTime = false;
			}
			
			this.addTorque = true;
		}
		
		
		/*
		============================================================================
		2D functions
		============================================================================
		*/
		public void AddForce2D(Rigidbody2D actor2D, Vector2 force2D, float time)
		{
			this.Stop();
			this.is2D = true;
		
			this.actor2D = actor2D;
			this.force2D = force2D;
			
			if(time > 0)
			{
				this.limitTime = true;
				this.time = 0;
				this.time2 = time;
			}
			else
			{
				this.limitTime = false;
			}
			
			this.addForce = true;
		}
		
		public void AddForceAtPosition2D(Rigidbody2D actor2D, Vector3 force2D, 
			Vector3 forcePosition2D, float time)
		{
			this.Stop();
			this.is2D = true;
		
			this.actor2D = actor2D;
			this.force2D = force2D;
			this.forcePosition2D = forcePosition2D;
			
			if(time > 0)
			{
				this.limitTime = true;
				this.time = 0;
				this.time2 = time;
			}
			else
			{
				this.limitTime = false;
			}
			
			this.addForceAtPosition = true;
		}
		
		public void AddTorque2D(Rigidbody2D actor2D, float torque, float time)
		{
			this.Stop();
			this.is2D = true;
		
			this.actor2D = actor2D;
			this.torque2D = torque;
			
			if(time > 0)
			{
				this.limitTime = true;
				this.time = 0;
				this.time2 = time;
			}
			else
			{
				this.limitTime = false;
			}
			
			this.addTorque = true;
		}
	
	
		/*
		============================================================================
		Update functions
		============================================================================
		*/
		void FixedUpdate()
		{
			if(!ORK.Game.Paused)
			{
				if(this.is2D && this.actor2D != null)
				{
					if(this.addForce)
					{
						this.actor2D.AddForce(this.force2D);
						
						if(this.limitTime)
						{
							this.time += ORK.Game.DeltaTime;
							if(this.time >= this.time2)
							{
								this.addForce = false;
							}
						}
					}
					else if(this.addForceAtPosition)
					{
						this.actor2D.AddForceAtPosition(this.force2D, this.forcePosition2D);
						
						if(this.limitTime)
						{
							this.time += ORK.Game.DeltaTime;
							if(this.time >= this.time2)
							{
								this.addForceAtPosition = false;
							}
						}
					}
					else if(this.addTorque)
					{
						this.actor2D.AddTorque(this.torque2D);
						
						if(this.limitTime)
						{
							this.time += ORK.Game.DeltaTime;
							if(this.time >= this.time2)
							{
								this.addTorque = false;
							}
						}
					}
				}
				else if(this.actor != null)
				{
					if(this.addForce)
					{
						this.actor.AddForce(this.force, this.forceMode);
						
						if(this.limitTime)
						{
							this.time += ORK.Game.DeltaTime;
							if(this.time >= this.time2)
							{
								this.addForce = false;
							}
						}
					}
					else if(this.addRelativeForce)
					{
						this.actor.AddRelativeForce(this.force, this.forceMode);
						
						if(this.limitTime)
						{
							this.time += ORK.Game.DeltaTime;
							if(this.time >= this.time2)
							{
								this.addRelativeForce = false;
							}
						}
					}
					else if(this.addForceAtPosition)
					{
						this.actor.AddForceAtPosition(this.force, this.forcePosition, this.forceMode);
						
						if(this.limitTime)
						{
							this.time += ORK.Game.DeltaTime;
							if(this.time >= this.time2)
							{
								this.addForceAtPosition = false;
							}
						}
					}
					else if(this.addTorque)
					{
						this.actor.AddTorque(this.force, this.forceMode);
						
						if(this.limitTime)
						{
							this.time += ORK.Game.DeltaTime;
							if(this.time >= this.time2)
							{
								this.addTorque = false;
							}
						}
					}
				}
			}
		}
	}
}
