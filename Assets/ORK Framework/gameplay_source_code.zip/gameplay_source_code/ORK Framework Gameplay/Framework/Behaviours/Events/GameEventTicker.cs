
using UnityEngine;
using ORKFramework;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	public class GameEventTicker : MonoBehaviour
	{
		private List<RunningEvent> runningEvents = new List<RunningEvent>();

		public void StartEvent(ORKGameEvent eventAsset, IEventStarter starter,
			object startingObject, SelectedDataHandler selectedData, bool inPause)
		{
			if(eventAsset != null)
			{
				new RunningEvent(eventAsset, starter, startingObject,
					selectedData, inPause);
			}
			else if(ComponentHelper.IsAlive(starter))
			{
				starter.EventEnded();
				GameObject.Destroy(this);
			}
		}

		public void StartEvent(ORKGameEvent eventAsset,
			object startingObject, SelectedDataHandler selectedData,
			bool inPause, Notify finishedCallback)
		{
			if(eventAsset != null)
			{
				new RunningEvent(eventAsset, startingObject,
					selectedData, inPause, finishedCallback);
			}
			else if(finishedCallback != null)
			{
				finishedCallback();
				GameObject.Destroy(this);
			}
		}

		public void StartEvent(ORKGameEvent eventAsset,
			object eventObject, object startingObject,
			SelectedDataHandler selectedData, VariableHandler localVariables,
			bool inPause, Notify finishedCallback)
		{
			if(eventAsset != null)
			{
				new RunningEvent(eventAsset, eventObject, startingObject,
					selectedData, localVariables, inPause, finishedCallback);
			}
			else if(finishedCallback != null)
			{
				finishedCallback();
				GameObject.Destroy(this);
			}
		}

		void Update()
		{
			float t = ORK.Game.DeltaTime;
			for(int i = 0; i < this.runningEvents.Count; i++)
			{
				this.runningEvents[i].Tick(t);
			}
		}

		private void Add(RunningEvent runningEvent)
		{
			this.runningEvents.Add(runningEvent);
		}

		private void Remove(RunningEvent runningEvent)
		{
			this.runningEvents.Remove(runningEvent);
		}

		private class RunningEvent : IEventStarter
		{
			private GameEvent gameEvent;

			private IEventStarter starter;

			private bool inPause = false;

			private Notify finishedCallback;

			public RunningEvent(ORKGameEvent eventAsset, IEventStarter starter,
				object startingObject, SelectedDataHandler selectedData, bool inPause)
			{
				this.starter = starter;
				this.inPause = inPause;

				ORK.GameEventTicker.Add(this);
				this.gameEvent = new GameEvent();
				this.gameEvent.SetData(eventAsset.GetData().ToDataObject());
				this.gameEvent.SelectedData = selectedData;
				this.gameEvent.StartEvent(this, startingObject);
			}

			public RunningEvent(ORKGameEvent eventAsset,
				object startingObject, SelectedDataHandler selectedData,
				bool inPause, Notify finishedCallback)
			{
				this.finishedCallback = finishedCallback;
				this.inPause = inPause;

				ORK.GameEventTicker.Add(this);
				this.gameEvent = new GameEvent();
				this.gameEvent.SetData(eventAsset.GetData().ToDataObject());
				this.gameEvent.SelectedData = selectedData;
				this.gameEvent.StartEvent(this, startingObject);
			}

			public RunningEvent(ORKGameEvent eventAsset,
				object eventObject, object startingObject,
				SelectedDataHandler selectedData, VariableHandler localVariables,
				bool inPause, Notify finishedCallback)
			{
				this.finishedCallback = finishedCallback;
				this.inPause = inPause;

				ORK.GameEventTicker.Add(this);
				this.gameEvent = new GameEvent();
				this.gameEvent.SetData(eventAsset.GetData().ToDataObject());
				this.gameEvent.SelectedData = selectedData;
				this.gameEvent.Variables = localVariables;
				this.gameEvent.StartEvent(this, eventObject, startingObject);
			}

			public void Tick(float t)
			{
				if((this.inPause || !ORK.Game.Paused) &&
					this.gameEvent != null &&
					this.gameEvent.Executing)
				{
					this.gameEvent.Tick(t);
				}
			}

			public void EventEnded()
			{
				if(ComponentHelper.IsAlive(this.starter))
				{
					this.starter.EventEnded();
				}
				else if(this.finishedCallback != null)
				{
					this.finishedCallback();
				}
				ORK.GameEventTicker.Remove(this);
			}

			public void DontDestroy()
			{
				if(ComponentHelper.IsAlive(this.starter))
				{
					this.starter.DontDestroy();
				}
			}

			public void OnSceneLoaded()
			{
				if(ComponentHelper.IsAlive(this.starter))
				{
					this.starter.OnSceneLoaded();
				}
			}

			public GameObject GameObject
			{
				get
				{
					if(ComponentHelper.IsAlive(this.starter))
					{
						return this.starter.GameObject;
					}
					else
					{
						return ORK.Core.GameObject;
					}
				}
			}
		}
	}
}
