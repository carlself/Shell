
using ORKFramework;
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class CameraEventMover : MonoBehaviour
	{
		private Transform cam;

		private Camera cameraComponent;

		private float time;

		private float time2;


		// mover
		private bool running = false;

		private CameraPosition camPos;

		private Transform target;

		private Function interpolate;

		private Vector3 startPos;

		private Vector3 distancePos;

		private Quaternion startRot;

		private Quaternion endRot;

		private float startFoV;

		private float distanceFov;


		// rotater
		private bool rotating = false;

		private float rotateSpeed ;

		private Vector3 rotationAxis;

		public void Stop()
		{
			this.running = false;
			this.rotating = false;
		}

		public void SetTargetData(CameraPosition cp, Transform camera, Transform target, EaseType et, float t)
		{
			this.Stop();

			this.camPos = cp;
			this.cam = camera;
			this.cameraComponent = this.cam.GetComponent<Camera>();
			this.target = target;
			this.interpolate = Interpolate.Ease(et);
			this.time = 0;
			this.time2 = t;

			Transform tmp = new GameObject().transform;
			tmp.SetPositionAndRotation(camera.position, camera.rotation);
			this.camPos.Use(tmp, this.target);

			this.startPos = this.cam.position;
			this.distancePos = tmp.position - this.startPos;
			this.startRot = this.cam.rotation;
			this.endRot = tmp.rotation;
			if(this.cameraComponent != null)
			{
				this.startFoV = this.cameraComponent.fieldOfView;
			}
			this.distanceFov = this.camPos.fieldOfView - this.startFoV;
			UnityWrapper.Destroy(tmp.gameObject);

			this.running = true;
		}

		public void SetTargetData(Vector3 pos, Quaternion rot, float fov, Transform camera, EaseType et, float t)
		{
			this.Stop();

			this.cam = camera;
			this.cameraComponent = this.cam.GetComponent<Camera>();
			this.interpolate = Interpolate.Ease(et);
			this.time = 0;
			this.time2 = t;
			this.camPos = null;

			this.startPos = this.cam.position;
			this.distancePos = pos - this.startPos;
			this.startRot = this.cam.rotation;
			this.endRot = rot;
			if(this.cameraComponent != null)
			{
				this.startFoV = this.cameraComponent.fieldOfView;
			}
			this.distanceFov = fov - this.startFoV;
			this.running = true;
		}

		public void CameraRotate(Transform camera, Transform target, Vector3 axes, float t, float speed)
		{
			this.Stop();

			this.cam = camera;
			this.cameraComponent = this.cam.GetComponent<Camera>();
			this.target = target;
			this.rotationAxis = axes;
			this.time = 0;
			this.time2 = t;
			this.rotateSpeed = speed;

			this.rotating = true;
		}

		void Update()
		{
			if(this.cam != null &&
				!ORK.Game.Paused)
			{
				if(this.running)
				{
					this.time += ORK.Game.DeltaTime;
					this.cam.SetPositionAndRotation(
						Interpolate.Ease(this.interpolate, this.startPos, this.distancePos, this.time, this.time2),
						Interpolate.Ease(this.interpolate, this.startRot, this.endRot, this.time, this.time2));
					if(this.cameraComponent != null)
					{
						this.cameraComponent.fieldOfView = Interpolate.Ease(this.interpolate, this.startFoV, this.distanceFov, this.time, this.time2);
					}
					if(this.time >= this.time2)
					{
						this.running = false;
					}
				}
				else if(this.rotating)
				{
					if(this.target != null)
					{
						float t = ORK.Game.DeltaTime;
						this.time += t;
						this.cam.RotateAround(this.target.position, this.rotationAxis, this.rotateSpeed * t);
						if(this.time >= this.time2)
						{
							this.rotating = false;
						}
					}
					else
					{
						this.rotating = false;
					}
				}
			}
		}
	}
}
