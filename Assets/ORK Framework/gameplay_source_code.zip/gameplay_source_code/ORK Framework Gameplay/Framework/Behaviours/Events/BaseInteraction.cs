
using ORKFramework;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	public abstract class BaseInteraction : BaseConditionComponent
	{
		// start type
		public EventStartType startType = EventStartType.None;

		public bool inBlockedControl = false;

		public string customType = "";


		// auto start
		public float autoStartAfter = 0;


		// click/touch interaction
		public bool allowClick = true;

		public bool overrideClickDistance = false;

		public float maxClickDistance = 3;


		// move to interaction
		public bool useMoveToInteraction = true;

		public GameObject destinationObject;

		public bool overrideInteractionRadius = false;

		public float interactionRadius = 1;

		public bool overrideStopDistance = false;

		public float stopDistance = 1;

		public bool overrideMoveToSpeed = false;

		public MoveSpeed moveToSpeed;


		// key press interaction
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int keyToPress = 0;

		public bool keyPressInTrigger = false;

		public bool keyPressWhileColliding = false;


		// drop interaction
		public EventDropType dropType = EventDropType.Item;

		public ItemGainSimple dropItem = new ItemGainSimple();

		public AbilitySelection dropAbility = new AbilitySelection();

		public bool consumeDrop = false;


		// trigger
		public bool startByCollider = true;

		public bool startByTrigger = true;


		// trigger/collider
		public bool startByRootObject = false;

		public bool useOtherObject = false;

		public EventStartObject startObjectCheck;


		// orientation settings
		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		public bool useFront = true;

		public bool useBack = true;

		public bool useLeft = true;

		public bool useRight = true;


		// ingame
		protected int isInTrigger = 0;

		protected int isColliding = 0;

		protected bool eventStarted = false;

		protected bool registered = false;

		protected IShortcut droppedShortcut;


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		protected virtual void OnEnable()
		{
			if(!this.registered && ORK.Instantiated)
			{
				ORK.Game.Interactions.Add(this);
				this.registered = true;
			}
		}

		protected virtual void OnDisable()
		{
			if(this.registered && ORK.Instantiated)
			{
				ORK.Game.Interactions.Remove(this);
				this.registered = false;
			}
		}

		public bool EventStarted
		{
			get { return this.eventStarted; }
		}

		public float MoveDestinationOffset
		{
			get
			{
				return (this.overrideInteractionRadius ?
						this.interactionRadius :
						ORK.GameControls.interaction.moveToInteraction.defaultInteractionRadius) +
					(this.overrideStopDistance ?
						this.stopDistance :
						ORK.GameControls.interaction.moveToInteraction.defaultStopDistance);
			}
		}


		/*
		============================================================================
		Interaction type functions
		============================================================================
		*/
		public abstract InteractionType Type
		{
			get;
		}

		/*
		============================================================================
		Start event functions
		============================================================================
		*/
		public IEnumerator StartEvent(GameObject startingObject, float delay)
		{
			yield return new WaitForSeconds(delay);
			this.StartEvent(startingObject);
		}

		public virtual void StartEvent(GameObject startingObject)
		{

		}


		/*
		============================================================================
		Auto start functions
		============================================================================
		*/
		protected override void Start()
		{
			if(!this.CheckAutoDestroy())
			{
				this.AutoStart();
			}
		}

		protected void AutoStart()
		{
			if(EventStartType.Autostart == this.startType &&
				this.CheckConditions())
			{
				this.DoAutoStart();
			}
		}

		protected void DoAutoStart()
		{
			if(this.autoStartAfter > 0)
			{
				this.StartCoroutine(this.StartEvent(this.gameObject, this.autoStartAfter));
			}
			else
			{
				this.StartEvent(this.gameObject);
			}
		}


		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		public virtual bool CanInteract(EventStartType type, GameObject startingObject)
		{
			return this.startType == type &&
				(this.inBlockedControl || ORK.Control.CanInteract) &&
				this.CheckOrientation(startingObject) &&
				this.CheckConditions() && this.gameObject.activeInHierarchy;
		}

		public bool CheckOrientation(GameObject gameObject)
		{
			if(gameObject != null)
			{
				Orientation orientation = VectorHelper.GetOrientation(
					this.transform, gameObject.transform, this.horizontalPlane);

				return Orientation.None == orientation ||
					(Orientation.Front == orientation && this.useFront) ||
					(Orientation.Back == orientation && this.useBack) ||
					(Orientation.Left == orientation && this.useLeft) ||
					(Orientation.Right == orientation && this.useRight);
			}
			return true;
		}

		protected void StartMoveToInteraction(GameObject player)
		{
			if(player != null &&
				ORK.GameControls.interaction.moveToInteraction.useMoveToInteraction &&
				this.useMoveToInteraction)
			{
				MoveToInteractionComponent comp = player.GetComponent<MoveToInteractionComponent>();
				if(comp == null)
				{
					comp = player.AddComponent<MoveToInteractionComponent>();
					comp.Init(ORK.Game.ActiveGroup.Leader);
				}
				comp.MoveToInteraction(this);
			}
			else
			{
				this.StartEvent(ORK.Game.GetPlayer());
			}
		}

		public virtual bool Interact()
		{
			if(this.CanInteract(EventStartType.Interact, ORK.Game.GetPlayer()))
			{
				this.StartMoveToInteraction(ORK.Game.GetPlayer());
				return true;
			}
			return false;
		}

		public virtual bool TouchInteract()
		{
			if(this.CanInteract(EventStartType.Interact, ORK.Game.GetPlayer()) && this.allowClick)
			{
				GameObject player = ORK.Game.GetPlayer();

				float clickDistance = this.overrideClickDistance ?
					this.maxClickDistance : ORK.GameControls.interaction.maxClickDistance;

				if(clickDistance == -1 ||
					(player != null && clickDistance > 0 &&
					Vector3.Distance(player.transform.position, this.transform.position) < clickDistance))
				{
					this.StartMoveToInteraction(player);
					return true;
				}
			}
			return false;
		}

		public virtual bool DropInteract(DragInfo drag)
		{
			if(this.CanInteract(EventStartType.Drop, ORK.Game.GetPlayer()) &&
				this.CheckDrop(drag))
			{
				this.StartEvent(ORK.Game.GetPlayer());
				this.droppedShortcut = null;
				return true;
			}
			return false;
		}

		public bool CheckDrop(DragInfo drag)
		{
			ShortcutHUDWrapper wrapper;
			if(drag != null &&
				drag.IsShortcut(out wrapper))
			{
				if(EventDropType.Item == this.dropType)
				{
					if(this.dropItem.CheckDropInteract(wrapper.Shortcut))
					{
						if(this.consumeDrop && this.dropItem.CheckChance())
						{
							ORK.Game.ActiveGroup.Inventory.RemoveAccess(wrapper.Shortcut,
								this.dropItem.quantity, true, true);
						}
						if(drag.Origin != null)
						{
							drag.Origin.Dropped(drag);
						}
						this.droppedShortcut = wrapper.Shortcut;
						return true;
					}
				}
				else if(EventDropType.Ability == this.dropType)
				{
					if(this.dropAbility.CheckDropInteract(wrapper.Shortcut))
					{
						if(drag.Origin != null)
						{
							drag.Origin.Dropped(drag);
						}
						this.droppedShortcut = wrapper.Shortcut is AbilityLinkShortcut ?
							((AbilityLinkShortcut)wrapper.Shortcut).Shortcut :
							wrapper.Shortcut;
						return true;
					}
				}
				else if(EventDropType.AnyItem == this.dropType)
				{
					if(wrapper.Shortcut is IInventoryShortcut)
					{
						if(drag.Origin != null)
						{
							drag.Origin.Dropped(drag);
						}
						this.droppedShortcut = wrapper.Shortcut;
						return true;
					}
				}
				else if(EventDropType.AnyAbility == this.dropType)
				{
					if(wrapper.Shortcut is AbilityShortcut ||
						wrapper.Shortcut is AbilityLinkShortcut)
					{
						if(drag.Origin != null)
						{
							drag.Origin.Dropped(drag);
						}
						this.droppedShortcut = wrapper.Shortcut is AbilityLinkShortcut ?
							((AbilityLinkShortcut)wrapper.Shortcut).Shortcut :
							wrapper.Shortcut;
						return true;
					}
				}
				else if(EventDropType.Any == this.dropType)
				{
					if(drag.Origin != null)
					{
						drag.Origin.Dropped(drag);
					}
					this.droppedShortcut = wrapper.Shortcut;
					return true;
				}
			}
			return false;
		}

		public bool CheckStartObject(GameObject gameObject)
		{
			return gameObject != null &&
				((!this.useOtherObject &&
					(gameObject == ORK.Game.GetPlayer() ||
						(ORK.Game.GetPlayer() != null &&
						gameObject.transform.root == ORK.Game.GetPlayer().transform.root))) ||
				(this.useOtherObject && this.startObjectCheck.CheckObject(gameObject)));
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		void OnTriggerEnter(Collider other)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject || other.transform == other.transform.root) &&
				((this.startByCollider && !other.isTrigger) ||
					(this.startByTrigger && other.isTrigger)) &&
				this.CheckStartObject(other.gameObject))
			{
				this.isInTrigger++;
				if(this.CanInteract(EventStartType.TriggerEnter, other.gameObject))
				{
					this.StartEvent(other.gameObject);
				}
			}
		}

		void OnTriggerExit(Collider other)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject ||
					other.transform == other.transform.root) &&
				((this.startByCollider && !other.isTrigger) ||
					(this.startByTrigger && other.isTrigger)) &&
				this.CheckStartObject(other.gameObject))
			{
				this.isInTrigger--;
				if(this.CanInteract(EventStartType.TriggerExit, other.gameObject))
				{
					this.StartEvent(other.gameObject);
				}
			}
		}

		void OnTriggerStay(Collider other)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject ||
					other.transform == other.transform.root) &&
				((this.startByCollider && !other.isTrigger) ||
					(this.startByTrigger && other.isTrigger)) &&
				this.CheckStartObject(other.gameObject))
			{
				if(this.CanInteract(EventStartType.TriggerStay, other.gameObject))
				{
					this.StartEvent(other.gameObject);
				}
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		void OnTriggerEnter2D(Collider2D other)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject ||
					other.transform == other.transform.root) &&
				((this.startByCollider && !other.isTrigger) ||
					(this.startByTrigger && other.isTrigger)) &&
				this.CheckStartObject(other.gameObject))
			{
				this.isInTrigger++;
				if(this.CanInteract(EventStartType.TriggerEnter, other.gameObject))
				{
					this.StartEvent(other.gameObject);
				}
			}
		}

		void OnTriggerExit2D(Collider2D other)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject ||
					other.transform == other.transform.root) &&
				((this.startByCollider && !other.isTrigger) ||
					(this.startByTrigger && other.isTrigger)) &&
				this.CheckStartObject(other.gameObject))
			{
				this.isInTrigger--;
				if(this.CanInteract(EventStartType.TriggerExit, other.gameObject))
				{
					this.StartEvent(other.gameObject);
				}
			}
		}

		void OnTriggerStay2D(Collider2D other)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject ||
					other.transform == other.transform.root) &&
				((this.startByCollider && !other.isTrigger) ||
					(this.startByTrigger && other.isTrigger)) &&
				this.CheckStartObject(other.gameObject))
			{
				if(this.CanInteract(EventStartType.TriggerStay, other.gameObject))
				{
					this.StartEvent(other.gameObject);
				}
			}
		}


		/*
		============================================================================
		Collision functions
		============================================================================
		*/
		void OnCollisionEnter(Collision collision)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject ||
					collision.transform == collision.transform.root) &&
				this.CheckStartObject(collision.gameObject))
			{
				this.isColliding++;
				if(this.CanInteract(EventStartType.CollisionEnter, collision.gameObject))
				{
					this.StartEvent(collision.gameObject);
				}
			}
		}

		void OnCollisionExit(Collision collision)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject ||
					collision.transform == collision.transform.root) &&
				this.CheckStartObject(collision.gameObject))
			{
				this.isColliding--;
				if(this.CanInteract(EventStartType.CollisionExit, collision.gameObject))
				{
					this.StartEvent(collision.gameObject);
				}
			}
		}

		void OnCollisionStay(Collision collision)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject ||
					collision.transform == collision.transform.root) &&
				this.CheckStartObject(collision.gameObject))
			{
				if(this.CanInteract(EventStartType.CollisionStay, collision.gameObject))
				{
					this.StartEvent(collision.gameObject);
				}
			}
		}


		/*
		============================================================================
		Collision2D functions
		============================================================================
		*/
		void OnCollisionEnter2D(Collision2D collision)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject ||
					collision.transform == collision.transform.root) &&
				this.CheckStartObject(collision.gameObject))
			{
				this.isColliding++;
				if(this.CanInteract(EventStartType.CollisionEnter, collision.gameObject))
				{
					this.StartEvent(collision.gameObject);
				}
			}
		}

		void OnCollisionExit2D(Collision2D collision)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject ||
					collision.transform == collision.transform.root) &&
				this.CheckStartObject(collision.gameObject))
			{
				this.isColliding--;
				if(this.CanInteract(EventStartType.CollisionExit, collision.gameObject))
				{
					this.StartEvent(collision.gameObject);
				}
			}
		}

		void OnCollisionStay2D(Collision2D collision)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject ||
					collision.transform == collision.transform.root) &&
				this.CheckStartObject(collision.gameObject))
			{
				if(this.CanInteract(EventStartType.CollisionStay, collision.gameObject))
				{
					this.StartEvent(collision.gameObject);
				}
			}
		}


		/*
		============================================================================
		Key functions
		============================================================================
		*/
		protected virtual void Update()
		{
			if(!this.registered)
			{
				this.OnEnable();
			}
			this.KeyPress();
		}

		public virtual void KeyPress()
		{
			if(this.isActiveAndEnabled && !ORK.Game.Paused &&
				this.CanInteract(EventStartType.KeyPress, ORK.Game.GetPlayer()) &&
				ORK.InputKeys.Get(this.keyToPress).GetButton() &&
				(!this.keyPressInTrigger || this.isInTrigger > 0) &&
				(!this.keyPressWhileColliding || this.isColliding > 0))
			{
				this.StartEvent(ORK.Game.GetPlayer());
			}
		}


		/*
		============================================================================
		UI functions
		============================================================================
		*/
		public virtual void UIStart()
		{
			this.UIStart(ORK.Game.GetPlayer());
		}

		public virtual void UIStart(GameObject startingObject)
		{
			if(this.CanInteract(EventStartType.UI, startingObject))
			{
				this.StartEvent(startingObject);
			}
		}


		/*
		============================================================================
		Forward interaction functions
		============================================================================
		*/
		public bool ForwardInteract()
		{
			return this.Interact();
		}

		public bool ForwardTouchInteract()
		{
			return this.TouchInteract();
		}

		public bool ForwardDropInteract(DragInfo drag)
		{
			return this.DropInteract(drag);
		}

		public void ForwardOnTriggerEnter(Collider other)
		{
			this.OnTriggerEnter(other);
		}

		public void ForwardOnTriggerExit(Collider other)
		{
			this.OnTriggerExit(other);
		}

		public void ForwardOnTriggerStay(Collider other)
		{
			this.OnTriggerStay(other);
		}

		public void ForwardOnTriggerEnter2D(Collider2D other)
		{
			this.OnTriggerEnter2D(other);
		}

		public void ForwardOnTriggerExit2D(Collider2D other)
		{
			this.OnTriggerExit2D(other);
		}

		public void ForwardOnTriggerStay2D(Collider2D other)
		{
			this.OnTriggerStay2D(other);
		}

		public void ForwardOnCollisionEnter(Collision collision)
		{
			this.OnCollisionEnter(collision);
		}

		public void ForwardOnCollisionExit(Collision collision)
		{
			this.OnCollisionExit(collision);
		}

		public void ForwardOnCollisionStay(Collision collision)
		{
			this.OnCollisionStay(collision);
		}

		public void ForwardOnCollisionEnter2D(Collision2D collision)
		{
			this.OnCollisionEnter2D(collision);
		}

		public void ForwardOnCollisionExit2D(Collision2D collision)
		{
			this.OnCollisionExit2D(collision);
		}

		public void ForwardOnCollisionStay2D(Collision2D collision)
		{
			this.OnCollisionStay2D(collision);
		}
	}
}