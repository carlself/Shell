
using ORKFramework;
using ORKFramework.Events;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Events/Save Point")]
	public class SavePoint : BaseInteraction, IEventStarter
	{
		public SavePointType savePointType = SavePointType.SavePoint;

		public bool destroyAfter = false;

		public override void StartEvent(GameObject startingObject)
		{
			this.CancelInvoke("AutoDestroy");
			this.isInvoking = false;

			if(!this.eventStarted)
			{
				this.eventStarted = true;

				if(SavePointType.AutoSave == this.savePointType)
				{
					this.SetVariables();
					ORK.SaveGame.Save(SaveGameHandler.AUTOSAVE_INDEX - ORK.Game.AutoSaveSlot);
					ORK.SaveGame.CreateInfos();
					if(ORK.SaveGameMenu.showAutoSaveMessage)
					{
						ORK.SaveGameMenu.ShowAutoSaveMessage();
					}
					this.EventEnded();
				}
				else if(SavePointType.RetryPoint == this.savePointType)
				{
					this.SetVariables();
					ORK.SaveGame.Save(SaveGameHandler.RETRY_INDEX);
					this.EventEnded();
				}
				else if(SavePointType.SavePoint == this.savePointType &&
					(this.inBlockedControl || ORK.Control.CanInteract))
				{
					ORK.Control.SetBlockControl(1, true);
					ORK.SaveGame.CreateInfos();
					if(ORK.SaveGameMenu.showSPChoice)
					{
						ORK.SaveGameMenu.savePoint.Show(this);
					}
					else
					{
						ORK.SaveGameMenu.saveMenu.Show(null, null, this);
					}
				}
			}
		}

		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "SavePoint.psd");
		}

		public void EventEnded()
		{
			this.eventStarted = false;
			ORK.Control.SetBlockControl(-1, true);
			if(this.destroyAfter)
			{
				UnityWrapper.Destroy(this.gameObject);
			}
		}

		public void DontDestroy()
		{

		}

		public void OnSceneLoaded()
		{

		}

		public GameObject GameObject
		{
			get { return this.gameObject; }
		}


		/*
		============================================================================
		Interaction type functions
		============================================================================
		*/
		public override InteractionType Type
		{
			get { return InteractionType.SavePoint; }
		}
	}
}
