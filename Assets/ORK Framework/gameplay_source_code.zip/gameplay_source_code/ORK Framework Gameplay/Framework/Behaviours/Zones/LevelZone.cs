﻿
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Battles/Level Zone")]
	public class LevelZone : BaseColliderZone, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		private ORKDataFile serialize_settings;


		// in-game
		private Collider collider;

		private Collider2D collider2D;

		protected virtual void Start()
		{
			this.collider = this.GetComponent<Collider>();
			this.collider2D = this.GetComponent<Collider2D>();
			ORK.Game.Scene.AddLevelZone(this);
		}

		protected virtual void OnDestroy()
		{
			ORK.Game.Scene.RemoveLevelZone(this);
		}

		public virtual bool HasCollider
		{
			get { return this.collider != null || this.collider2D != null; }
		}

		public override bool IsWithin(Vector3 point)
		{
			if(this.collider != null)
			{
				point.y = this.collider.bounds.center.y;
				if(this.collider.bounds.Contains(point))
				{
					point.y = this.collider.bounds.max.y + 1;
					RaycastHit hit;
					if(this.collider.Raycast(new Ray(point, -Vector3.up), out hit, this.collider.bounds.size.y))
					{
						return true;
					}
				}
			}
			else if(this.collider2D != null)
			{
				return this.collider2D.OverlapPoint(point);
			}
			return false;
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "LevelZone.psd");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_settings = this.settings.GetData().GetDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_settings != null)
			{
				this.settings.SetData(this.serialize_settings.ToDataObject());
				this.serialize_settings = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			// level settings
			// min level
			[ORKEditorHelp("Use Minimum Level", "Use a minimum level all combatants can have within this level zone.", "")]
			[ORKEditorInfo("Level Settings", "The base level of combatants within this level zone.", "")]
			public bool useMinLevel = false;

			[ORKEditorHelp("Minimum Level", "The minimum level all combatants can have within this level zone.", "")]
			[ORKEditorLimit(1, false)]
			[ORKEditorInfo(indent=true)]
			[ORKEditorLayout("useMinLevel", true, endCheckGroup=true)]
			public int minLevel = 1;

			// max level
			[ORKEditorHelp("Use Maximum Level", "Use a maximum level all combatants can have within this level zone.", "")]
			[ORKEditorInfo(separator=true)]
			public bool useMaxLevel = false;

			[ORKEditorHelp("Minimum Level", "The maximum level all combatants can have within this level zone.", "")]
			[ORKEditorLimit(1, false)]
			[ORKEditorInfo(indent=true)]
			[ORKEditorLayout("useMaxLevel", true, endCheckGroup=true)]
			public int maxLevel = 100;

			// level
			[ORKEditorHelp("Set Levels", "Set the base levels of combatants with in this level zone.\n" +
				"If disabled, combatants will use the level settings they're usually spawned with " +
				"(e.g. from 'Battle' or 'Combatant Spawner' components).", "")]
			[ORKEditorInfo(separator=true)]
			public bool useLevelSettings = true;

			[ORKEditorInfo(endFoldout=true)]
			[ORKEditorLayout("useLevelSettings", true, endCheckGroup=true)]
			public LevelInitSettings levelSettings = new LevelInitSettings();


			// class level settings
			// min level
			[ORKEditorHelp("Use Minimum Level", "Use a minimum class level all combatants can have within this level zone.", "")]
			[ORKEditorInfo("Class Level Settings", "The class level of combatants within this level zone.", "")]
			public bool classUseMinLevel = false;

			[ORKEditorHelp("Minimum Level", "The minimum class level all combatants can have within this level zone.", "")]
			[ORKEditorLimit(1, false)]
			[ORKEditorInfo(indent=true)]
			[ORKEditorLayout("classUseMinLevel", true, endCheckGroup=true)]
			public int classMinLevel = 1;

			// max level
			[ORKEditorHelp("Use Maximum Level", "Use a maximum class level all combatants can have within this level zone.", "")]
			[ORKEditorInfo(separator=true)]
			public bool classUseMaxLevel = false;

			[ORKEditorHelp("Minimum Level", "The maximum class level all combatants can have within this level zone.", "")]
			[ORKEditorLimit(1, false)]
			[ORKEditorInfo(indent=true)]
			[ORKEditorLayout("classUseMaxLevel", true, endCheckGroup=true)]
			public int classMaxLevel = 100;

			// level
			[ORKEditorHelp("Set Levels", "Set the class levels of combatants with in this level zone.\n" +
				"If disabled, combatants will use the level settings they're usually spawned with " +
				"(e.g. from 'Battle' or 'Combatant Spawner' components).", "")]
			[ORKEditorInfo(separator=true)]
			public bool classUseLevelSettings = true;

			[ORKEditorInfo(endFoldout=true)]
			[ORKEditorLayout("classUseLevelSettings", true, endCheckGroup=true)]
			public LevelInitSettings classLevelSettings = new LevelInitSettings();

			public Settings()
			{

			}
		}
	}
}
