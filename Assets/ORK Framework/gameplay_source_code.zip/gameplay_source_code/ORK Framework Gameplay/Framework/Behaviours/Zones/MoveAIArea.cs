﻿
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Move AI/Move AI Area")]
	public class MoveAIArea : BaseColliderZone
	{
		public bool allowMoveAI = false;

		public bool usedInField = true;

		public bool usedInBattle = true;

		protected virtual void Start()
		{
			this.gameObject.layer = 2;
			if(this.GetComponent<Collider>() == null &&
				this.GetComponent<Collider2D>() == null)
			{
				UnityWrapper.Destroy(this.gameObject);
			}
			else
			{
				ORK.Game.Scene.AddMoveAIArea(this);
			}
		}

		protected virtual void OnDestroy()
		{
			ORK.Game.Scene.RemoveMoveAIArea(this);
		}
	}
}
