
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Move AI/No Random Patrol")]
	public class NoRandomPatrol : BaseColliderZone
	{
		protected virtual void Start()
		{
			this.gameObject.layer = 2;
			if(this.GetComponent<Collider>() == null && 
				this.GetComponent<Collider2D>() == null)
			{
				UnityWrapper.Destroy(this.gameObject);
			}
			else
			{
				ORK.Game.Scene.AddNoRandomPatrol(this);
			}
		}

		protected virtual void OnDestroy()
		{
			ORK.Game.Scene.RemoveNoRandomPatrol(this);
		}
	}
}
