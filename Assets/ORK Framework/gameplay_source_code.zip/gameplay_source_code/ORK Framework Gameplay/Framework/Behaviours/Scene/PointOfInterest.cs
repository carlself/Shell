﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Move AI/Point Of Interest")]
	public class PointOfInterest : MonoBehaviour, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		private ORKDataFile serialize_settings;

		protected virtual void Start()
		{
			ORK.Game.Scene.AddPointOfInterest(this);
		}

		protected virtual void OnDestroy()
		{
			ORK.Game.Scene.RemovePointOfInterest(this);
		}

		public Revisit CreateRevisit()
		{
			return new Revisit(this, this.settings.revisitAfter);
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "PointOfInterest.psd");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_settings = this.settings.GetData().GetDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_settings != null)
			{
				this.settings.SetData(this.serialize_settings.ToDataObject());
				this.serialize_settings = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[ORKEditorHelp("Detection Tag", "A combatant can detect this point of interest if at least one detection tag matches.", "")]
			[ORKEditorInfo(expandWidth=true)]
			public string detectionTag = "";


			// game event
			[ORKEditorHelp("Game Event", "Select a game event that will be started when the combatant reaches this point of interest.\n" +
				"The combatant will be used as 'Event Object' actor, the point of interest as 'Starting Object' actor.", "")]
			[ORKEditorInfo(separator=true)]
			public ORKGameEvent gameEvent;

			[ORKEditorHelp("Wait", "Wait for the game event to finish before resuming the move AI.", "")]
			[ORKEditorLayout("gameEvent", null, elseCheckGroup=true, endCheckGroup=true)]
			[ORKEditorInfo(indent=true)]
			public bool waitForEvent = false;


			// visit
			[ORKEditorHelp("Visit Once", "A combatant an only visit this point of interest once.", "")]
			[ORKEditorInfo(separator=true)]
			public bool visitOnce = true;

			[ORKEditorHelp("Revisit After (s)", "The time in seconds after which a combatant can visit/detect this point of interest again.", "")]
			[ORKEditorLimit(0.0f, false)]
			[ORKEditorLayout("visitOnce", false, endCheckGroup=true)]
			public float revisitAfter = 1;


			// stop range
			[ORKEditorHelp("Use Stop Range", "The combatant will stop when being within a defined range to this point of interest." +
				"If disabled, the combatant will stop at the point of interest's position.", "")]
			[ORKEditorInfo(separator=true, labelText="Stop Range")]
			public Range stopRange = new Range(0);


			// own move speed
			[ORKEditorHelp("Own Move Speed", "This point of interest override's the move AI's move speed.", "")]
			[ORKEditorInfo(separator=true, labelText="Move Speed")]
			public bool ownMoveSpeed = false;

			[ORKEditorLayout("ownMoveSpeed", true, endCheckGroup=true, autoInit=true)]
			public MoveSpeed moveSpeed;

			public Settings()
			{

			}

			public bool CheckTag(string[] tags)
			{
				if(tags.Length > 0)
				{
					for(int i = 0; i < tags.Length; i++)
					{
						if(tags[i] == this.detectionTag)
						{
							return true;
						}
					}
					return false;
				}
				else
				{
					return true;
				}
			}
		}

		public class Revisit
		{
			public PointOfInterest poi;

			public float time = -1;

			public Revisit(PointOfInterest poi, float time)
			{
				this.poi = poi;
				this.time = time;
			}
		}
	}
}
