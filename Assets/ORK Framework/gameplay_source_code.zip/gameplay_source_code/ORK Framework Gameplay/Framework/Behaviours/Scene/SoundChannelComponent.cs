﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[AddComponentMenu("ORK Framework/Scenes/Sound Channel")]
	public class SoundChannelComponent : MonoBehaviour
	{
		public int channel = 0;

		public AudioSource audioSource;


		// in-game
		protected bool isRegistered = false;

		protected virtual void Reset()
		{
			this.audioSource = this.GetComponent<AudioSource>();
		}

		protected virtual void OnEnable()
		{
			this.Register();
		}

		protected virtual void Start()
		{
			this.Register();
		}

		protected virtual void Register()
		{
			if(!this.isRegistered &&
				ORK.Initialized &&
				this.audioSource != null)
			{
				this.isRegistered = true;
				ORK.Audio.GetSoundChannel(this.channel).Register(this.audioSource);
			}
		}

		protected virtual void OnDisable()
		{
			if(this.isRegistered)
			{
				this.isRegistered = false;
				if(ORK.Audio != null)
				{
					ORK.Audio.GetSoundChannel(this.channel).Unregister(this.audioSource);
				}
			}
		}

		public virtual bool PlayOneShot(AudioClip clip, float volume)
		{
			if(clip != null)
			{
				if(this.audioSource != null)
				{
					this.audioSource.PlayOneShot(clip,
						volume * ORK.Audio.GetSoundChannel(this.channel).Volume * ORK.Audio.SoundVolume);
				}
				else
				{
					ORK.Audio.GetSoundChannel(this.channel).PlayOneShot(clip, volume);
				}
				return true;
			}
			return false;
		}
	}
}
