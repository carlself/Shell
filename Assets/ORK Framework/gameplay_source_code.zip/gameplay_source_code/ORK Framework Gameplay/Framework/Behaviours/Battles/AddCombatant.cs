
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/Add Combatant")]
	public class AddCombatant : BaseConditionComponent
	{
		public BattleSystemType battleType = BattleSystemType.TurnBased;

		public bool rememberCombatant = false;

		public string spawnerID = "";

		[ORKEditorInfo(ORKDataType.Faction)]
		public int factionID = 0;

		public CombatantInit combatantSetting = new CombatantInit();


		// battle arena
		public GameObject battleComponentObject;

		public bool setBCPos = false;

		public bool setBCRot = false;

		public bool useNearestArena = false;

		public float arenaRange = 20;


		// move AI
		public bool blockMoveAI = false;

		public bool ownMoveAI = false;

		public int moveAIID = 0;


		// waypoint settings
		public bool randomWaypointOrder = false;

		public GameObject[] waypoints = new GameObject[0];


		// in-game
		protected string sceneName = "";

		protected Combatant combatant;

		protected override void Start()
		{
			if(ORK.Access.Combatant.HasSpawnCreationAuthority &&
				!this.CheckAutoDestroy() && 
				this.CheckConditions())
			{
				this.sceneName = SceneManager.GetActiveScene().name;

				if(this.GetComponent<CombatantComponent>() == null)
				{
					if(this.rememberCombatant && this.spawnerID != "")
					{
						DataObject data = ORK.Game.Scene.GetSpawnerData(
							this.sceneName, this.spawnerID);
						if(data != null)
						{
							this.combatant = new Combatant(data, false, new Group(this.factionID));
							this.combatant.GameObject = this.gameObject;
							this.combatant.Object.LoadPosition(data);
						}
						else
						{
							this.combatant = this.combatantSetting.Create(new Group(this.factionID), true, this.transform.position);
							this.combatant.GameObject = this.gameObject;
						}
						this.combatant.Object.RememberPosition = true;
					}
					else
					{
						this.combatant = this.combatantSetting.Create(new Group(this.factionID), true, this.transform.position);
						this.combatant.GameObject = this.gameObject;
					}

					this.combatant.Group.BattleType = this.battleType;

					if(this.waypoints.Length > 0 && this.combatant.Object.MoveAI != null)
					{
						this.combatant.Object.MoveAI.SetWaypoints(this.waypoints, this.randomWaypointOrder);
					}
					if(this.combatant.Object.Component != null)
					{
						this.combatant.Object.Component.addCombatantComponent = this;
					}

					this.SetVariables();
				}
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual BattleComponent GetBattleComponent(Vector3 position, Vector3 rotation, AutoStartBattleSettings autoStart)
		{
			BattleComponent bc = null;
			if(this.battleComponentObject != null)
			{
				bc = this.battleComponentObject.GetComponent<BattleComponent>();
				if(bc != null)
				{
					if(this.setBCPos && this.setBCRot)
					{
						bc.transform.SetPositionAndRotation(position, Quaternion.Euler(rotation));
					}
					else
					{
						if(this.setBCPos)
						{
							bc.transform.position = position;
						}
						if(this.setBCRot)
						{
							bc.transform.eulerAngles = rotation;
						}
					}
				}
			}
			if(bc == null && this.useNearestArena)
			{
				bc = ComponentHelper.GetNearest<BattleComponent>(position, this.arenaRange);
			}
			if(autoStart != null &&
				autoStart.useNearestArena)
			{
				bc = ComponentHelper.GetNearest<BattleComponent>(position, autoStart.arenaRange);
			}
			if(bc == null)
			{
				bc = new GameObject("_Battle").AddComponent<BattleComponent>();
				bc.transform.SetPositionAndRotation(position, Quaternion.Euler(rotation));
			}
			bc.battleType = this.battleType;
			bc.useSceneID = false;
			bc.sceneID = -1;
			return bc;
		}


		/*
		============================================================================
		Remember functions
		============================================================================
		*/
		public virtual void StoreSpawned()
		{
			if(this.rememberCombatant &&
				this.spawnerID != "" &&
				this.combatant != null)
			{
				ORK.Game.Scene.SetSpawnerData(this.sceneName,
					this.spawnerID, this.combatant.SaveGame());
			}
		}

		protected virtual void OnDestroy()
		{
			if(ORK.SaveGame != null &&
				!ORK.SaveGame.IsLoading)
			{
				this.StoreSpawned();
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "Combatant.psd");
		}
	}
}
