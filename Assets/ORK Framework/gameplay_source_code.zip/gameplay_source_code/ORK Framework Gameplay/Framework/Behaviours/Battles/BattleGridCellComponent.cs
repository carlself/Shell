﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class BattleGridCellComponent : MonoBehaviour, ISerializationCallbackReceiver
	{
		// grid info
		public BattleGridComponent parentGrid = null;

		public BattleGridCellComponent[] connections = null;

		public int row = 0;

		public int column = 0;


		// cell settings
		[ORKEditorInfo(ORKDataType.BattleGridCellType)]
		public int cellTypeID = 0;

		// deployment
		public bool ownDeployment = false;

		public GridDeploymentCell deployment;

		// rotation
		public bool setSpawnRotation = false;

		public float spawnRotation = 0;

		// own blocked cell
		public bool ownBlockedSettings = false;

		public bool blocked = false;

		public bool passable = false;

		public bool blockDiagonalMove = true;


		// cell events
		[ORKEditorInfo("Cell Events", "A cell event can perform abilities and game events on combatants that " +
			"move to/over or start/end their turn on cells of this type.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Cell Event", "Adds a cell event (abilities and game events) that can be performed on combatants on cells of this type.", "",
			"Remove", "Removes this cell event.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[]
			{
				"Cell Event", "Define when this cell event will be performed and what abilities and game events will be used.", ""
			})]
		[System.NonSerialized]
		public GridCellEvent[] cellEvent = new GridCellEvent[0];

		[SerializeField]
		[HideInInspector]
		private ORKDataFile serialize_cellEvent;


		// in-game
		private BattleGridCellType cellTypeSettings;

		[SerializeField]
		private GameObject prefabInstance;

		private CubeCoord cubeCoord;

		private bool isPositionOffset = false;

		private Vector3 originalPosition = Vector3.zero;

		private Dictionary<string, TemporaryGridCellEvent> temporaryCellEvents;


		// occupant
		private Combatant combatant;

		private bool isSizeCombatant = false;

		private Combatant markedForCombatant;

		private Combatant markedForAI;

		private List<Combatant> guestCombatants;


		// highlighting
		private GridHighlightType currentHighlight = GridHighlightType.None;

		private GridHighlightType priorityHighlight = GridHighlightType.None;

		private List<GridHighlightType> highlightStack;

		private Dictionary<GridHighlightType, GameObject> highlight;

		public void Init(BattleGridComponent parentGrid, int row, int column)
		{
			this.parentGrid = parentGrid;
			this.row = row;
			this.column = column;
		}

		private void Start()
		{
			if(this.Settings != null &&
				this.Settings.useObjectVariables)
			{
				this.Settings.objectVariables.AddComponent(this.gameObject);
			}
		}

		public BattleGridCellType CellType
		{
			get
			{
				if(this.cellTypeSettings == null &&
					ORK.Initialized)
				{
					if(this.isPositionOffset)
					{
						this.transform.position = this.originalPosition;
						this.isPositionOffset = false;
					}
					if(Application.isEditor &&
						!Application.isPlaying)
					{
						this.cellTypeSettings = ORK.BattleGridCellTypes.Get(this.cellTypeID);
					}
					else
					{
						this.cellTypeSettings = ORK.BattleGridCellTypes.Get(this.cellTypeID).GetCellType();
						if(this.cellTypeSettings.singleCellType.usePositionOffset)
						{
							this.isPositionOffset = true;
							this.originalPosition = this.transform.position;
							this.transform.position = this.cellTypeSettings.singleCellType.localPosition.GetOffsetPosition(
								this.transform, this.cellTypeSettings.singleCellType.positionOffset);
						}
					}
				}
				return this.cellTypeSettings;
			}
		}

		public BattleGridCellTypeSingle Settings
		{
			get
			{
				return this.CellType.singleCellType;
			}
		}

		public bool IsPositionOffset
		{
			get { return this.isPositionOffset; }
		}

		public float SpawnRotation
		{
			get { return this.transform.eulerAngles.y + this.spawnRotation; }
		}

		public void ClearSettings()
		{
			this.cellTypeSettings = null;
		}

		public CubeCoord CubeCoord
		{
			get
			{
				if(this.cubeCoord == null)
				{
					this.cubeCoord = CubeCoord.FromOffset(this.row, this.column);
				}
				return this.cubeCoord;
			}
		}

		public bool IsBlocked
		{
			get
			{
				if(this.ownBlockedSettings)
				{
					return this.blocked;
				}
				return this.Settings.blocked;
			}
		}

		public bool IsPassable
		{
			get
			{
				if(this.ownBlockedSettings)
				{
					return !this.blocked || this.passable;
				}
				return !this.Settings.blocked || this.Settings.passable;
			}
		}

		public bool BlockDiagonalMove
		{
			get
			{
				if(this.ownBlockedSettings)
				{
					return this.blocked && this.blockDiagonalMove;
				}
				return this.Settings.blocked && this.Settings.blockDiagonalMove;
			}
		}


		/*
		============================================================================
		Connection functions
		============================================================================
		*/
		public void InitConnections()
		{
			if(ORK.BattleSystem.gridSettings.IsSquare)
			{
				this.InitConnectionsSquare();
			}
			else
			{
				this.InitConnectionsHexagonal();
			}
		}

		public void InitConnectionsSquare()
		{
			this.parentGrid.CreateLookup();
			this.connections = new BattleGridCellComponent[BattleGridHelper.SquareDirectionsDiagonal.Length];

			if(!this.parentGrid.noBlockedConnections ||
				!this.IsBlocked)
			{
				CubeCoord coord = new CubeCoord();
				for(int i = 0; i < this.connections.Length; i++)
				{
					coord.SetAdd(this.CubeCoord, BattleGridHelper.SquareDirectionsDiagonal[i]);
					this.connections[i] = this.parentGrid.GetCell(coord);
					if(this.parentGrid.noBlockedConnections &&
						this.connections[i] != null &&
						this.connections[i].IsBlocked)
					{
						this.connections[i] = null;
					}
				}
			}
		}

		public void InitConnectionsHexagonal()
		{
			this.parentGrid.CreateLookup();
			this.connections = new BattleGridCellComponent[BattleGridHelper.HexagonalDirections.Length];

			if(!this.parentGrid.noBlockedConnections ||
				!this.IsBlocked)
			{
				CubeCoord coord = new CubeCoord();
				for(int i = 0; i < this.connections.Length; i++)
				{
					coord.SetAdd(this.CubeCoord, BattleGridHelper.HexagonalDirections[i]);
					this.connections[i] = this.parentGrid.GetCell(coord);
					if(this.parentGrid.noBlockedConnections &&
						this.connections[i] != null &&
						this.connections[i].IsBlocked)
					{
						this.connections[i] = null;
					}
				}
			}
		}

		public void RemoveBlockedConnections()
		{
			if(this.connections != null)
			{
				if(this.IsBlocked)
				{
					for(int i = 0; i < this.connections.Length; i++)
					{
						this.connections[i] = null;
					}
				}
				else
				{
					for(int i = 0; i < this.connections.Length; i++)
					{
						if(this.connections[i] != null &&
							this.connections[i].IsBlocked)
						{
							this.connections[i] = null;
						}
					}
				}
			}
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public bool CanDeploy(Combatant combatant)
		{
			return !this.IsBlocked &&
				this.combatant == null &&
				(this.ownDeployment ?
					this.deployment.CanDeploy(combatant) :
					this.Settings.deployment.CanDeploy(combatant)) &&
				combatant.Grid.CanPlaceOn(this, -1);
		}

		public bool IsDeployment
		{
			get
			{
				return this.ownDeployment ?
					GridDeploymentType.None != this.deployment.type :
					GridDeploymentType.None != this.Settings.deployment.type;
			}
		}

		public GridDeploymentCell Deployment
		{
			get { return this.ownDeployment ? this.deployment : this.Settings.deployment; }
		}

		public bool IsEmpty
		{
			get
			{
				return this.combatant == null &&
					this.markedForCombatant == null &&
					!this.HasGuests;
			}
		}

		public Combatant Combatant
		{
			get { return this.combatant; }
		}

		public void SetCombatant(Combatant value, bool isSizeCombatant)
		{
			if(this.combatant != value ||
				this.isSizeCombatant != isSizeCombatant)
			{
				// reset current combatant's grid cell
				if(this.combatant != null &&
					!this.isSizeCombatant &&
					this.combatant.Grid.Cell == this)
				{
					Combatant tmpCombatant = this.combatant;
					this.combatant = null;
					tmpCombatant.Grid.Cell = null;
				}

				this.combatant = value;
				this.isSizeCombatant = isSizeCombatant;
				this.MarkedForAI = null;
				if(this.markedForCombatant != null)
				{
					this.markedForCombatant = null;
					if(ORK.Battle.SystemSettings.gridHighlights.markedCellHighlight.enable)
					{
						BattleGridHelper.StopHighlight(this, GridHighlightType.MarkedCell);
					}
				}
				if(this.HasGuests)
				{
					this.guestCombatants.Remove(this.combatant);
				}

				// set new combatant's grid cell
				if(this.combatant != null &&
					!this.isSizeCombatant)
				{
					this.combatant.Grid.Cell = this;
				}
				this.parentGrid.MarkFireChanged();
			}
		}

		public Combatant MarkedForCombatant
		{
			get { return this.markedForCombatant; }
			set
			{
				if(this.markedForCombatant != value)
				{
					this.markedForCombatant = value;
					this.parentGrid.MarkFireChanged();

					if(ORK.Battle.SystemSettings.gridHighlights.markedCellHighlight.enable)
					{
						if(this.markedForCombatant != null)
						{
							BattleGridHelper.Highlight(this, GridHighlightType.MarkedCell);
						}
						else
						{
							BattleGridHelper.StopHighlight(this, GridHighlightType.MarkedCell);
						}
					}
				}
			}
		}

		public Combatant MarkedForAI
		{
			get { return this.markedForAI; }
			set
			{
				if(this.markedForAI != value)
				{
					// reset current combatant's grid cell
					if(this.markedForAI != null &&
						this.markedForAI.Grid.CellMarkedForAI == this)
					{
						Combatant tmpCombatant = this.markedForAI;
						this.markedForAI = null;
						tmpCombatant.Grid.CellMarkedForAI = null;
					}

					this.markedForAI = value;

					// set new combatant's grid cell
					if(this.markedForAI != null)
					{
						this.markedForAI.Grid.CellMarkedForAI = this;
					}
					this.parentGrid.MarkFireChanged();
				}
			}
		}

		public bool HasGuests
		{
			get
			{
				return this.guestCombatants != null &&
					this.guestCombatants.Count > 0;
			}
		}

		public List<Combatant> GetGuests()
		{
			return this.guestCombatants;
		}

		public bool IsGuest(Combatant combatant)
		{
			return this.HasGuests &&
				this.guestCombatants.Contains(combatant);
		}

		public void AddGuest(Combatant combatant)
		{
			if(this.guestCombatants == null)
			{
				this.guestCombatants = new List<Combatant>();
			}
			if(!this.guestCombatants.Contains(combatant))
			{
				this.guestCombatants.Add(combatant);
				combatant.Grid.AddGuestCell(this);
				this.parentGrid.MarkFireChanged();
			}
		}

		public void RemoveGuest(Combatant combatant)
		{
			if(this.guestCombatants != null &&
				this.guestCombatants.Contains(combatant))
			{
				this.guestCombatants.Remove(combatant);
				combatant.Grid.RemoveGuestCell(this);
				this.parentGrid.MarkFireChanged();
			}
		}

		public void GetCombatants(ref List<Combatant> list, CheckCombatant check)
		{
			if(this.combatant != null &&
				!list.Contains(this.combatant) &&
				(check == null || check(this.combatant)))
			{
				list.Add(this.combatant);
			}
			if(this.HasGuests)
			{
				for(int i = 0; i < this.guestCombatants.Count; i++)
				{
					if(!list.Contains(this.guestCombatants[i]) &&
						(check == null || check(this.guestCombatants[i])))
					{
						list.Add(this.guestCombatants[i]);
					}
				}
			}
		}

		public bool CheckOccupants(CheckCombatant check)
		{
			if(check != null)
			{
				if(check(this.combatant))
				{
					return true;
				}
				else if(this.HasGuests)
				{
					for(int i = 0; i < this.guestCombatants.Count; i++)
					{
						if(check(this.guestCombatants[i]))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public void SwapCombatants(BattleGridCellComponent other, bool placeAtCell)
		{
			if(!this.IsBlocked &&
				other != null &&
				!other.IsBlocked)
			{
				if(this.combatant != null)
				{
					this.combatant.Grid.StopHighlightCells(
						ORK.Battle.SystemSettings.gridHighlights.GetCombatantCellHighlight(this.combatant));
				}

				Combatant tmpCombatant = this.combatant;
				this.combatant = null;
				this.SetCombatant(other.combatant, false);

				other.combatant = null;
				other.SetCombatant(tmpCombatant, false);

				if(placeAtCell)
				{
					if(this.combatant != null)
					{
						this.combatant.GameObject.transform.position = this.transform.position;
					}
					if(other.combatant != null)
					{
						other.combatant.GameObject.transform.position = other.transform.position;
					}
				}
			}
		}

		public void RemoveCombatant(Combatant combatant)
		{
			if(combatant != null)
			{
				if(this.combatant == combatant)
				{
					this.combatant.Grid.StopHighlightCells(
						ORK.Battle.SystemSettings.gridHighlights.GetCombatantCellHighlight(this.combatant));
					this.combatant = null;
					if(!this.isSizeCombatant)
					{
						combatant.Grid.Cell = null;
					}
				}
				if(this.markedForCombatant == combatant)
				{
					this.markedForCombatant = null;
					if(ORK.Battle.SystemSettings.gridHighlights.markedCellHighlight.enable)
					{
						BattleGridHelper.StopHighlight(this, GridHighlightType.MarkedCell);
					}
				}
				if(this.guestCombatants != null &&
					this.guestCombatants.Contains(combatant))
				{
					this.guestCombatants.Remove(combatant);
					combatant.Grid.RemoveGuestCell(this);
				}
				this.parentGrid.MarkFireChanged();
			}
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public GameObject PrefabInstance
		{
			get { return this.prefabInstance; }
		}

		public GameObject HighlightPrefabInstance
		{
			get
			{
				GameObject prefab;
				if(this.highlight != null &&
					this.highlight.TryGetValue(this.currentHighlight, out prefab))
				{
					return prefab;
				}
				return null;
			}
			set
			{
				if(this.highlight == null)
				{
					this.highlight = new Dictionary<GridHighlightType, GameObject>();
				}
				if(this.highlight.ContainsKey(this.currentHighlight))
				{
					this.highlight[this.currentHighlight] = value;
				}
				else
				{
					this.highlight.Add(this.currentHighlight, value);
				}
			}
		}

		public void ShowPrefab()
		{
			if(this.prefabInstance == null &&
				this.Settings != null)
			{
				this.prefabInstance = this.Settings.CreatePrefabInstance(this);
			}
		}

		public void EditorShowPrefab()
		{
			if(this.prefabInstance == null &&
				this.CellType != null)
			{
				this.prefabInstance = this.CellType.CreatePrefabInstance(this, true);
			}
		}

		public void HidePrefab()
		{
			if(this.prefabInstance != null)
			{
				this.prefabInstance.SetActive(false);
			}
			if(this.highlight != null)
			{
				foreach(KeyValuePair<GridHighlightType, GameObject> pair in this.highlight)
				{
					if(pair.Value != null)
					{
						pair.Value.SetActive(false);
					}
				}
			}
		}

		public void DestroyPrefab()
		{
			if(this.prefabInstance != null)
			{
				UnityWrapper.Destroy(this.prefabInstance);
			}
			if(this.highlight != null)
			{
				foreach(KeyValuePair<GridHighlightType, GameObject> pair in this.highlight)
				{
					if(pair.Value != null)
					{
						UnityWrapper.Destroy(pair.Value);
					}
				}
			}
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public void HideHighlights(bool hiddenByUI, bool systemHideState)
		{
			if(hiddenByUI || systemHideState ?
				GridHighlightType.None != this.currentHighlight :
				(this.highlightStack != null && this.highlightStack.Count > 0))
			{
				if(systemHideState ||
					!hiddenByUI ||
					ORK.Battle.SystemSettings.gridHighlights.IsHidden(this.currentHighlight))
				{
					this.DoStopHighlight(this.currentHighlight);
					this.currentHighlight = this.GetLastHighlightType();
					if(GridHighlightType.None != this.currentHighlight)
					{
						this.DoHighlight(this.currentHighlight);
					}
				}
			}
		}

		public void Highlight(GridHighlightType highlightType)
		{
			if(this.currentHighlight != highlightType)
			{
				if(this.highlightStack == null)
				{
					this.highlightStack = new List<GridHighlightType>();
				}
				if(GridHighlightType.None != this.currentHighlight)
				{
					this.DoStopHighlight(this.currentHighlight);
				}

				// set priority highlight
				if(GridHighlightType.SelectingPlayer == highlightType ||
					GridHighlightType.SelectingAlly == highlightType ||
					GridHighlightType.SelectingEnemy == highlightType ||
					GridHighlightType.MarkedCell == highlightType ||
					// player selection
					GridHighlightType.PlacementSelectionPlayer == highlightType ||
					GridHighlightType.MoveSelectionPlayer == highlightType ||
					GridHighlightType.OrientationSelectionPlayer == highlightType ||
					GridHighlightType.TargetCellSelectionPlayer == highlightType ||
					GridHighlightType.ExamineSelectionPlayer == highlightType ||
					// ally selection
					GridHighlightType.PlacementSelectionAlly == highlightType ||
					GridHighlightType.MoveSelectionAlly == highlightType ||
					GridHighlightType.OrientationSelectionAlly == highlightType ||
					GridHighlightType.TargetCellSelectionAlly == highlightType ||
					GridHighlightType.ExamineSelectionAlly == highlightType ||
					// enemy selection
					GridHighlightType.PlacementSelectionEnemy == highlightType ||
					GridHighlightType.MoveSelectionEnemy == highlightType ||
					GridHighlightType.OrientationSelectionEnemy == highlightType ||
					GridHighlightType.TargetCellSelectionEnemy == highlightType ||
					GridHighlightType.ExamineSelectionEnemy == highlightType)
				{
					this.priorityHighlight = highlightType;
				}

				if(this.highlightStack.Count > 0 &&
					(GridHighlightType.CellPlayer == highlightType ||
						GridHighlightType.CellAlly == highlightType ||
						GridHighlightType.CellEnemy == highlightType))
				{
					this.highlightStack.Insert(0, highlightType);
				}
				else
				{
					this.highlightStack.Add(highlightType);
				}

				this.PriorityHighlight();
				this.currentHighlight = this.GetLastHighlightType();
				if(GridHighlightType.None != this.currentHighlight)
				{
					this.DoHighlight(this.currentHighlight);
				}
			}
		}

		public void StopHighlight(GridHighlightType highlightType)
		{
			// remove priority highlight
			if(this.priorityHighlight == highlightType)
			{
				this.priorityHighlight = GridHighlightType.None;
			}

			if(this.currentHighlight == highlightType)
			{
				this.DoStopHighlight(this.currentHighlight);

				if(this.highlightStack != null &&
					this.highlightStack.Count > 0)
				{
					this.RemoveHighlightType(highlightType);
					this.currentHighlight = this.GetLastHighlightType();
					if(GridHighlightType.None != this.currentHighlight)
					{
						this.DoHighlight(this.currentHighlight);
					}
				}
				else
				{
					this.currentHighlight = GridHighlightType.None;
				}
			}
			else
			{
				this.RemoveHighlightType(highlightType);
			}
		}

		private GridHighlightType GetLastHighlightType()
		{
			if(!ORK.BattleSystem.gridHighlights.HideGridHighlights &&
				this.highlightStack != null &&
				this.highlightStack.Count > 0)
			{
				if(this.parentGrid.HighlightsHiddenByUI)
				{
					for(int i = this.highlightStack.Count - 1; i >= 0; i--)
					{
						if(!ORK.Battle.SystemSettings.gridHighlights.IsHidden(this.highlightStack[i]))
						{
							return this.highlightStack[i];
						}
					}
				}
				else
				{
					return this.highlightStack[this.highlightStack.Count - 1];
				}
			}
			return GridHighlightType.None;
		}

		private void PriorityHighlight()
		{
			if(ORK.Battle.SystemSettings.gridHighlights.selectingPriority &&
				this.highlightStack != null &&
				this.highlightStack.Count > 0 &&
				GridHighlightType.None != this.priorityHighlight)
			{
				this.RemoveHighlightType(this.priorityHighlight);
				this.highlightStack.Add(this.priorityHighlight);
			}
		}

		private void RemoveHighlightType(GridHighlightType highlightType)
		{
			if(this.highlightStack != null &&
				this.highlightStack.Contains(highlightType))
			{
				for(int i = this.highlightStack.Count - 1; i >= 0; i--)
				{
					if(this.highlightStack[i] == highlightType)
					{
						this.highlightStack.RemoveAt(i);
					}
				}
			}
		}

		public void StopAllHighlights()
		{
			if(GridHighlightType.None != this.currentHighlight)
			{
				this.DoStopHighlight(this.currentHighlight);

				if(this.highlightStack != null &&
					this.highlightStack.Count > 0)
				{
					this.highlightStack.Clear();
				}
				this.currentHighlight = GridHighlightType.None;
			}
		}

		private void DoHighlight(GridHighlightType highlightType)
		{
			GridHighlight setting = ORK.Battle.SystemSettings.gridHighlights.GetHighlight(highlightType);
			if(setting != null)
			{
				setting.Highlight(this);
			}
		}

		private void DoStopHighlight(GridHighlightType highlightType)
		{
			GridHighlight setting = ORK.Battle.SystemSettings.gridHighlights.GetHighlight(highlightType);
			if(setting != null)
			{
				setting.StopHighlight(this);
			}
		}


		/*
		============================================================================
		Cell event functions
		============================================================================
		*/
		public void GetCellEvents(ref List<GridCellEventCall> cellEvents, GridCellEventStartType startType)
		{
			// cell type events
			if(this.Settings != null)
			{
				for(int i = 0; i < this.Settings.cellEvent.Length; i++)
				{
					if(this.Settings.cellEvent[i].startType == startType ||
						this.Settings.cellEvent[i].startType == GridCellEventStartType.Any ||
						GridCellEventStartType.Any == startType)
					{
						cellEvents.Add(new GridCellEventCall(this, this.Settings.cellEvent[i]));
					}
				}
			}
			// cell events
			for(int i = 0; i < this.cellEvent.Length; i++)
			{
				if(this.cellEvent[i].startType == startType ||
					this.cellEvent[i].startType == GridCellEventStartType.Any ||
					GridCellEventStartType.Any == startType)
				{
					cellEvents.Add(new GridCellEventCall(this, this.cellEvent[i]));
				}
			}
			// temporary cell events
			if(this.temporaryCellEvents != null)
			{
				foreach(KeyValuePair<string, TemporaryGridCellEvent> pair in this.temporaryCellEvents)
				{
					if(pair.Value.startType == startType ||
						pair.Value.startType == GridCellEventStartType.Any ||
						GridCellEventStartType.Any == startType)
					{
						cellEvents.Add(new GridCellEventCall(this, pair.Value));
					}
				}
			}
		}

		public bool HasEvents
		{
			get
			{
				return this.cellEvent.Length > 0 ||
					(this.Settings != null &&
						this.Settings.cellEvent.Length > 0) ||
					(this.temporaryCellEvents != null &&
						this.temporaryCellEvents.Count > 0);
			}
		}

		public void AddTemporaryCellEvent(TemporaryGridCellEvent cellEvent)
		{
			if(this.temporaryCellEvents == null)
			{
				this.temporaryCellEvents = new Dictionary<string, TemporaryGridCellEvent>();
			}
			TemporaryGridCellEvent currentEvent;
			if(this.temporaryCellEvents.TryGetValue(cellEvent.EventKey, out currentEvent))
			{
				currentEvent.Clear();
				this.temporaryCellEvents[cellEvent.EventKey] = cellEvent;
			}
			else
			{
				this.temporaryCellEvents.Add(cellEvent.EventKey, cellEvent);
			}
			cellEvent.AddedTo(this);
		}

		public bool HasTemporaryCellEvent(string eventKey)
		{
			return this.temporaryCellEvents != null &&
				this.temporaryCellEvents.ContainsKey(eventKey);
		}

		public bool HasAnyTemporaryCellEvents()
		{
			return this.temporaryCellEvents != null &&
				this.temporaryCellEvents.Count > 0;
		}

		public void RemoveTemporaryCellEvent(string eventKey)
		{
			TemporaryGridCellEvent currentEvent;
			if(this.temporaryCellEvents.TryGetValue(eventKey, out currentEvent))
			{
				currentEvent.Clear();
				this.temporaryCellEvents.Remove(eventKey);
			}
		}

		public void ClearTemporaryCellEvents()
		{
			if(this.temporaryCellEvents != null)
			{
				foreach(KeyValuePair<string, TemporaryGridCellEvent> pair in this.temporaryCellEvents)
				{
					pair.Value.Clear();
				}
				this.temporaryCellEvents.Clear();
			}
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public void OnBeforeSerialize()
		{
			DataObject data = new DataObject();
			DataObject[] events = new DataObject[this.cellEvent.Length];
			for(int i = 0; i < this.cellEvent.Length; i++)
			{
				events[i] = this.cellEvent[i].GetData();
			}
			data.Set("cellEvents", events);
			this.serialize_cellEvent = data.GetDataFile("cellEvents", false);
		}

		public void OnAfterDeserialize()
		{
			this.cellEvent = new GridCellEvent[0];
			if(this.serialize_cellEvent != null)
			{
				DataObject data = this.serialize_cellEvent.ToDataObject();
				DataObject[] events = data.GetFileArray("cellEvents");
				if(events != null)
				{
					this.cellEvent = new GridCellEvent[events.Length];
					for(int i = 0; i < this.cellEvent.Length; i++)
					{
						this.cellEvent[i] = new GridCellEvent();
						this.cellEvent[i].SetData(events[i]);
					}
				}
			}
			this.serialize_cellEvent = null;
		}
	}
}
