﻿
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/No Player Control")]
	public class NoPlayerControl : MonoBehaviour
	{

	}
}
