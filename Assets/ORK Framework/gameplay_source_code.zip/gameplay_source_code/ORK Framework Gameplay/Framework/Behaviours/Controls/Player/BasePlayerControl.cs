﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class BasePlayerControl : MonoBehaviour
	{
		public virtual void MoveToInteractionStartet(BaseInteraction interaction)
		{

		}
	}
}
