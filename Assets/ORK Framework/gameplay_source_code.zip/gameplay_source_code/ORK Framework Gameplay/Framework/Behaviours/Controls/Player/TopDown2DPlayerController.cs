﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[AddComponentMenu("ORK Framework/Controls/Player: Top Down 2D Controller")]
	public class TopDown2DPlayerController : MonoBehaviour
	{
		public bool moveDead = true;

		public bool useCharacterSpeed = false;

		public float runSpeed = 8.0f;

		public float gravity = Physics.gravity.y;

		public float speedSmoothing = 10.0f;


		// input
		public int verticalAxis = 0;

		public int horizontalAxis = 0;


		// flipping
		public bool horizontalFlip = false;

		public bool horizontalFlipNegate = false;

		public bool verticalFlip = false;

		public bool verticalFlipNegate = false;

		public float flipInputIgnore = 0.1f;


		// sprint settings
		public bool useSprint = false;

		public int sprintKey = 0;

		public float sprintFactor = 2.0f;

		public bool useEnergy = false;

		public FloatValue maxEnergy = new FloatValue(10);

		public FloatValue energyConsume = new FloatValue(1);

		public FloatValue energyRegeneration = new FloatValue(1);

		protected float currentSprintEnergy = 0;

		protected float currentMaxSprintEnergy = 0;


		// in-game
		protected Rigidbody2D rigidbody;

		protected Vector2 moveDirection = Vector2.zero;

		protected float verticalSpeed = 0.0f;

		protected float moveSpeed = 0.0f;

		protected float lastMoveSpeed = 0.0f;

		protected Combatant combatant = null;

		protected virtual void Start()
		{
			this.rigidbody = this.GetComponent<Rigidbody2D>();
			this.moveDirection = this.transform.TransformDirection(Vector3.forward);

			if(this.useCharacterSpeed || !this.moveDead ||
				(this.useSprint && this.useEnergy))
			{
				this.combatant = ComponentHelper.GetCombatant(this.transform.root.gameObject);
				if(this.combatant != null && (this.useSprint && this.useEnergy))
				{
					this.currentMaxSprintEnergy = this.maxEnergy.GetValue(this.combatant, this.combatant);
					this.currentSprintEnergy = this.currentMaxSprintEnergy;
				}
			}
		}

		protected virtual void OnDisable()
		{
			if(this.rigidbody != null)
			{
				this.rigidbody.velocity = Vector2.zero;
			}
		}

		protected virtual void Update()
		{
			this.UpdateSmoothedMovementDirection();
		}

		protected virtual void FixedUpdate()
		{
			if(this.rigidbody != null)
			{
				this.rigidbody.velocity = this.moveDirection * this.moveSpeed;
			}
		}

		protected void UpdateSmoothedMovementDirection()
		{
			float t = ORK.Game.DeltaMovementTime;

			this.moveDirection = Vector2.zero;
			float speedMod = 1;

			if(this.combatant == null ||
				((this.moveDead || !this.combatant.Status.IsDead) &&
				!this.combatant.Status.Effects.StopMovement))
			{
				this.moveDirection.y = ORK.InputKeys.Get(this.verticalAxis).GetAxis();
				this.moveDirection.x = ORK.InputKeys.Get(this.horizontalAxis).GetAxis();

				if(this.useCharacterSpeed && this.combatant != null)
				{
					this.runSpeed = this.combatant.Object.GetMoveSpeed(MoveSpeedType.Run);
				}

				if(this.combatant != null)
				{
					// sprint
					if(this.useSprint &&
						this.combatant.Object.Component != null &&
						!this.combatant.Object.Component.InAir &&
						ORK.InputKeys.Get(this.sprintKey).GetButton())
					{
						if(this.EnergyHandling(true))
						{
							speedMod = this.sprintFactor;
						}
					}
					else
					{
						this.EnergyHandling(false);
					}
				}
			}

			float curSmooth = speedSmoothing * t;
			float targetSpeed = Mathf.Min(this.moveDirection.magnitude, 1.0f);
			if(targetSpeed < 0.2)
			{
				targetSpeed = 0;
			}
			else
			{
				targetSpeed *= this.runSpeed * speedMod;

				if(this.horizontalFlip)
				{
					if(this.moveDirection.x < -this.flipInputIgnore &&
						(this.horizontalFlipNegate ?
							this.transform.localScale.x < 0 :
							this.transform.localScale.x > 0))
					{
						Vector3 scale = this.transform.localScale;
						scale.x = -scale.x;
						this.transform.localScale = scale;
					}
					else if(this.moveDirection.x > this.flipInputIgnore &&
						(this.horizontalFlipNegate ?
							this.transform.localScale.x > 0 :
							this.transform.localScale.x < 0))
					{
						Vector3 scale = this.transform.localScale;
						scale.x = -scale.x;
						this.transform.localScale = scale;
					}
				}
				if(this.verticalFlip)
				{
					if(this.moveDirection.y < -this.flipInputIgnore &&
						(this.verticalFlipNegate ?
							this.transform.localScale.y < 0 :
							this.transform.localScale.y > 0))
					{
						Vector3 scale = this.transform.localScale;
						scale.y = -scale.y;
						this.transform.localScale = scale;
					}
					else if(this.moveDirection.y > this.flipInputIgnore &&
						(this.verticalFlipNegate ?
							this.transform.localScale.y > 0 :
							this.transform.localScale.y < 0))
					{
						Vector3 scale = this.transform.localScale;
						scale.y = -scale.y;
						this.transform.localScale = scale;
					}
				}
			}
			this.moveSpeed = Mathf.Lerp(this.moveSpeed, targetSpeed, curSmooth);
		}

		protected bool EnergyHandling(bool use)
		{
			bool ok = true;
			if(this.useSprint &&
				this.useEnergy)
			{
				float t = ORK.Game.DeltaMovementTime;
				// set max
				this.currentMaxSprintEnergy = this.maxEnergy.GetValue(this.combatant, this.combatant);
				// regenerate
				this.currentSprintEnergy += this.energyRegeneration.GetValue(this.combatant, this.combatant) * t;
				// use
				if(use)
				{
					float tmp = this.energyConsume.GetValue(this.combatant, this.combatant) * t;
					if(tmp > this.currentSprintEnergy)
						ok = false;
					else
						this.currentSprintEnergy -= tmp;
				}
				// max bounds
				if(this.currentSprintEnergy < 0)
				{
					this.currentSprintEnergy = 0;
				}
				else if(this.currentSprintEnergy > this.currentMaxSprintEnergy)
				{
					this.currentSprintEnergy = this.currentMaxSprintEnergy;
				}
			}
			return ok;
		}
	}
}
