
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Move AI/Simple Move")]
	public class SimpleMove : MonoBehaviour
	{
		[UnityEngine.Serialization.FormerlySerializedAs("ignoreYRotation")]
		public bool ignoreHeightDistance = true;

		public bool smooth = true;

		public float speedSmoothing = 10;

		public float rotationDamping = 6.0f;


		// move target
		protected bool doMove = false;

		protected Vector3 targetPosition;

		protected float maxSpeed = 5;


		// movement
		protected CharacterController controller;

		protected Vector3 moveDirection;

		protected float moveSpeed = 0;

		protected virtual void Start()
		{
			this.controller = this.transform.root.GetComponentInChildren<CharacterController>();
		}

		protected virtual void Update()
		{
			if(this.doMove)
			{
				float t = ORK.Game.DeltaMovementTime;

				if(this.ignoreHeightDistance)
				{
					if(HorizontalPlaneType.XY == ORK.GameSettings.horizontalPlane)
					{
						this.targetPosition.z = this.transform.position.z;
					}
					else
					{
						this.targetPosition.y = this.transform.position.y;
					}
				}

				if(this.smooth)
				{
					this.transform.rotation = Quaternion.Slerp(this.transform.rotation,
						VectorHelper.LookAt(this.transform.position, this.targetPosition),
						this.rotationDamping * t);
					this.moveSpeed = Mathf.Lerp(this.moveSpeed, this.maxSpeed, this.speedSmoothing * t);
				}
				else
				{
					this.transform.LookAt(this.targetPosition);
					this.moveSpeed = this.maxSpeed;
				}

				this.moveDirection = this.transform.TransformDirection(Vector3.forward);
				if(this.controller != null)
				{
					this.controller.Move((this.moveDirection * this.moveSpeed + Physics.gravity) * t);
				}
				else
				{
					this.transform.Translate(this.moveDirection * this.moveSpeed * t, Space.World);
				}
			}
		}


		/*
		============================================================================
		Move functions
		============================================================================
		*/
		public virtual void MoveTo(float speed, Vector3 position)
		{
			this.maxSpeed = speed;
			this.targetPosition = position;
			this.doMove = true;
		}

		public virtual void Stop()
		{
			this.doMove = false;
			if(this.controller != null)
			{
				this.controller.Move(Vector3.zero);
			}
		}
	}
}
