
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using ORKFramework;
using System.Collections.Generic;
using System.Text;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/UI/Update UI Slider")]
	public class UpdateUISlider : MonoBehaviour
	{
		public Slider sliderComponent;

		public float updateTime = 0;

		public UINumberOrigin valueOrigin = UINumberOrigin.StatusValue;


		// status value
		public int statusValueID = 0;


		// attribute
		public int attributeID = 0;

		public int subAttributeID = 0;


		// content object
		public UIContentOrigin contentOrigin = UIContentOrigin.Player;

		public int memberIndex = 0;

		public FindObjectSetting findObject;

		public GameObject contentObject;

		public bool updateObject = false;

		public float objectUpdateTime = 0;


		// in-game
		private float timeout = 0;

		private float objectTimeout = 0;

		private Combatant combatant;


		/*
		============================================================================
		Text update functions
		============================================================================
		*/
		void Update()
		{
			if(this.updateObject)
			{
				if(this.objectTimeout <= 0)
				{
					this.UpdateObject();
					this.objectTimeout = this.objectUpdateTime;
				}
				else
				{
					this.objectTimeout -= ORK.Core.GUITimeDelta; ;
				}
			}

			if(this.timeout <= 0)
			{
				this.UpdateSlider();

				this.timeout = this.updateTime;
			}
			else
			{
				this.timeout -= ORK.Core.GUITimeDelta;
			}
		}

		public void UpdateSlider()
		{
			if(this.sliderComponent != null)
			{
				if(this.combatant == null)
				{
					this.UpdateObject();
				}

				if(this.combatant != null)
				{
					if(UINumberOrigin.StatusValue == this.valueOrigin)
					{
						this.sliderComponent.minValue = this.combatant.Status[this.statusValueID].GetMinValue();
						this.sliderComponent.maxValue = this.combatant.Status[this.statusValueID].GetMaxValue();
						this.sliderComponent.value = this.combatant.Status[this.statusValueID].GetDisplayValue();
					}
					else if(UINumberOrigin.AttackAttribute == this.valueOrigin)
					{
						this.sliderComponent.minValue = this.combatant.Status.
							GetAttackAttribute(this.attributeID).GetMinValue();
						this.sliderComponent.maxValue = this.combatant.Status.
							GetAttackAttribute(this.attributeID).GetMaxValue();
						this.sliderComponent.value = this.combatant.Status.
							GetAttackAttribute(this.attributeID).GetValue(this.subAttributeID);
					}
					else if(UINumberOrigin.DefenceAttribute == this.valueOrigin)
					{
						this.sliderComponent.minValue = this.combatant.Status.
							GetDefenceAttribute(this.attributeID).GetMinValue();
						this.sliderComponent.maxValue = this.combatant.Status.
							GetDefenceAttribute(this.attributeID).GetMaxValue();
						this.sliderComponent.value = this.combatant.Status.
							GetDefenceAttribute(this.attributeID).GetValue(this.subAttributeID);
					}
				}
				else
				{
					this.sliderComponent.minValue = 0;
					this.sliderComponent.maxValue = 0;
					this.sliderComponent.value = 0;
				}
			}
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public void UpdateObject()
		{
			this.combatant = this.GetCombatant();
		}

		public Combatant GetCombatant()
		{
			if(UIContentOrigin.Player == this.contentOrigin)
			{
				return ORK.Game.ActiveGroup.Leader;
			}
			else if(UIContentOrigin.Member == this.contentOrigin)
			{
				return ORK.Game.ActiveGroup.MemberAt(this.memberIndex);
			}
			else if(UIContentOrigin.FindObject == this.contentOrigin)
			{
				return ComponentHelper.GetFirstCombatant(this.findObject.Find(this.gameObject));
			}
			else if(UIContentOrigin.GameObject == this.contentOrigin)
			{
				if(this.contentObject != null)
				{
					return ComponentHelper.GetCombatant(this.contentObject);
				}
			}
			return null;
		}
	}
}
