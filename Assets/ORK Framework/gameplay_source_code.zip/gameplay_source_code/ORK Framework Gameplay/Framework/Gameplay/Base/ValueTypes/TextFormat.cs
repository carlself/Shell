
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public struct TextFormat
	{
		public int colorID;


		// shadow
		public bool showShadow;
		
		public int shadowColorID;
		
		public Vector2 shadowOffset;


		// outline (new UI)
		public bool showOutline;
		
		public int outlineColorID;
		
		public Vector2 outlineOffset;


		// font
		public Font font;
		
		public int fontSize;
		
		public FontStyle fontStyle;

		public TextFormat(int colorID, int shadowColorID)
		{
			this.colorID = colorID;

			// shadow
			this.shadowColorID = shadowColorID;
			this.showShadow = this.shadowColorID >= 0;
			this.shadowOffset = new Vector2(1, 1);

			// outline
			this.outlineColorID = shadowColorID;
			this.showOutline = this.outlineColorID >= 0;
			this.outlineOffset = new Vector2(1, 1);

			// font
			this.font = null;
			this.fontSize = 20;
			this.fontStyle = FontStyle.Normal;
		}

		public TextFormat(TextFormatSetting setting)
		{
			this.colorID = setting.colorID;

			// shadow
			this.showShadow = setting.showShadow;
			this.shadowColorID = setting.shadowColorID;
			this.shadowOffset = setting.shadowOffset;

			// outline
			this.showOutline = setting.showOutline;
			this.outlineColorID = setting.outlineColorID;
			this.outlineOffset = setting.outlineOffset;

			// font
			this.font = setting.font;
			this.fontSize = setting.fontSize;
			this.fontStyle = setting.fontStyle;
		}

		public static implicit operator TextFormat(TextFormatSetting setting)
		{
			return new TextFormat(setting);
		}


		/*
		============================================================================
		Static text colors
		============================================================================
		*/
		public static TextFormat Default
		{
			get { return new TextFormat(0, 1); }
		}


		/*
		============================================================================
		Color functions
		============================================================================
		*/
		public Color GetTextColor()
		{
			return ORK.Colors.Get(this.colorID).color;
		}

		public Color GetShadowColor()
		{
			return ORK.Colors.Get(this.shadowColorID).color;
		}

		public Color GetOutlineColor()
		{
			return ORK.Colors.Get(this.outlineColorID).color;
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public Rect GetShadowRect(Vector2 position, Vector2 size)
		{
			return new Rect(position.x + this.shadowOffset.x, position.y + this.shadowOffset.y, size.x, size.y);
		}
	}
}
