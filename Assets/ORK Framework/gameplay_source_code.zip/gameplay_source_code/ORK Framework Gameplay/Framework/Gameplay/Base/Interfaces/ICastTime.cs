﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface ICastTime
	{
		CastTimeSettings CastTimeSettings
		{
			get;
		}

		float GetCastTime(Combatant user);

		void PlayCastAudio(Combatant user);

		bool CanCancelCasting();

		bool CanCastMove();

		void ShowCastingConsoleText(Combatant user, List<Combatant> target,
			Dictionary<Combatant, StatusChangeInformation> statusChangesTarget);

		void ShowCancelCastingConsoleText(Combatant user, List<Combatant> target,
			Dictionary<Combatant, StatusChangeInformation> statusChangesTarget);
	}
}
