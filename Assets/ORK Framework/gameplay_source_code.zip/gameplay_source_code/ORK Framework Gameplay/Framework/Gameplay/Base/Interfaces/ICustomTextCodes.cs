﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface ICustomTextCodes
	{
		void ReplaceCustomTextCodes(ref string text);
	}
}
