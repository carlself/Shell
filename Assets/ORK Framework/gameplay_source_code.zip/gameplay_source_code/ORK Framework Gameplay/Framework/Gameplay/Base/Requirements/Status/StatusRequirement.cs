
using UnityEngine;
using ORKFramework.Requirements;

namespace ORKFramework
{
	public class StatusRequirement : BaseData
	{
		[ORKEditorHelp("Requirement Type", "Select what will be checked:\n" +
			"- Status: A single status will be checked.\n" +
			"- Requirements: Defined status requirements will be checked, allows more complex requirements.\n" +
			"- Template: A status requirement template will be used.", "")]
		public StatusRequirementType requirementType = StatusRequirementType.Status;


		// status
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("requirementType", StatusRequirementType.Status,
			endCheckGroup=true, autoInit=true)]
		public StatusRequirementSelection status;


		// requirements
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("requirementType", StatusRequirementType.Requirements)]
		public Needed needed = Needed.All;

		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "",
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public StatusRequirement[] req;


		// template
		[ORKEditorHelp("Template", "Select the status requirement template that will be used.", "")]
		[ORKEditorInfo(ORKDataType.StatusRequirementTemplate)]
		[ORKEditorLayout("requirementType", StatusRequirementType.Template, endCheckGroup=true)]
		public int templateID = 0;

		public StatusRequirement()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(!data.Contains<StatusRequirementType>("requirementType"))
			{
				this.requirementType = StatusRequirementType.Status;
				this.status = new StatusRequirementSelection();
				this.status.SetData(data);
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return "";//this.statusNeeded.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CheckRequirement(Combatant combatant)
		{
			if(StatusRequirementType.Status == this.requirementType)
			{
				return this.status.settings.Check(combatant);
			}
			else if(StatusRequirementType.Requirements == this.requirementType)
			{
				return StatusRequirement.Check(combatant, this.req, this.needed);
			}
			else if(StatusRequirementType.Template == this.requirementType)
			{
				return ORK.StatusRequirementTemplates.Get(this.templateID).CheckRequirement(combatant);
			}
			return false;
		}

		public bool CheckRequirementPreview(Combatant combatant)
		{
			if(StatusRequirementType.Status == this.requirementType)
			{
				return this.status.settings.CheckPreview(combatant);
			}
			else if(StatusRequirementType.Requirements == this.requirementType)
			{
				return StatusRequirement.CheckPreview(combatant, this.req, this.needed);
			}
			else if(StatusRequirementType.Template == this.requirementType)
			{
				return ORK.StatusRequirementTemplates.Get(this.templateID).CheckRequirementPreview(combatant);
			}
			return false;
		}

		public bool CheckRequirementBestiary(Combatant combatant)
		{
			if(StatusRequirementType.Status == this.requirementType)
			{
				return this.status.settings.CheckBestiary(combatant);
			}
			else if(StatusRequirementType.Requirements == this.requirementType)
			{
				return StatusRequirement.CheckBestiary(combatant, this.req, this.needed);
			}
			else if(StatusRequirementType.Template == this.requirementType)
			{
				return ORK.StatusRequirementTemplates.Get(this.templateID).CheckRequirementBestiary(combatant);
			}
			return false;
		}

		public static bool Check(Combatant combatant, StatusRequirement[] req, Needed needed)
		{
			if(req.Length > 0)
			{
				for(int i = 0; i < req.Length; i++)
				{
					if(req[i].CheckRequirement(combatant))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}

		public static bool CheckPreview(Combatant combatant, StatusRequirement[] req, Needed needed)
		{
			if(req.Length > 0)
			{
				for(int i = 0; i < req.Length; i++)
				{
					if(req[i].CheckRequirementPreview(combatant))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}

		public static bool CheckBestiary(Combatant combatant, StatusRequirement[] req, Needed needed)
		{
			if(req.Length > 0)
			{
				for(int i = 0; i < req.Length; i++)
				{
					if(req[i].CheckRequirementBestiary(combatant))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public void RegisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			if(StatusRequirementType.Status == this.requirementType)
			{
				this.status.settings.Register(combatant, notify);
			}
			else if(StatusRequirementType.Requirements == this.requirementType)
			{
				for(int i = 0; i < this.req.Length; i++)
				{
					this.req[i].RegisterStatusChanges(combatant, notify);
				}
			}
			else if(StatusRequirementType.Template == this.requirementType)
			{
				ORK.StatusRequirementTemplates.Get(this.templateID).RegisterStatusChanges(combatant, notify);
			}
		}

		public void UnregisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			if(StatusRequirementType.Status == this.requirementType)
			{
				this.status.settings.Unregister(combatant, notify);
			}
			else if(StatusRequirementType.Requirements == this.requirementType)
			{
				for(int i = 0; i < this.req.Length; i++)
				{
					this.req[i].UnregisterStatusChanges(combatant, notify);
				}
			}
			else if(StatusRequirementType.Template == this.requirementType)
			{
				ORK.StatusRequirementTemplates.Get(this.templateID).UnregisterStatusChanges(combatant, notify);
			}
		}
	}
}
