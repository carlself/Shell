﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class SpeedControl : BaseData
	{
		[ORKEditorHelp("Speed", "The speed used that will be used.", "")]
		public float speed = 5;

		[ORKEditorHelp("Use Speed Key", "Use a different speed while holding down an input key.", "")]
		public bool useInputKey = false;

		[ORKEditorHelp("Speed Key", "The input key used to change the speed.\n" +
			"The different speed will be used while the input key receives input (e.g. using 'Hold' input handling).", "")]
		[ORKEditorInfo(ORKDataType.InputKey, indent=true)]
		[ORKEditorLayout("useInputKey", true)]
		public int inputKey = 0;

		[ORKEditorHelp("Input Panning Speed", "The speed used for while holding down the speed key.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float inputSpeed = 10;

		public SpeedControl()
		{

		}

		public SpeedControl(float speed)
		{
			this.speed = speed;
			this.inputSpeed = speed * 2;
		}

		public float GetSpeed()
		{
			if(this.useInputKey && ORK.InputKeys.Get(this.inputKey).GetButton())
			{
				return this.inputSpeed;
			}
			else
			{
				return this.speed;
			}
		}
	}
}
