
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Formulas
{
	public class ChanceFormulaNextNode : BaseData
	{
		[ORKEditorInfo(labelText="Minimum Range")]
		public FormulaFloat minimum = new FormulaFloat();

		[ORKEditorInfo(separator=true, labelText="Maximum Range")]
		public FormulaFloat maximum = new FormulaFloat();

		[ORKEditorInfo(hide=true)]
		public int next = -1;

		public ChanceFormulaNextNode()
		{

		}

		public bool Contains(float chance, FormulaCall call)
		{
			return this.minimum.GetValue(call) <= chance &&
				chance <= this.maximum.GetValue(call);
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return this.minimum.GetInfoText() + " - " + this.maximum.GetInfoText();
		}
	}
}
