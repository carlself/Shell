
using UnityEngine;

namespace ORKFramework
{
	public class PlayAudioSettings : BaseData
	{
		[ORKEditorHelp("Play One Shot", "Uses the PlayOneShot function of the AudioSource component to play the audio clip.", "")]
		public bool oneShot = false;

		// advanced settings
		[ORKEditorHelp("Advanced Settings", "Change settings of the AudioSource component used to play the clip.", "")]
		[ORKEditorInfo(separator=true)]
		public bool advSet = false;

		[ORKEditorHelp("Volume", "The volume this audio clip is played at.", "")]
		[ORKEditorLayout(new string[] {"oneShot", "advSet"},
			new System.Object[] {true, true}, needed=Needed.One, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float volume = 1;

		[ORKEditorHelp("Minimum Distance", "Within the minimum distance the AudioSource will cease to grow louder in volume.", "")]
		[ORKEditorLayout("advSet", true)]
		[ORKEditorLimit(0.0f, false)]
		public float minD = 0;

		[ORKEditorHelp("Maximum Distance", "(Logarithmic rolloff) Maximum distance is the distance a sound stops attenuating at.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float maxD = 100;

		[ORKEditorHelp("Rolloff Mode", "Sets how the AudioSource attenuates over distance.", "")]
		public AudioRolloffMode rolloff = AudioRolloffMode.Linear;

		[ORKEditorHelp("Pitch", "The pitch of the audio source.", "")]
		public float pitch = 1;

		[ORKEditorHelp("Loop", "The audio clip will loop.", "")]
		public bool loop = false;

		[ORKEditorHelp("Ignore Listener Vol.", "This makes the AudioSource not take into account the volume of the AudioListener.", "")]
		public bool ignoreLV = false;

		[ORKEditorHelp("Set Pan", "Set the AudioSource spatial blend and pan stereo settings.", "")]
		public bool setPan = false;

		[ORKEditorHelp("Spatial Blend", "Sets how much this AudioSource is affected by 3D spatialisation calculations " +
			"(attenuation, doppler etc).\n" +
			"0.0 makes the sound full 2D, 1.0 makes it full 3D.", "")]
		[ORKEditorLayout("setPan", true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float panLevel = 0;

		[ORKEditorHelp("Pan Stereo", "Pans a playing sound in a stereo way (left or right). " +
			"This only applies to sounds that are Mono or Stereo.\n" +
			"Only works for 2D clips. -1.0 is full left, 0.0 is center, 1.0 is full right.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(-1.0f, 1.0f)]
		public float pan = 0;

		public PlayAudioSettings()
		{

		}

		public float PlayAudio(GameObject obj, AudioClip clip)
		{
			return this.PlayAudio(ComponentHelper.Get<AudioSource>(obj), clip);
		}

		public float PlayAudio(AudioSource audio, AudioClip clip)
		{
			if(audio != null)
			{
				if(this.advSet)
				{
					audio.pitch = this.pitch;
					audio.volume = this.volume * ORK.Audio.SoundVolume;
					audio.rolloffMode = this.rolloff;
					audio.minDistance = this.minD;
					audio.maxDistance = this.maxD;
					audio.loop = this.loop;
					audio.ignoreListenerVolume = this.ignoreLV;
					if(this.setPan)
					{
						audio.spatialBlend = this.panLevel;
						audio.panStereo = this.pan;
					}
				}
				if(this.oneShot)
				{
					ComponentHelper.PlayOneShot(audio.gameObject, clip, this.volume);
				}
				else
				{
					audio.clip = clip;
					audio.Play();
				}
				return clip.length;
			}
			return 0;
		}

		public float PlayAudio(SoundChannel channel, AudioClip clip)
		{
			if(channel != null)
			{
				if(this.advSet)
				{
					channel.Source.pitch = this.pitch;
					channel.Source.volume = this.volume * ORK.Audio.SoundVolume;
					channel.Source.rolloffMode = this.rolloff;
					channel.Source.minDistance = this.minD;
					channel.Source.maxDistance = this.maxD;
					channel.Source.loop = this.loop;
					channel.Source.ignoreListenerVolume = this.ignoreLV;
					if(this.setPan)
					{
						channel.Source.spatialBlend = this.panLevel;
						channel.Source.panStereo = this.pan;
					}
				}
				if(this.oneShot)
				{
					channel.PlayOneShot(clip, this.volume);
				}
				else
				{
					channel.Source.clip = clip;
					channel.Source.Play();
				}
				return clip.length;
			}
			return 0;
		}
	}
}

