﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Formulas
{
	public class FormulaSelectedDataOrigin : BaseData
	{
		// variable settings
		[ORKEditorHelp("Data Origin", "Select the origin of the selected data:\n" +
			"- Local: Local data is only used in a running event and don't interfere with global data. " +
			"The data will be gone once the event ends.\n" +
			"- Global: Global data is persistent and available everywhere, everytime.\n" +
			"- Object: Object data is bound to objects in the scene by an object ID (using an 'Object Variables' component).\n" +
			"- Object ID: Object data is bound to objects in the scene by an object ID (using a defined object ID).\n\n" +
			"Selected data is not saved in save games.", "")]
		public SelectedDataOrigin origin = SelectedDataOrigin.Local;


		// object
		[ORKEditorInfo(labelText="Object", indent=true)]
		[ORKEditorLayout("origin", SelectedDataOrigin.Object, endCheckGroup=true, autoInit=true)]
		public FormulaStatusOrigin fromObject;


		// object ID
		[ORKEditorInfo(labelText="Object ID", indent=true)]
		[ORKEditorLayout("origin", SelectedDataOrigin.ObjectID, endCheckGroup=true, autoInit=true)]
		public FormulaString objectID;

		public FormulaSelectedDataOrigin()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(SelectedDataOrigin.Object == this.origin)
			{
				if(this.fromObject == null)
				{
					this.fromObject = new FormulaStatusOrigin();
				}
			}
			else if(SelectedDataOrigin.ObjectID == this.origin)
			{
				if(this.objectID == null)
				{
					this.objectID = new FormulaString();
				}
			}
		}

		public string GetInfoText()
		{
			return this.origin.ToString();
		}


		/*
		============================================================================
		Handler functions
		============================================================================
		*/
		public SelectedDataHandler Get(FormulaCall call)
		{
			if(SelectedDataOrigin.Local == this.origin)
			{
				return call.SelectedData;
			}
			else if(SelectedDataOrigin.Global == this.origin)
			{
				return ORK.Game.SelectedData;
			}
			else if(SelectedDataOrigin.Object == this.origin)
			{
				Combatant combatant = this.fromObject.GetCombatant(call);
				if(combatant != null)
				{
					return combatant.SelectedData;
				}
			}
			else if(SelectedDataOrigin.ObjectID == this.origin)
			{
				return ORK.Game.Scene.GetObjectSelectedData(this.objectID.GetValue(call));
			}
			return null;
		}


		/*
		============================================================================
		Clear functions
		============================================================================
		*/
		public void Clear(FormulaCall call)
		{
			if(SelectedDataOrigin.Local == this.origin)
			{
				call.SelectedData.Clear();
			}
			else if(SelectedDataOrigin.Global == this.origin)
			{
				ORK.Game.SelectedData.Clear();
			}
			else if(SelectedDataOrigin.Object == this.origin)
			{
				Combatant combatant = this.fromObject.GetCombatant(call);
				if(combatant != null &&
					combatant.HasSelectedData)
				{
					combatant.SelectedData.Clear();
				}
			}
			else if(SelectedDataOrigin.ObjectID == this.origin)
			{
				string tmpID = this.objectID.GetValue(call);
				if(ORK.Game.Scene.ObjectSelectedDataExist(tmpID))
				{
					ORK.Game.Scene.GetObjectSelectedData(tmpID).Clear();
				}
			}
		}

		public void Clear(FormulaCall call, string selectedKey)
		{
			SelectedDataHandler handler = this.Get(call);
			if(handler != null)
			{
				handler.Change(selectedKey, null, ListChangeType.Clear);
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public int GetCount(FormulaCall call, string selectedKey)
		{
			SelectedDataHandler handler = this.Get(call);
			if(handler != null)
			{
				return handler.GetCount(selectedKey);
			}
			return 0;
		}

		public List<object> GetSelectedData(FormulaCall call, string selectedKey)
		{
			List<object> list = new List<object>();
			SelectedDataHandler handler = this.Get(call);
			if(handler != null)
			{
				List<object> tmpList = handler.Get(selectedKey);
				if(tmpList != null)
				{
					list.AddRange(tmpList);
				}
			}
			return list;
		}

		public void Change(FormulaCall call, string selectedKey, object data, ListChangeType changeType)
		{
			SelectedDataHandler handler = this.Get(call);
			if(handler != null)
			{
				handler.Change(selectedKey, data, changeType);
			}
		}
	}
}
