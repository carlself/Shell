﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public enum VisibilityCheckType { RendererIsVisible, CameraViewport, FrustumPlanes }

	public class VisibilityCheck : BaseData
	{
		[ORKEditorHelp("Visibility Check", "Select how visibility will be checked:\n" +
			"- Renderer Is Visible: Checks if the renderer is visible by any camera ('Renderer.isVisible').\n" +
			"- Camera Viewport: Checks if the renderer's position is within " +
			"the main camera's viewport ('Camera.WorldToViewportPoint').\n" +
			"- Frustum Planes: Checks if the renderer's bounds are within " +
			"the frustum planes of the main camera ('GeometryUtility.CalculateFrustumPlanes')", "")]
		public VisibilityCheckType type = VisibilityCheckType.RendererIsVisible;


		// viewport
		[ORKEditorHelp("Viewport Padding", "Define the padding that will be added to viewport checks.\n" +
			"Positive values will expand the viewport, negative values will contract the viewport.\n" +
			"A viewport position is visible if the x and y axes is between 0 and 1 and the z axis is 0 or greater.", "")]
		[ORKEditorLayout("type", VisibilityCheckType.CameraViewport, endCheckGroup=true)]
		public Vector3 viewportPadding = Vector3.zero;


		// in-game
		private static VisibilityCheck instance;

		public VisibilityCheck()
		{

		}

		public bool CheckVisibility(Renderer renderer)
		{
			if(renderer != null)
			{
				if(VisibilityCheckType.RendererIsVisible == this.type)
				{
					return renderer.isVisible;
				}
				else if(VisibilityCheckType.CameraViewport == this.type)
				{
					if(ORK.Game.Camera != null)
					{
						Vector3 point = ORK.Game.Camera.WorldToViewportPoint(renderer.transform.position);
						return point.x >= 0.0f - this.viewportPadding.x &&
							point.x <= 1.0f + this.viewportPadding.x &&
							point.y >= 0.0f - this.viewportPadding.y &&
							point.y <= 1.0f + this.viewportPadding.y &&
							point.z >= 0.0f - this.viewportPadding.z;
					}
				}
				else if(VisibilityCheckType.FrustumPlanes == this.type)
				{
					if(ORK.Game.Camera != null)
					{
						Plane[] planes = GeometryUtility.CalculateFrustumPlanes(ORK.Game.Camera);
						return GeometryUtility.TestPlanesAABB(planes, renderer.bounds);
					}
				}
			}
			return false;
		}

		public static bool IsVisible(Renderer renderer)
		{
			if(instance == null)
			{
				instance = ORK.GameSettings.visibilityCheck;
			}
			return instance.CheckVisibility(renderer);
		}
	}
}
