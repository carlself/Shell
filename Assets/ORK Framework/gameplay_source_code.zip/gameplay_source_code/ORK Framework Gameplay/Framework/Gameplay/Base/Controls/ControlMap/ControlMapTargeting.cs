﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ControlMapTargeting : BaseData
	{
		// cursor target
		[ORKEditorHelp("Only Cursor Over Target", "The control map key can only be used when the cursor is over a valid target.", "")]
		public bool onlyCursorOverTarget = false;

		[ORKEditorHelp("Only In Range", "Cursor over targets will only be used when the target is in range.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("onlyCursorOverTarget", true, endCheckGroup=true)]
		public bool cursorOverInRange = false;

		[ORKEditorHelp("Use Cursor Over Target", "Use the combatant the cursor is over as the action's target.\n" +
			"If the cursor isn't over a valid target, the auto target or target selection will be used.", "")]
		public bool useCursorOverTarget = false;


		// auto target
		[ORKEditorHelp("Use Auto Target", "Automatically selects the action's targets using " +
			"the 'Auto Targets' settings of abilities/items or the user's AI settings.\n" +
			"The group target is ignored.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useAutoTarget = false;

		[ORKEditorHelp("Auto Target Only", "Only use auto target for abilities/items that have " +
			"'Use Auto Target' enabled in their settings.", "")]
		[ORKEditorLayout("useAutoTarget", true, endCheckGroup=true)]
		public bool autoTargetOnly = false;


		// target selections
		[ORKEditorHelp("Use Group Target", "Automatically use a group target for abilities and items (if available).", "")]
		[ORKEditorInfo(separator=true)]
		public bool useGroupTarget = true;

		[ORKEditorHelp("Use Individual Target", "Automatically use an individual target for abilities and items (if available).", "")]
		public bool useIndividualTarget = true;

		[ORKEditorHelp("Prioritize Raycast", "Raycast targeting of 'None' target range abilities/items will be used even if group/individual targets are available.\n" +
			"If disabled, the group/individual target will be used instead of raycast targeting.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout(new string[] { "useGroupTarget", "useIndividualTarget" },
			new object[] { true, true },
			needed=Needed.One, endCheckGroup=true)]
		public bool prioritizeRaycast = false;

		[ORKEditorHelp("No Target Selection", "The control map key will not bring up any target selection if auto or cursor targeting fails.\n" +
			"Using the key will fail in that case.", "")]
		public bool noTargetSelection = false;

		[ORKEditorHelp("Need Targets", "Actions that need target selection require possible targets to display the battle menu.\n" +
			"If no targets are available, the action wont be used and no target menu displayed.\n" +
			"If disabled, the action will display an empty target menu.", "")]
		[ORKEditorLayout("noTargetSelection", false, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool needTargets = false;


		// static
		public static readonly ControlMapTargeting Default = new ControlMapTargeting(
			false, false, false, true, false, true, true, false, false, false);

		public ControlMapTargeting()
		{

		}

		public ControlMapTargeting(bool onlyCursorOverTarget, bool cursorOverInRange, bool useCursorOverTarget,
			bool useAutoTarget, bool autoTargetOnly,
			bool useGroupTarget, bool useIndividualTarget, bool prioritizeRaycast,
			bool noTargetSelection, bool needTargets)
		{
			this.onlyCursorOverTarget = onlyCursorOverTarget;
			this.cursorOverInRange = cursorOverInRange;
			this.useCursorOverTarget = useCursorOverTarget;
			this.useAutoTarget = useAutoTarget;
			this.autoTargetOnly = autoTargetOnly;
			this.useGroupTarget = useGroupTarget;
			this.useIndividualTarget = useIndividualTarget;
			this.prioritizeRaycast = prioritizeRaycast;
			this.noTargetSelection = noTargetSelection;
			this.needTargets = needTargets;
		}
	}
}
