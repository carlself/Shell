﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("AI Type", "A defined AI type must or mustn't be equipped on an AI behaviour slot or AI ruleset slot.", "")]
	public class AITypeRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("AI Type", "Select the AI type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.AIType)]
		public int aiTypeID = 0;

		[ORKEditorHelp("Use Sub-Types", "The sub-types of the defined AI type will also be checked.", "")]
		[ORKEditorInfo(indent=true)]
		public bool useSubTypes = false;

		[ORKEditorHelp("Is Equipped", "The AI type must be equipped in one of the combatant's AI slots.\n" +
			"If disabled, the AI type mustn't be equipped.", "")]
		public bool isEquipped = true;

		public AITypeRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.aiTypeID);
				data.Get("aiEquipped", ref this.isEquipped);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.AI.IsAITypeEquipped(this.aiTypeID, this.useSubTypes) == this.isEquipped;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.AI.Changed += notify.CombatantAIChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.AI.Changed -= notify.CombatantAIChanged;
		}
	}
}
