﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class AutoAnimationSetting : BaseData
	{
		[ORKEditorHelp("Use Auto Animation", "ORK will automatically handle movement animations " +
			"(idle, walk, run, sprint, fall, land) based on the combatant's movement.\n" +
			"If disabled, you'll have to manage the movement animations with your own scripts.\n" +
			"The auto animation can also be enabled/disabled using the event system.", "")]
		public bool enabled = false;

		[ORKEditorHelp("Initial State", "If enabled, the auto animation starts enabled.\n" +
			"If disabled, the auto animation is disabled when creating the combatant.", "")]
		[ORKEditorLayout("enabled", true)]
		public bool initialState = true;

		[ORKEditorHelp("Minimum Fall Time (s)", "The minimum fall time in seconds to play the land animation.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float minFallTime = 0.3f;


		// run speed
		[ORKEditorHelp("Minimum Run Speed", "The minimum speed to play the run animation.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLimit(0.0f, false)]
		public float minRunSpeed = 3;

		[ORKEditorHelp("Run Speed Threshold", "The threshold is used for a smoother change between walk/run animations.\n" +
			"The run animation will be played when the combatant's speed is above 'Minimum Run Speed + threshold', " +
			"the walk animation will be played again when the speed is below 'Minimum Run Speed - threshold'.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float runSpeedThreshold = 0;


		// sprint speed
		[ORKEditorHelp("Minimum Sprint Speed", "The minimum speed to play the sprint animation.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLimit(0.0f, false)]
		public float minSprintSpeed = 6;

		[ORKEditorHelp("Sprint Speed Threshold", "The threshold is used for a smoother change between run/sprint animations.\n" +
			"The sprint animation will be played when the combatant's speed is above 'Minimum Sprint Speed + threshold', " +
			"the run animation will be played again when the speed is below 'Minimum Sprint Speed - threshold'.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float sprintSpeedThreshold = 0;


		// speed change delay
		[ORKEditorHelp("Use Speed Change Delay", "Delay animation changes when the speed change exceeds a defined value.\n" +
			"E.g. use this when a short stop (e.g. between two movement nodes) causes an unwanted animation change.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useSpeedChangeDelay = false;

		[ORKEditorHelp("Minimum Speed Change", "The minimum speed change that must happen to trigger the animation delay.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("useSpeedChangeDelay", true)]
		public float minSpeedChange = 1;

		[ORKEditorHelp("Delay (s)", "The time in seconds the animation change will be delayed.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float speedChangeDelay = 0.1f;


		// forward animations
		[ORKEditorHelp("Use Forward Animation", "Use different walk, run or sprint animation types when moving forward.\n" +
			"In 'XY' horizontal plane mode, the forward/backward movement uses the Y-axis.", "")]
		[ORKEditorInfo(separator=true, labelText="Forward Move Animation")]
		public bool useForwardAnimations = false;

		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("useForwardAnimations", true, endCheckGroup=true)]
		public MoveAnimations forwardAnimations = new MoveAnimations();


		// backward animations
		[ORKEditorHelp("Use Backward Animation", "Use different walk, run or sprint animation types when moving backward.\n" +
			"In 'XY' horizontal plane mode, the forward/backward movement uses the Y-axis.", "")]
		[ORKEditorInfo(separator=true, labelText="Backward Move Animation")]
		public bool useBackwardAnimations = false;

		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("useBackwardAnimations", true, endCheckGroup=true)]
		public MoveAnimations backwardAnimations = new MoveAnimations();


		// left animations
		[ORKEditorHelp("Use Left Animation", "Use different walk, run or sprint animation types when moving left.", "")]
		[ORKEditorInfo(separator=true, labelText="Left Move Animation")]
		public bool useLeftAnimations = false;

		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("useLeftAnimations", true)]
		public MoveAnimations leftAnimations = new MoveAnimations();

		[ORKEditorHelp("Left Min Value", "The minimum value the movement direction must have to use left movement animations.\n" +
			"The direction value must be equal or below the defined value.\n" +
			"The movement direction is checked using a normalized Vector3 value, left-side movement is usually a negative value.\n" +
			"E.g. -1 would be full left, -0.5 would be forward/backward-left.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorLimit(0.0f, true)]
		public float leftMinValue = -0.5f;


		// right animations
		[ORKEditorHelp("Use Right Animation", "Use different walk, run or sprint animation types when moving right.", "")]
		[ORKEditorInfo(separator=true, labelText="Right Move Animation")]
		public bool useRightAnimations = false;

		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("useRightAnimations", true)]
		public MoveAnimations rightAnimations = new MoveAnimations();

		[ORKEditorHelp("Right Min Value", "The minimum value the movement direction must have to use right movement animations.\n" +
			"The direction value must be equal or above the defined value.\n" +
			"The movement direction is checked using a normalized Vector3 value, right-side movement is usually a positive value.\n" +
			"E.g. 1 would be full left, 0.5 would be forward/backward-left.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, false)]
		public float rightMinValue = 0.5f;

		public AutoAnimationSetting()
		{

		}

		public bool IsDirectional
		{
			get
			{
				return this.useForwardAnimations ||
					this.useBackwardAnimations ||
					this.useLeftAnimations ||
					this.useRightAnimations;
			}
		}
	}
}
