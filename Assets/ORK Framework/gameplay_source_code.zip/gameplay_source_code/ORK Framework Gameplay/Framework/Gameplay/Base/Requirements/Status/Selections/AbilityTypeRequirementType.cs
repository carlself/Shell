﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Ability Type", "The combatant must or mustn't have an ability of a selected ability type.", "")]
	public class AbilityTypeRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Ability Type", "Select the ability type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.AbilityType)]
		public int abilityTypeID = 0;

		[ORKEditorHelp("Use Sub-Types", "The sub-types of the defined ability type will also be checked.", "")]
		[ORKEditorInfo(indent=true)]
		public bool useSubTypes = false;

		[ORKEditorHelp("Is Valid", "The combatant must have an ability of the defined type.\n" +
			"If disabled, the combatant mustn't have the ability type.", "")]
		public bool isValid = true;


		// filters
		[ORKEditorHelp("Check Attacks", "The combatant's base attacks will be checked.", "")]
		[ORKEditorInfo(separator=true)]
		public bool checkAttacks = false;

		[ORKEditorHelp("Check Counter", "The combatant's counter attack will be checked.", "")]
		public bool checkCounter = false;

		[ORKEditorHelp("Check Class Ability", "The combatant's class ability will be checked.", "")]
		public bool checkClass = false;

		[ORKEditorHelp("Check Active Abilities", "The combatant's active abilities will be checked.", "")]
		public bool checkActive = true;

		[ORKEditorHelp("Check Passive Abilities", "The combatant's passive abilities will be checked.", "")]
		public bool checkPassive = true;

		[ORKEditorHelp("Check Temporary Abilities", "Select if temporary abilities will be checked:\n" +
			"- Yes: Temporary abilities will be checked.\n" +
			"- No: Temporary abilities will not be checked.\n" +
			"- Only: Only temporary abilities will be checked.", "")]
		public IncludeCheckType checkTemporary = IncludeCheckType.Yes;

		public AbilityTypeRequirementType()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.isValid == combatant.Abilities.HasType(this.useSubTypes, this.abilityTypeID,
				this.checkAttacks, this.checkCounter, this.checkClass, this.checkActive, this.checkPassive, this.checkTemporary, false);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Abilities.AbilitiesChanged += notify.AbilitiesChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Abilities.AbilitiesChanged -= notify.AbilitiesChanged;
		}
	}
}
