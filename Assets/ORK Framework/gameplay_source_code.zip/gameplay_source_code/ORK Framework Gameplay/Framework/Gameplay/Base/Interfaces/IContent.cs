
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IContent : IContentSimple
	{
		int TypeID
		{
			get;
		}
		
		IContentSimple GetTypeContent();
		
		string GetInfo(Combatant c);
	}
}
