﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface ITargetRange
	{
		/*
		============================================================================
		Target range functions
		============================================================================
		*/
		bool IsNoneTarget();

		bool IsSingleTarget();

		bool IsGroupTarget();

		bool ToggleTargetRange();
	}
}
