
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Animations
{
	public class Sound : BaseData
	{
		[ORKEditorHelp("Sound Type", "Select the sound type of this sound.", "")]
		[ORKEditorInfo(ORKDataType.SoundType)]
		public int typeID = 0;
		
		[ORKEditorHelp("Audio Clip", "Select the audio clip that will be used when playing this sound.", "")]
		public AssetSource<AudioClip> audioClip = new AssetSource<AudioClip>();
		
		public Sound()
		{
			
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.audioClip.Upgrade(data, "audioClip");
		}
	}
}
