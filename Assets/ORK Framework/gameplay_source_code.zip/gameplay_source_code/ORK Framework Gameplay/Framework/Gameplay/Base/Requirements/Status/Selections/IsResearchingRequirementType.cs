﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Is Researching", "The combatant must or mustn't be researching a research item.", "")]
	public class IsResearchingRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Is Researching", "The combatant must be researching.\n" +
			"If disabled, the combatant mustn't be researching.", "")]
		public bool isResearching = true;

		public IsResearchingRequirementType()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return (combatant.Research.InResearch > 0) == this.isResearching;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Research.Changed += notify.CombatantResearchChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Research.Changed -= notify.CombatantResearchChanged;
		}
	}
}
