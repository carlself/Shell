﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Status Value", "The selected status value will be compared to a defined value.", "")]
	public class StatusValueRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Status Value", "Select the status value that will be used.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue)]
		public int statusValueID = 0;

		[ORKEditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the status value.\n" +
			"- Base Value: The base value of the status value (without bonuses).\n" +
			"- Min Value: The minimum value of the status value.\n" +
			"- Max Value: The maximum value of the status value.\n" +
			"- Display Value: The currently displayed value of the status value (e.g. when using 'Count To Value').\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Max Value: The preview maximum value, displaying changes when an equipment would be equipped.", "")]
		public StatusValueGetValue getValue = StatusValueGetValue.CurrentValue;


		// compare with other
		[ORKEditorHelp("Compare With Other", "Compares the selected status value with the current value of another status value.\n" +
			"If disabled, the status value is compared with a defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public bool compareWithOther = false;

		[ORKEditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than the defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorLayout("compareWithOther", true)]
		public ValueCheckType otherCheckType = ValueCheckType.IsEqual;

		// other status
		[ORKEditorHelp("Other Status Value", "Select the status value that will be used for the comparison.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, separator=true)]
		public int otherStatusValueID = 0;

		[ORKEditorHelp("Other Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the status value.\n" +
			"- Base Value: The base value of the status value (without bonuses).\n" +
			"- Min Value: The minimum value of the status value.\n" +
			"- Max Value: The maximum value of the status value.\n" +
			"- Display Value: The currently displayed value of the status value (e.g. when using 'Count To Value').\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Max Value: The preview maximum value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Min Value: The preview minimum value, displaying changes when an equipment would be equipped.", "")]
		public StatusValueGetValue otherGetValue = StatusValueGetValue.CurrentValue;

		// other status 2
		[ORKEditorHelp("Other Status Value 2", "Select the status value that will be used for the comparison (upper limit).", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, separator=true)]
		[ORKEditorLayout(new string[] { "otherCheckType", "otherCheckType" } ,
			new System.Object[] { ValueCheckType.RangeInclusive, ValueCheckType.RangeExclusive },
			needed=Needed.One)]
		public int otherStatusValueID2 = 0;

		[ORKEditorHelp("Other Used Value 2", "Select which value will be used:\n" +
			"- Current Value: The current value of the status value.\n" +
			"- Base Value: The base value of the status value (without bonuses).\n" +
			"- Min Value: The minimum value of the status value.\n" +
			"- Max Value: The maximum value of the status value.\n" +
			"- Display Value: The currently displayed value of the status value (e.g. when using 'Count To Value').\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Max Value: The preview maximum value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Min Value: The preview minimum value, displaying changes when an equipment would be equipped.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public StatusValueGetValue otherGetValue2 = StatusValueGetValue.CurrentValue;


		// check value
		[ORKEditorHelp("Check In", "The value is either in percent of the maximum status value or an absolute value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public ValueSetter setter = ValueSetter.Value;

		[ORKEditorLayout(endCheckGroup=true)]
		public ValueCheck check = new ValueCheck();

		public StatusValueRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.statusValueID);
				data.GetEnum("svGetValue", ref this.getValue);
				data.GetEnum("svOtherGetValue", ref this.otherGetValue);
			}
			if(data.Contains<int>("comparison"))
			{
				if(this.compareWithOther)
				{
					ValueCheck.UpgradeOldType(data, "comparison", ref this.otherCheckType);
				}
				else if(data.Contains<int>("selectionID"))
				{
					this.check.UpgradeFloat(data, "comparison", "value");
				}
				else
				{
					this.check.UpgradeInt(data, "comparison", "value");
				}
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			float value = combatant.Status[this.statusValueID].GetCompareValue(this.getValue, this.setter);
			if(this.compareWithOther)
			{
				return ValueHelper.CheckValue(value,
					combatant.Status[this.otherStatusValueID].GetTypeValue(this.otherGetValue),
					ValueCheckType.RangeInclusive == this.otherCheckType || ValueCheckType.RangeExclusive == this.otherCheckType ?
						combatant.Status[this.otherStatusValueID2].GetTypeValue(this.otherGetValue2) : 0,
					this.otherCheckType);
			}
			else
			{
				return this.check.Check(value, combatant);
			}
		}

		public override bool CheckPreview(Combatant combatant)
		{
			float value = combatant.Status[this.statusValueID].GetCompareValuePreview(this.setter);
			if(this.compareWithOther)
			{
				return ValueHelper.CheckValue(value,
					combatant.Status[this.otherStatusValueID].GetPreviewValue(false),
					ValueCheckType.RangeInclusive == this.otherCheckType || ValueCheckType.RangeExclusive == this.otherCheckType ?
						combatant.Status[this.otherStatusValueID2].GetPreviewValue(false) : 0,
					this.otherCheckType);
			}
			else
			{
				return this.check.Check(value, combatant);
			}
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null &&
				(combatant.Bestiary.IsComplete || combatant.Bestiary.status.statusValues))
			{
				return this.Check(combatant);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			StatusValue sv = combatant.Status[this.statusValueID];
			sv.ValueChanged += notify.StatusValueChanged;
			if(sv.IsConsumable())
			{
				combatant.Status[sv.Setting.maxStatusID].ValueChanged += notify.StatusValueChanged;
			}
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			StatusValue sv = combatant.Status[this.statusValueID];
			sv.ValueChanged -= notify.StatusValueChanged;
			if(sv.IsConsumable())
			{
				combatant.Status[sv.Setting.maxStatusID].ValueChanged -= notify.StatusValueChanged;
			}
		}
	}
}
