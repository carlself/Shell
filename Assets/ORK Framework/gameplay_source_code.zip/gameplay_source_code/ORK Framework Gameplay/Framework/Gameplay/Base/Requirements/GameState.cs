
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class GameState : BaseData
	{
		// player control
		[ORKEditorHelp("In Control", "Select the required player control state:\n" +
			"- Yes: The player can be controlled.\n" +
			"- No: The player can't be controlled.\n" +
			"- Ignore: Player control state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider inControl = Consider.Ignore;

		[ORKEditorHelp("Shop", "Select the required shop state:\n" +
			"- Yes: A control blocking shop is displayed.\n" +
			"- No: No control blocking shop is displayed.\n" +
			"- Ignore: Shop state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider inShop = Consider.Ignore;


		// event/scene change
		[ORKEditorHelp("In Event", "Select the required event state:\n" +
			"- Yes: In a blocking event.\n" +
			"- No: Not in a blocking event.\n" +
			"- Ignore: Event state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider inEvent = Consider.Ignore;

		[ORKEditorHelp("Changing Scene", "Select the required scene change state:\n" +
			"- Yes: Changing scenes.\n" +
			"- No: Not changing scenes.\n" +
			"- Ignore: Scene changes are ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider inSceneChange = Consider.Ignore;


		// pause
		[ORKEditorHelp("Game Paused", "Select the required game pause state:\n" +
			"- Yes: The game is paused.\n" +
			"- No: The game isn't paused.\n" +
			"- Ignore: Pause state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider inPause = Consider.Ignore;


		// battle
		[ORKEditorHelp("In Battle", "Select the required battle state:\n" +
			"- Yes: In a battle.\n" +
			"- No: Outside of battles.\n" +
			"- Ignore: Battle state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50, separator=true,
			labelText="Battle Types")]
		public Consider inBattle = Consider.Ignore;

		[ORKEditorHelp("Target Selection", "Select the required target selection state:\n" +
			"- Yes: A player group member must currently be selecting a target for an action.\n" +
			"- No: No player group member must currently be selecting a target for an action.\n" +
			"- Ignore: Target selection state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		[ORKEditorLayout("inBattle", Consider.No, elseCheckGroup=true)]
		public Consider targetSelection = Consider.Ignore;

		[ORKEditorHelp("Performing Action", "Select the required performing action state:\n" +
			"- Yes: A battle action must currently be performing.\n" +
			"- No: No battle action must currently be performing.\n" +
			"- Ignore: Performing action state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		[ORKEditorLayout(endCheckGroup=true)]
		public Consider performingAction = Consider.Ignore;

		// battle system types
		[ORKEditorLayout("inBattle", Consider.Yes, endCheckGroup=true)]
		public BattleSystemCheck battleSystemCheck = new BattleSystemCheck();


		// menu screens
		[ORKEditorHelp("Blocking Menu Screen", "Select the required menu state:\n" +
			"- Yes: A control blocking menu screen is displayed.\n" +
			"- No: No control blocking menu screen is displayed.\n" +
			"- Ignore: Menu screen state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50, separator=true,
			labelText="Menu Screens")]
		public Consider inMenu = Consider.Ignore;

		[ORKEditorHelp("Opened Menu Screen", "Select the menu screen that must be opened.", "")]
		[ORKEditorInfo(ORKDataType.MenuScreen, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Menu Screen", "Adds a menu screen - " +
			"only one of the added menu screens has to be opened.\n" +
			"Add none to ignore which menu screen is opened.", "",
			"Remove", "Removes this menu screen.", "", isHorizontal=true)]
		[ORKEditorLayout("inMenu", Consider.Yes, endCheckGroup=true)]
		public int[] screenID = new int[0];

		public GameState()
		{

		}

		public GameState(Consider consider)
		{
			this.inControl = consider;
			this.inMenu = consider;
			this.inShop = consider;
			this.inEvent = consider;
			this.inSceneChange = consider;
			this.inPause = consider;
			this.inBattle = consider;
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			if(data.Contains<bool>("turnBased"))
			{
				this.battleSystemCheck.SetData(data);
			}
		}

		public virtual bool Check()
		{
			return (Consider.Ignore == this.inControl ||
					(Consider.No == this.inControl) == ORK.Control.Blocked) &&
				(Consider.Ignore == this.inShop ||
					(Consider.Yes == this.inShop) == ORK.Control.InShop) &&
				(Consider.Ignore == this.inEvent ||
					(Consider.Yes == this.inEvent) == ORK.Control.InEvent) &&
				(Consider.Ignore == this.inSceneChange ||
					(Consider.Yes == this.inSceneChange) == ORK.Control.ChangingScene) &&
				(Consider.Ignore == this.inPause ||
					(Consider.Yes == this.inPause) == ORK.Game.Paused) &&
				this.CheckBattle() &&
				// menu screens
				(Consider.Ignore == this.inMenu ||
					(Consider.No == this.inMenu && !ORK.Control.InMenu) ||
					((Consider.Yes == this.inMenu) == ORK.Control.InMenu &&
					this.CheckMenuScreens()));
		}

		protected virtual bool CheckBattle()
		{
			if(Consider.No == this.inBattle)
			{
				return !ORK.Control.InBattle;
			}
			else if(Consider.Ignore == this.inBattle)
			{
				return this.CheckTargetSelection() &&
					this.CheckPerformingAction();
			}
			else if(Consider.Yes == this.inBattle)
			{
				return ORK.Control.InBattle &&
					this.battleSystemCheck.Check() &&
					this.CheckTargetSelection() &&
					this.CheckPerformingAction();
			}
			return true;
		}

		protected virtual bool CheckTargetSelection()
		{
			return Consider.Ignore == this.targetSelection ||
				(Consider.Yes == this.targetSelection) == ORK.Battle.IsTargetSelectionActive;
		}

		protected virtual bool CheckPerformingAction()
		{
			return Consider.Ignore == this.performingAction ||
				(Consider.Yes == this.performingAction) == ORK.Battle.Actions.HasActive();
		}

		protected virtual bool CheckMenuScreens()
		{
			if(this.screenID != null && this.screenID.Length > 0)
			{
				for(int i = 0; i < this.screenID.Length; i++)
				{
					if(MenuStatus.Opened == ORK.MenuScreens.Get(this.screenID[i]).Status)
					{
						return true;
					}
				}
				return false;
			}
			return true;
		}
	}
}
