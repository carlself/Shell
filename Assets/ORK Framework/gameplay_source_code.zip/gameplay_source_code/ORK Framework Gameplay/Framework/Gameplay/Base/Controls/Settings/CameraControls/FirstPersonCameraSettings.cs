﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class FirstPersonCameraSettings : BaseData
	{
		[ORKEditorHelp("Use Child Object", "The camera will be positioned using a child object of the player (e.g. body/head).\n" +
			"Leave empty if you don't want to use a child object and place the camera using the root of the player object.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string onChild = "";

		[ORKEditorHelp("Offset", "The offset added to the player/child position when placing the camera.", "")]
		[ORKEditorInfo(separator=true)]
		public Vector3 offset = Vector3.zero;

		[ORKEditorHelp("Lock Cursor", "The mouse cursor will be locked when the camera control is enabled " +
			"(i.e. the mouse cursor is centered in the screen, hidden and can't be moved).", "")]
		[ORKEditorInfo(separator=true)]
		public bool lockCursor = false;


		// vertical
		[ORKEditorHelp("Vertical Axis", "The key used for vertical camera changes.\n" +
			"Vertical camera changes will turn the camera along the X-axis.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, separator=true, labelText="Vertical Input Axis")]
		public int verticalAxis = 2;

		[ORKEditorInfo("Invert Vertical", "Invert the vertical axis.", "",
			endFoldout=true)]
		public BoolValue verticalInvert = new BoolValue();

		[ORKEditorInfo("Vertical Sensitivity", "The sensitivity of vertical camera moves.", "",
			endFoldout=true)]
		public FloatValue verticalSensitivity = new FloatValue(15);


		// horizontal
		[ORKEditorHelp("Horizontal Axis", "The key used for horizontal camera changes.\n" +
			"Horizontal camera changes will turn the camera along the Y-axis.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, separator=true, labelText="Horizontal Input Axis")]
		public int horizontalAxis = 1;

		[ORKEditorInfo("Invert Horizontal", "Invert the horizontal axis.", "",
			endFoldout=true)]
		public BoolValue horizontalInvert = new BoolValue();

		[ORKEditorInfo("Horizontal Sensitivity", "The sensitivity of horizontal camera moves.", "",
			endFoldout=true)]
		public FloatValue horizontalSensitivity = new FloatValue(15);

		public FirstPersonCameraSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.ContainsArray<float>("sensitivity"))
			{
				float[] tmp = null;
				data.Get("sensitivity", out tmp);
				if(tmp != null)
				{
					Vector2 tmp2 = ArrayHelper.GetVector2(tmp);
					this.horizontalSensitivity = new FloatValue(tmp2.x);
					this.verticalSensitivity = new FloatValue(tmp2.y);
				}
			}
		}

		public void Setup(GameObject camera)
		{
			if(camera != null)
			{
				FirstPersonCamera comp = camera.GetComponent<FirstPersonCamera>();
				if(comp == null)
				{
					comp = camera.AddComponent<FirstPersonCamera>();

					comp.onChild = this.onChild;
					comp.offset = this.offset;
					comp.lockCursor = this.lockCursor;
					comp.verticalAxis = this.verticalAxis;
					comp.verticalInvert = this.verticalInvert;
					comp.verticalSensitivity = this.verticalSensitivity;
					comp.horizontalAxis = this.horizontalAxis;
					comp.horizontalInvert = this.horizontalInvert;
					comp.horizontalSensitivity = this.horizontalSensitivity;
				}
				if(comp != null)
				{
					ORK.Control.AddCameraControl(comp);
				}
			}
		}
	}
}
