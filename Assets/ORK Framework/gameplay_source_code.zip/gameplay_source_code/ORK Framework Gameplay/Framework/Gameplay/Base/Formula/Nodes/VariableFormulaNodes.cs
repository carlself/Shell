
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using ORKFramework.Formulas;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("Change Game Variables", "Changes game variables.", "")]
	[ORKNodeInfo("Variable")]
	public class ChangeGameVariableStep : BaseFormulaStep
	{
		// variable origin
		public FormulaVariableOrigin variableOrigin = new FormulaVariableOrigin();


		// variables
		[ORKEditorInfo(separator=true)]
		public VariableSetter change = new VariableSetter();

		public ChangeGameVariableStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useObjectVariable"))
			{
				bool tmpObjVar = false;
				data.Get("useObjectVariable", ref tmpObjVar);
				if(tmpObjVar)
				{
					this.variableOrigin.variableOrigin = VariableOrigin.Object;
					this.variableOrigin.origin = new FormulaStatusOrigin();
				}
			}
			if(data.Contains<int>("variableOrigin"))
			{
				this.variableOrigin.SetData(data);
			}
		}

		public override int Calculate(FormulaCall call)
		{
			if(this.variableOrigin.IsSingle)
			{
				VariableHandler handler = this.variableOrigin.GetSingle(call);
				if(handler != null)
				{
					this.change.SetVariables(handler,
						call.Variables, call.SelectedData);
				}
			}
			else
			{
				List<VariableHandler> handlers = this.variableOrigin.GetMulti(call);
				if(handlers != null)
				{
					for(int i = 0; i < handlers.Count; i++)
					{
						this.change.SetVariables(handlers[i],
							call.Variables, call.SelectedData);
					}
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variableOrigin.GetInfoText();
		}
	}

	[ORKEditorHelp("Check Game Variables", "Checks if game variables have certain values.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Variable", "Check")]
	public class CheckGameVariableStep : BaseFormulaCheckStep
	{
		// variable origin
		public FormulaVariableOrigin variableOrigin = new FormulaVariableOrigin();


		// variables
		[ORKEditorInfo(separator=true)]
		public VariableCondition condition = new VariableCondition();

		public CheckGameVariableStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useObjectVariable"))
			{
				bool tmpObjVar = false;
				data.Get("useObjectVariable", ref tmpObjVar);
				if(tmpObjVar)
				{
					this.variableOrigin.variableOrigin = VariableOrigin.Object;
					this.variableOrigin.origin = new FormulaStatusOrigin();
				}
			}
			if(data.Contains<int>("variableOrigin"))
			{
				this.variableOrigin.SetData(data);
			}
		}

		public override int Calculate(FormulaCall call)
		{
			bool check = false;

			if(this.variableOrigin.IsSingle)
			{
				check = this.condition.CheckVariables(this.variableOrigin.GetSingle(call));
			}
			else
			{
				List<VariableHandler> handlers = this.variableOrigin.GetMulti(call);
				if(handlers != null)
				{
					for(int i = 0; i < handlers.Count; i++)
					{
						if(this.condition.CheckVariables(handlers[i]))
						{
							check = true;
						}
						else
						{
							check = false;
							break;
						}
					}
				}
			}

			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variableOrigin.GetInfoText();
		}
	}

	[ORKEditorHelp("Game Variable Fork", "Checks if a single game variable for certain values.\n" +
		"If a variable condition is valid, it's next step will be executed.\n" +
		"If no variable condition is valid, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Variable", "Check")]
	public class GameVariableForkStep : BaseFormulaCheckStep
	{
		// variable origin
		public FormulaVariableOrigin variableOrigin = new FormulaVariableOrigin();


		// variable
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public FormulaString key = new FormulaString();

		[ORKEditorArray(false, "Add Condition", "Adds a new game variable condition.", "",
			"Remove", "Removes the game variable condition.", "", isMove=true, isCopy=true,
			noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Variable Condition", "Define the game variable condition that must be valid.", ""
		})]
		public CheckVariableNextNode[] condition = new CheckVariableNextNode[] {new CheckVariableNextNode()};

		public GameVariableForkStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useObjectVariable"))
			{
				bool tmpObjVar = false;
				data.Get("useObjectVariable", ref tmpObjVar);
				if(tmpObjVar)
				{
					this.variableOrigin.variableOrigin = VariableOrigin.Object;
					this.variableOrigin.origin = new FormulaStatusOrigin();
				}
			}
			if(data.Contains<int>("variableOrigin"))
			{
				this.variableOrigin.SetData(data);
			}
		}

		public override int Calculate(FormulaCall call)
		{
			int check = this.next;

			string tmpKey = this.key.GetValue(call);
			if(this.variableOrigin.IsSingle)
			{
				this.Check(ref check, tmpKey, this.variableOrigin.GetSingle(call));
			}
			else
			{
				List<VariableHandler> handlers = this.variableOrigin.GetMulti(call);
				if(handlers != null)
				{
					for(int i = 0; i < handlers.Count; i++)
					{
						if(this.Check(ref check, tmpKey, handlers[i]))
						{
							break;
						}
					}
				}
			}

			return check;
		}

		private bool Check(ref int check, string varKey, VariableHandler handler)
		{
			if(handler != null)
			{
				for(int i = 0; i < this.condition.Length; i++)
				{
					if(this.condition[i].Check(varKey, handler))
					{
						check = this.condition[i].next;
						return true;
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variableOrigin.GetInfoText();
		}

		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1) + ": " + this.condition[index - 1].GetInfoText();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}
	}

	[ORKEditorHelp("Store Formula Value", "Stores the current value of the formula into a float game variable.", "")]
	[ORKNodeInfo("Variable")]
	public class StoreFormulaValueStep : BaseFormulaStep
	{
		// variable origin
		public FormulaVariableOrigin variableOrigin = new FormulaVariableOrigin();


		// variable key
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public FormulaString key = new FormulaString();

		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Multiply: Multiplies the current value of the variable with the value.\n" +
			"- Divide: Divides the current value of the variable by the value.\n" +
			"- Modulo: Uses the modulo operator, current value of the variable % the value.\n" +
			"- Power Of: The current variable value to the power of the value.\n" +
			"- Log: The current variable value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current variable value to the value.", "")]
		public FormulaOperator floatOperator = FormulaOperator.Set;

		public StoreFormulaValueStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useObjectVariable"))
			{
				bool tmpObjVar = false;
				data.Get("useObjectVariable", ref tmpObjVar);
				if(tmpObjVar)
				{
					this.variableOrigin.variableOrigin = VariableOrigin.Object;
					this.variableOrigin.origin = new FormulaStatusOrigin();
				}
			}
			if(data.Contains<int>("variableOrigin"))
			{
				this.variableOrigin.SetData(data);
			}
		}

		public override int Calculate(FormulaCall call)
		{
			this.variableOrigin.ChangeFloat(call, this.key.GetValue(call),
				call.result, this.floatOperator);

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variableOrigin.GetInfoText() + ": " + this.key.GetInfoText() +
				" " + this.floatOperator.ToString();
		}
	}
}
