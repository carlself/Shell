﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("AI Behaviour", "A defined AI behaviour must or mustn't be equipped on an AI behaviour slot.", "")]
	public class AIBehaviourRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("AI Behaviour", "Select the AI behaviour that will be used.", "")]
		[ORKEditorInfo(ORKDataType.AIBehaviour)]
		public int behaviourID = 0;

		[ORKEditorHelp("Is Equipped", "The AI behaviour must be equipped in one of the combatant's AI slots.\n" +
			"If disabled, the AI behaviour mustn't be equipped.", "")]
		public bool isEquipped = true;

		public AIBehaviourRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.behaviourID);
				data.Get("aiEquipped", ref this.isEquipped);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.AI.IsAIBehaviourEquipped(this.behaviourID) == this.isEquipped;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.AI.Changed += notify.CombatantAIChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.AI.Changed -= notify.CombatantAIChanged;
		}
	}
}
