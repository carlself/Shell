
using UnityEngine;
using ORKFramework.Reflection;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ControlBehaviour : BaseData
	{
		[ORKEditorHelp("Blocked By", "Select when this custom control will be blocked:\n" +
			"- Player: When the player control is blocked.\n" +
			"- Camera: When the camera control is blocked.", "")]
		public CustomControlType blockType = CustomControlType.Player;
		
		[ORKEditorHelp("Placed On", "Select on which object this custom control will be added/searched:\n" +
			"- Player: On the player's game object.\n" +
			"- Camera: On the main camera's game object.", "")]
		public CustomControlType objectType = CustomControlType.Player;
		
		[ORKEditorHelp("Behaviour Name", "The name of the behaviour component that will be managed by ORK.\n" +
			"The component will be enabled/disabled depending on the current player control state.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("From Root", "Searching/adding the behaviour component will start from the root of the game object.\n" +
			"Use this option if the game object isn't the real root.", "")]
		public bool fromRoot = false;
		
		[ORKEditorHelp("On Child Object", "Search the behaviour component on child object's of the game object.", "")]
		public bool onChild = false;

		[ORKEditorHelp("On Parent Object", "Search the behaviour component on parent object's of the game object.", "")]
		public bool onParent = false;

		[ORKEditorHelp("Add Component", "The component will be added by ORK if it isn't yet attached.\n" +
			"If disabled, the component must already attached when the scene loads or the game object is instantiated.\n" +
			"If the component is already attached to the game object, ORK wont add it.", "")]
		public bool add = false;
		
		[ORKEditorHelp("On Child", "The component will be added to a a child object of the game object (e.g. Path/to/Child).\n" +
			"Leave empty if you don't want to use a child object.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("add", true, endCheckGroup=true)]
		public string childName = "";
		
		
		// fields
		[ORKEditorHelp("Set Fields", "Change the values of defined fields/properties of the component.", "")]
		[ORKEditorInfo(separator=true, labelText="Field Settings")]
		public bool setFields = false;
		
		[ORKEditorHelp("Add Only", "Only change the values if the component has been added by ORK.\n" +
			"If disabled, the fields will be changed also when the component has already been attached.", "")]
		[ORKEditorLayout("setFields", true)]
		public bool changeOnlyAdd = false;
		
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public ChangeFields fields;
		
		public ControlBehaviour()
		{
			
		}
		
		public void Add(GameObject gameObject)
		{
			if(gameObject != null)
			{
				if(this.fromRoot)
				{
					gameObject = gameObject.transform.root.gameObject;
				}
				
				bool added = false;
				MonoBehaviour comp = (this.onChild ? 
					ComponentHelper.GetInChildren(gameObject, this.name) : 
					ComponentHelper.Get(gameObject, this.name)) as MonoBehaviour;
				if(comp == null && 
					this.onParent)
				{
					comp = ComponentHelper.GetInParent(gameObject, this.name) as MonoBehaviour;
				}
				
				if(this.add && comp == null)
				{
					comp = ComponentHelper.Add(
						TransformHelper.GetChildObject(this.childName, gameObject), this.name) 
						as MonoBehaviour;
					added = true;
				}
				
				if(comp != null)
				{
					if(this.setFields && this.fields != null && 
						(!this.changeOnlyAdd || added))
					{
						this.fields.Change(comp);
					}
					
					if(CustomControlType.Player == this.blockType)
					{
						ORK.Control.AddPlayerControl(comp);
					}
					else if(CustomControlType.Camera == this.blockType)
					{
						ORK.Control.AddCameraControl(comp);
					}
				}
			}
		}
		
		public void Remove(GameObject gameObject)
		{
			if(gameObject != null)
			{
				MonoBehaviour comp = (this.onChild ? 
					ComponentHelper.GetInChildren(gameObject, this.name) : 
					ComponentHelper.Get(gameObject, this.name)) as MonoBehaviour;
				if(comp == null &&
					this.onParent)
				{
					comp = ComponentHelper.GetInParent(gameObject, this.name) as MonoBehaviour;
				}

				if(comp != null)
				{

					if(CustomControlType.Player == this.blockType)
					{
						ORK.Control.RemovePlayerControl(comp);
					}
					else if(CustomControlType.Camera == this.blockType)
					{
						ORK.Control.RemoveCameraControl(comp);
					}
					if(this.add)
					{
						GameObject.Destroy(comp);
					}
				}
			}
		}
	}
}

