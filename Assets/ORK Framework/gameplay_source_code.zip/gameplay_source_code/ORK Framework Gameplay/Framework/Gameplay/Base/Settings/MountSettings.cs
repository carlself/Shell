
using UnityEngine;

namespace ORKFramework
{
	[System.Serializable]
	public class MountSettings : BaseData
	{
		[ORKEditorHelp("On Child", "A child object of the target's game object is used for " +
			"placement (e.g. Path/to/Child).\n" +
			"Leave empty if you don't want to use a child object.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string childName = "";

		public LocalSpace localSpace = new LocalSpace();

		[ORKEditorHelp("Offset", "The offset added to the target game object's position.", "")]
		public Vector3 offset = Vector3.zero;

		[ORKEditorHelp("Use Rotation", "The rotation of the target will be used for placement.", "")]
		public bool useRotation = true;

		[ORKEditorHelp("Rotation Offset", "Offset added to the target's rotation.", "")]
		[ORKEditorLayout("useRotation", true, endCheckGroup=true)]
		public Vector3 rotationOffset = Vector3.zero;

		[ORKEditorHelp("Set Scale", "Set the scale when placing the object.", "")]
		public bool setScale = false;

		[ORKEditorHelp("After Mount", "The scale is set after mounting the game object (if mounting is used).", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("setScale", true)]
		public bool scaleAfterMount = false;

		[ORKEditorHelp("Scale", "The scale the object will be set to.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public Vector3 scale = Vector3.one;

		public MountSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.localSpace.Upgrade(data);
		}

		public void MountTo(Transform parent, Transform child)
		{
			TransformHelper.Mount(
				TransformHelper.GetChild(this.childName, parent), child,
				this.localSpace, this.offset,
				this.useRotation, this.rotationOffset,
				this.setScale, this.scaleAfterMount, this.scale);
		}

		public void Place(Transform parent, Transform child)
		{
			TransformHelper.Place(
				TransformHelper.GetChild(this.childName, parent), child,
				this.localSpace, this.offset,
				this.useRotation, this.rotationOffset,
				this.setScale, this.scale);
		}

		public void GetMountTo(Transform parent, ref Vector3 pos, ref Vector3 rot)
		{
			TransformHelper.GetMount(
				TransformHelper.GetChild(this.childName, parent),
				this.localSpace, this.offset,
				this.useRotation, this.rotationOffset,
				ref pos, ref rot);
		}

		public void GetPlace(Transform parent, ref Vector3 pos, ref Vector3 rot)
		{
			TransformHelper.GetPlace(
				TransformHelper.GetChild(this.childName, parent),
				this.localSpace, this.offset,
				this.useRotation, this.rotationOffset,
				ref pos, ref rot);
		}
	}
}

