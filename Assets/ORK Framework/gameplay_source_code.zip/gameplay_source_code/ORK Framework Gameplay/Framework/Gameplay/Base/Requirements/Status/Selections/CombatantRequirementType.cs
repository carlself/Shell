﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Combatant", "The combatant must or mustn't be a selected combatant.", "")]
	public class CombatantRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Combatant", "Select the combatant that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		public int combatantID = 0;

		[ORKEditorHelp("Is Combatant", "The combatant must be the selected combatant.\n" +
			"If disabled, the combatant mustn't be the selected combatant.", "")]
		public bool isCombatant = true;

		[ORKEditorHelp("Combatant Scope", "Select the scope that will be checked:\n" +
			"- Current: The combatant that is checked.\n" +
			"- Battle: The members of the checked combatant's battle group.\n" +
			"- Group: All members of the checked combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the checked combatant's battle group.\n" +
			"- Battle Reserve: The members in the checked combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the checked combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.\n\n" +
			"When checking the group or battle group, " +
			"'Is Combatant' is valid if at least one member is the selected combatant, " +
			"not 'Is Combatant' is valid if no member is the selected combatant.", "")]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		public CombatantRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.combatantID);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(MenuCombatantScope.Current == this.combatantScope)
			{
				return (combatant.ID == this.combatantID) == this.isCombatant;
			}
			else if(MenuCombatantScope.Battle == this.combatantScope)
			{
				return combatant.Group.IsBattleMember(this.combatantID) == this.isCombatant;
			}
			else if(MenuCombatantScope.Group == this.combatantScope ||
				MenuCombatantScope.GroupBattleSorted == this.combatantScope)
			{
				return combatant.Group.IsMember(this.combatantID) == this.isCombatant;
			}
			else if(MenuCombatantScope.NonBattle == this.combatantScope)
			{
				return combatant.Group.IsNonBattleMember(this.combatantID) == this.isCombatant;
			}
			else if(MenuCombatantScope.BattleReserve == this.combatantScope)
			{
				return combatant.Group.IsBattleReserveMember(this.combatantID) == this.isCombatant;
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			if(MenuCombatantScope.Current != this.combatantScope)
			{
				combatant.GroupChanged += notify.CombatantGroupChanged;
			}
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			if(MenuCombatantScope.Current != this.combatantScope)
			{
				combatant.GroupChanged -= notify.CombatantGroupChanged;
			}
		}
	}
}
