﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class MenuControls : BaseData
	{
		[ORKEditorHelp("Accept Key", "The key used to accept selections (e.g. choice dialogues, battle menu, etc.).", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int acceptKeyID = 3;

		[ORKEditorHelp("Cancel Key", "The key used to cancel selections or return to previous selections " +
			"(e.g. return from target selection in battle menus).", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int cancelKeyID = 4;

		[ORKEditorHelp("Vertical Axis", "The key used to move the menu cursor vertically.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int verticalAxisID = 2;

		[ORKEditorHelp("Horizontal Axis", "The key used to move the menu cursor horizontally.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int horizontalAxisID = 1;


		// scroll input
		[ORKEditorHelp("Use Scroll Axis", "Use an input key to scroll the content of a GUI box.\n" +
			"If disabled, scrolling is done with the vertical axis and the mouse wheel.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useScrollAxis = false;

		[ORKEditorHelp("Unfocused Scrolling", "The scroll axis will also scroll a GUI box when it's unfocused.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("useScrollAxis", true)]
		public bool scrollAxisUnfocused = false;

		[ORKEditorHelp("Scroll Key", "Select the input key that will be used to scroll the content of the GUI box.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, indent=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int scrollAxisID = 0;


		// click accept
		[ORKEditorHelp("Accept Left Click", "Clicking with the left mouse button on a choice will accept it.", "")]
		[ORKEditorInfo(separator=true)]
		public bool acceptLeftClick = true;

		[ORKEditorHelp("Accept Middle Click", "Clicking with the middle mouse button on a choice will accept it.", "")]
		public bool acceptMiddleClick = false;

		[ORKEditorHelp("Accept Right Click", "Clicking with the right mouse button on a choice will accept it.", "")]
		public bool acceptRightClick = false;


		// choice scroll
		[ORKEditorHelp("Use Choice Scroll", "Use input keys to scroll up/down to show the next block of choices " +
			"(starting with the first not fully visible choice).\n" + 
			"Best only used in 'List' choice mode without columns.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useChoiceScroll = false;

		[ORKEditorLayout("useChoiceScroll", true, endCheckGroup=true, autoInit=true)]
		public AxisControl choiceScroll;


		// in-game
		private InputKey acceptKey;

		private InputKey cancelKey;

		private InputKey verticalKey;

		private InputKey horizontalKey;

		private InputKey scrollKey;

		public MenuControls()
		{

		}

		public bool CheckClickAccept()
		{
			return (this.acceptLeftClick && Input.GetMouseButtonUp(0)) ||
				(this.acceptRightClick && Input.GetMouseButtonUp(1)) ||
				(this.acceptMiddleClick && Input.GetMouseButtonUp(2));
		}


		/*
		============================================================================
		Input keys
		============================================================================
		*/
		public InputKey AcceptKey
		{
			get
			{
				if(this.acceptKey == null)
				{
					this.acceptKey = ORK.InputKeys.Get(this.acceptKeyID);
				}
				return this.acceptKey;
			}
		}

		public InputKey CancelKey
		{
			get
			{
				if(this.cancelKey == null)
				{
					this.cancelKey = ORK.InputKeys.Get(this.cancelKeyID);
				}
				return this.cancelKey;
			}
		}

		public InputKey VerticalKey
		{
			get
			{
				if(this.verticalKey == null)
				{
					this.verticalKey = ORK.InputKeys.Get(this.verticalAxisID);
				}
				return this.verticalKey;
			}
		}

		public InputKey HorizontalKey
		{
			get
			{
				if(this.horizontalKey == null)
				{
					this.horizontalKey = ORK.InputKeys.Get(this.horizontalAxisID);
				}
				return this.horizontalKey;
			}
		}

		public InputKey ScrollKey
		{
			get
			{
				if(this.scrollKey == null)
				{
					this.scrollKey = ORK.InputKeys.Get(this.scrollAxisID);
				}
				return this.scrollKey;
			}
		}
	}
}
