﻿
using UnityEngine;
using System.Collections.Generic;
using System.Reflection;
using System.IO;
using System;

namespace ORKFramework
{
	public class FileSaveSettings : BaseData
	{
		[ORKEditorHelp("Save To", "Select where the file will be saved to:\n" +
			"- PlayerPrefs: Saves the content as a string PlayerPrefs variable.\n" +
			"- File Persistent Data Path: Saves the file in 'Application.persistentDataPath'.\n" +
			"- Custom: A custom file save solution using static functions to save, load and delete files is used.\n" +
			"- File Data Path: Saves the file in 'Application.dataPath'.\n" +
			"See the Unity Documentation for more information about where the file will be stored on the different platforms.", "")]
		public SaveGameType type = SaveGameType.FilePersistentDataPath;


		// folder
		[ORKEditorHelp("Save Folder", "Optionally define a folder that will be used (in the selected data path) to store save games in.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(new string[] { "type", "type" },
			new object[] { SaveGameType.FilePersistentDataPath, SaveGameType.FileDataPath },
			needed=Needed.One, endCheckGroup=true)]
		public string saveFolder = "";


		// custom save functions
		[ORKEditorHelp("Class Name", "The name of the class that contains the static functions.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("type", SaveGameType.Custom)]
		public string className = "";

		[ORKEditorHelp("Save Function Name", "The name of the static save function that will be called.\n" +
			"The function must have a string parameter for the file name and a string parameter for the save data, e.g.:\n" +
			"public static void Save(string fileName, string data)", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string saveFunctionName = "";

		[ORKEditorHelp("Load Function Name", "The name of the static load function that will be called.\n" +
			"The function must have a string parameter for the file name and return a string containing the save data, e.g.:\n" +
			"public static string Load(string fileName)", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string loadFunctionName = "";

		[ORKEditorHelp("Exists Function Name", "The name of the static exists function that will be called.\n" +
			"The function must have a string parameter for the file name and return a bool indicating if the file exists (true) or not (false), e.g.:\n" +
			"public static bool Exists(string fileName)", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string existsFunctionName = "";

		[ORKEditorHelp("Delete Function Name", "The name of the static delete function that will be called.\n" +
			"The function must have a string parameter for the file name, e.g.:\n" +
			"public static void Delete(string fileName)", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string deleteFunctionName = "";


		// in-game
		private MethodInfo customSave;

		private MethodInfo customLoad;

		private MethodInfo customExists;

		private MethodInfo customDelete;

		public FileSaveSettings()
		{

		}

		public string GetInfoText()
		{
			return this.type.ToString();
		}

		private void LoadCustomFunctions()
		{
			Type type = ORK.Core.TypeHandler.GetType(this.className);
			if(type != null)
			{
				this.customSave = type.GetMethod(
					this.saveFunctionName,
					new Type[] { typeof(string), typeof(string) });
				this.customLoad = type.GetMethod(
					this.loadFunctionName,
					new Type[] { typeof(string) });
				this.customDelete = type.GetMethod(
					this.deleteFunctionName,
					new Type[] { typeof(string) });
				this.customExists = type.GetMethod(
					this.existsFunctionName,
					new Type[] { typeof(string) });
			}
		}

		public string GetSavePath()
		{
			if(SaveGameType.FilePersistentDataPath == this.type)
			{
				if(string.IsNullOrEmpty(this.saveFolder))
				{
					return Application.persistentDataPath + "/";
				}
				else
				{
					return Application.persistentDataPath + "/" + this.saveFolder + "/";
				}
			}
			else if(SaveGameType.FileDataPath == this.type)
			{
				if(string.IsNullOrEmpty(this.saveFolder))
				{
					return Application.dataPath + "/";
				}
				else
				{
					return Application.dataPath + "/" + this.saveFolder + "/";
				}
			}
			return "";
		}


		/*
		============================================================================
		File functions
		============================================================================
		*/
		public void Save(string fileName, string data)
		{
			if(SaveGameType.PlayerPrefs == this.type ||
#if Unity_5_6
				Application.isWebPlayer)
#else
				Application.platform == RuntimePlatform.WebGLPlayer)
#endif
			{
				PlayerPrefs.SetString(fileName, data);
				PlayerPrefs.Save();
			}
			else if(SaveGameType.FilePersistentDataPath == this.type ||
				SaveGameType.FileDataPath == this.type)
			{
				string path = this.GetSavePath();
				if(!Directory.Exists(path))
				{
					Directory.CreateDirectory(path);
				}
				StreamWriter writer = new StreamWriter(path + fileName);
				writer.Write(data);
				writer.Flush();
				writer.Close();
			}
			else if(SaveGameType.Custom == this.type)
			{
				try
				{
					if(this.customSave == null)
					{
						this.LoadCustomFunctions();
					}
					if(this.customSave != null)
					{
						this.customSave.Invoke(null, new object[] { fileName, data });
					}
				}
				catch(Exception ex)
				{
					Debug.LogWarning("Error occured calling custom save function: " + ex.Message);
				}
			}
		}

		public string Load(string fileName)
		{
			if(this.Exists(fileName))
			{
				if(SaveGameType.PlayerPrefs == this.type ||
#if Unity_5_6
					Application.isWebPlayer)
#else
					Application.platform == RuntimePlatform.WebGLPlayer)
#endif
				{
					return PlayerPrefs.GetString(fileName);
				}
				else if(SaveGameType.FilePersistentDataPath == this.type ||
					SaveGameType.FileDataPath == this.type)
				{
					StreamReader reader = new StreamReader(this.GetSavePath() + fileName);
					string data = reader.ReadToEnd();
					reader.Close();
					return data;
				}
				else if(SaveGameType.Custom == this.type)
				{
					try
					{
						if(this.customLoad == null)
						{
							this.LoadCustomFunctions();
						}
						if(this.customLoad != null)
						{
							object tmp = this.customLoad.Invoke(null, new object[] { fileName });
							if(tmp is string)
							{
								return (string)tmp;
							}
						}
					}
					catch(Exception ex)
					{
						Debug.LogWarning("Error occured while calling custom load function: " + ex.Message);
					}
				}
			}
			return "";
		}

		public bool Exists(string fileName)
		{
			if(SaveGameType.PlayerPrefs == this.type ||
#if Unity_5_6
					Application.isWebPlayer)
#else
					Application.platform == RuntimePlatform.WebGLPlayer)
#endif
			{
				return PlayerPrefs.HasKey(fileName);
			}
			else if(SaveGameType.FilePersistentDataPath == this.type ||
				SaveGameType.FileDataPath == this.type)
			{
				return File.Exists(this.GetSavePath() + fileName);
			}
			else if(SaveGameType.Custom == this.type)
			{
				try
				{
					if(this.customExists == null)
					{
						this.LoadCustomFunctions();
					}
					if(this.customExists != null)
					{
						object tmp = this.customExists.Invoke(null, new object[] { fileName });
						if(tmp is bool)
						{
							return (bool)tmp;
						}
					}
				}
				catch(Exception ex)
				{
					Debug.LogWarning("Error occured while calling custom file exists function: " + ex.Message);
				}
			}
			return false;
		}

		public void Delete(string fileName)
		{
			if(this.Exists(fileName))
			{
				if(SaveGameType.PlayerPrefs == this.type ||
#if Unity_5_6
					Application.isWebPlayer)
#else
					Application.platform == RuntimePlatform.WebGLPlayer)
#endif
				{
					PlayerPrefs.DeleteKey(fileName);
				}
				else if(SaveGameType.FilePersistentDataPath == this.type ||
					SaveGameType.FileDataPath == this.type)
				{
					File.Delete(this.GetSavePath() + fileName);
				}
				else if(SaveGameType.Custom == this.type)
				{
					try
					{
						if(this.customDelete == null)
						{
							this.LoadCustomFunctions();
						}
						if(this.customDelete != null)
						{
							this.customDelete.Invoke(null, new object[] { fileName });
						}
					}
					catch(Exception ex)
					{
						Debug.LogWarning("Error occured while calling custom delete function: " + ex.Message);
					}
				}
			}
		}
	}
}
