﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Formulas
{
	public class FormulaSelectedData : FormulaSelectedDataOrigin
	{
		[ORKEditorInfo(labelText="Selected Key")]
		public FormulaString selectedKey = new FormulaString();

		public FormulaSelectedData()
		{

		}

		public string GetInfoText()
		{
			return this.selectedKey.GetInfoText() + "(" + this.origin.ToString() + ")";
		}

		public int GetCount(FormulaCall call)
		{
			return this.GetCount(call, this.selectedKey.GetValue(call));
		}

		public List<object> GetSelectedData(FormulaCall call)
		{
			return this.GetSelectedData(call, this.selectedKey.GetValue(call));
		}

		public void Change(FormulaCall call, object data, ListChangeType changeType)
		{
			this.Change(call, this.selectedKey.GetValue(call), data, changeType);
		}
	}
}
