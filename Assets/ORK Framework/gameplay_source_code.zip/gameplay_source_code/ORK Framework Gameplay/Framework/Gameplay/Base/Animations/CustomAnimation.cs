
using UnityEngine;
using ORKFramework;
using ORKFramework.Reflection;
using System.Collections.Generic;

namespace ORKFramework.Animations
{
	public class CustomAnimation : BaseData
	{
		[ORKEditorHelp("Animation Type", "Select the animation type of this animation.", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int typeID = 0;
		
		[ORKEditorInfo("Play Function", "Define the function that will be called when the animation is played.", "", endFoldout=true)]
		public CallMethod playMethod = new CallMethod();
		
		[ORKEditorInfo("Stop Function", "Define the function that will be called when the animation is stopped.", "", endFoldout=true)]
		public CallMethod stopMethod = new CallMethod();
		
		public CustomAnimation()
		{
			
		}
		
		
		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public void Play(Component behaviour)
		{
			this.playMethod.Call(behaviour);
		}
		
		public void Stop(Component behaviour)
		{
			this.stopMethod.Call(behaviour);
		}
	}
}
