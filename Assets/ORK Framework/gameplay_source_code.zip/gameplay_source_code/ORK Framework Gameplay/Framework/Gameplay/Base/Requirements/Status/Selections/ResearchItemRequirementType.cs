﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Research Item", "The state of a defined research item must match.", "")]
	public class ResearchItemRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Research Tree", "Select the research tree that will be used.", "")]
		[ORKEditorInfo(ORKDataType.ResearchTree)]
		public int researchTreeID = 0;

		[ORKEditorHelp("Research Item", "Select the research item that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.ResearchTree, idFieldName="researchTreeID")]
		public int researchItem = 0;

		[ORKEditorHelp("Check Research Count", "Check how often the research item has been researched.\n" +
			"If disabled, the state of the research item will be checked.", "")]
		public bool checkResearchCount = false;

		[ORKEditorLayout("checkResearchCount", true)]
		public ValueCheck check = new ValueCheck();

		[ORKEditorHelp("Research Item State", "Select the state that will be checked for:\n" +
			"- Unresearched: The research item hasn't yet been researched.\n" +
			"- In Research: The research item is currently in research.\n" +
			"- Researched: The research item has been researched (at least once).\n" +
			"- Complete: The research item has been fully researched (i.e. reached the limit).", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public ResearchItemState researchItemState = ResearchItemState.Unresearched;

		public ResearchItemRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.researchTreeID);
			}
			this.check.UpgradeInt(data, "researchCountComparison", "researchCount");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.checkResearchCount ?
				combatant.Research.CheckItemResearchCount(
					this.researchTreeID, this.researchItem, this.check) :
				combatant.Research.CheckItemState(
					this.researchTreeID, this.researchItem, this.researchItemState);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Research.Changed += notify.CombatantResearchChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Research.Changed -= notify.CombatantResearchChanged;
		}
	}
}
