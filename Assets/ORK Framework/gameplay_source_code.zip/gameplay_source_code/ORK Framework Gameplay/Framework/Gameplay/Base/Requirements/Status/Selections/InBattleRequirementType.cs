﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("In Battle", "The combatant must or mustn't be in battle.", "")]
	public class InBattleRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Is In Battle", "The combatant must be in battle.\n" +
			"If disabled, the combatant mustn't be in battle.", "")]
		public bool isInBattle = true;

		public InBattleRequirementType()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.Battle.InBattle == this.isInBattle;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Battle.BattleStateChanged += notify.CombatantBattleStateChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Battle.BattleStateChanged -= notify.CombatantBattleStateChanged;
		}
	}
}
