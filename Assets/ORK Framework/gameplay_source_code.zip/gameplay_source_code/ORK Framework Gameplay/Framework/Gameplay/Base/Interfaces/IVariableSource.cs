﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IVariableSource
	{
		bool HasVariables
		{
			get;
		}

		VariableHandler Variables
		{
			get;
		}
	}
}
