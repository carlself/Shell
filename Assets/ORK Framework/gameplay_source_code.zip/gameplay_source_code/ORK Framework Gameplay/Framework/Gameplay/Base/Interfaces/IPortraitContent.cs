﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IPortraitContent
	{
		IPortrait GetPortrait(int typeID);
	}
}
