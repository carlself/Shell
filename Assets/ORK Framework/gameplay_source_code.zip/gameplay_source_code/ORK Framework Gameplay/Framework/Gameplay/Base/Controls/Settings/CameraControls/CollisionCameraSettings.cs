
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CollisionCameraSettings : BaseData
	{
		[ORKEditorHelp("Enable Collision Camera", "Enable using the collision camera.\n" +
			"The collision camera uses raycasts to determine if an object is between the player and the screen.\n" +
			"If an object is found, the camera will be placed at the collision point.\n" +
			"The 'CollisionCamera' component is added to the scene's camera automatically, " +
			"unless the component is already attached " +
			"(i.e. you can add the component to scene cameras to use different settings).\n" +
			"The collision camera can also be used with custom controls and with events " +
			"(i.e. even when the camera controls are blocked).", "")]
		public bool enable = false;


		// camera settings
		[ORKEditorHelp("Check Type", "Select the collision camera check type:\n" +
			"- Center: Only the center of the screen will be checked.\n" +
			"- Horizontal: Checks center, left and right.\n" +
			"- Vertical: Checks center, up and down.\n" +
			"- Cross: Checks center, left, right, up and down.", "")]
		[ORKEditorLayout("enable", true)]
		public CollisionCameraType type = CollisionCameraType.Center;

		[ORKEditorHelp("Layer Mask", "Select the layers that will be checked.", "")]
		public LayerMask layerMask = -1;

		[ORKEditorHelp("Move Towards", "Define the distance the camera will move towards the player from the collision point.\n" +
			"You can use negative values to move away from the player.\n" +
			"Use this setting to avoid clipping near walls.", "")]
		public float moveTowards = 0;

		// how much of the FoV will be used: 0-1
		[ORKEditorHelp("View Size", "Define how much of the camera's view will be used " +
			"when checking left/right and up/down positions", "")]
		[ORKEditorLayout("type", CollisionCameraType.Center, elseCheckGroup=true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float viewSize = 0.5f;


		// player settings
		[ORKEditorHelp("Player Child Name", "You can use a child object of the player when checking for collisions.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string childName = "";

		public CollisionCameraSettings()
		{

		}

		public void Add(GameObject gameObject)
		{
			if(this.enable)
			{
				CollisionCamera comp = gameObject.GetComponent<CollisionCamera>();
				if(comp == null)
				{
					comp = gameObject.AddComponent<CollisionCamera>();

					comp.type = this.type;
					comp.layerMask = this.layerMask;
					comp.moveTowards = this.moveTowards;
					comp.viewSize = this.viewSize;
					comp.childName = this.childName;
				}
			}
		}
	}
}
