﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Weapon", "A defined weapon must or mustn't be equipped.", "")]
	public class WeaponRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Weapon", "Select the weapon that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Weapon)]
		public int weaponID = 0;

		[ORKEditorHelp("Level", "The level of the weapon that will be checked for.\n" +
			"The combatant must have at least the defined equipment level equipped.", "")]
		[ORKEditorLimit(1, false)]
		public int level = 1;

		[ORKEditorHelp("Is Equipped", "The weapon must be equipped on the combatant.\n" +
			"If disabled, the weapon mustn't be equipped.", "")]
		public bool isEquipped = true;

		[ORKEditorHelp("Check Equipment Part", "Check if the weapon is equipped on a defined equipment part.\n" +
			"If disabled, checks if the weapon is equipped on any part.", "")]
		public bool checkEquipmentPart = false;

		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be check.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("checkEquipmentPart", true, endCheckGroup=true)]
		public int equipmentPartID = 0;

		public WeaponRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.weaponID);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.Equipment.IsEquipped(EquipSet.Weapon, this.weaponID, this.level,
				this.checkEquipmentPart ? this.equipmentPartID : -1) == this.isEquipped;
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null &&
				(combatant.Bestiary.IsComplete ||
				combatant.Bestiary.status.equipment))
			{
				return this.Check(combatant);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Equipment.Changed += notify.EquipmentChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Equipment.Changed -= notify.EquipmentChanged;
		}
	}
}
