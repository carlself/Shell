﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public abstract class BaseAssetSource : BaseTypeData
	{
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public virtual bool EditorHasAssetField
		{
			get { return false; }
		}

		public virtual Object EditorAsset
		{
			get { return null; }
			set { }
		}

		public virtual bool HasAsset
		{
			get { return false; }
		}

		public virtual void EditorBefore()
		{

		}

		public virtual void EditorAfter(bool assetChanged, string assetPath)
		{

		}

		public virtual string GetGenericTypeName()
		{
			return ReflectionTypeHandler.GetGenericTypeName(this.GetType());
		}

		public virtual string GetInfoText()
		{
			return "";
		}

		public override bool IsType(string type)
		{
			return this.GetGenericTypeName() == type;
		}
	}

	public abstract class BaseAssetSource<T> : BaseAssetSource where T : UnityEngine.Object
	{
		public abstract T Get();
	}
}
