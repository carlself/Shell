
using ORKFramework;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("Rounding", "The current value of the formula will be rounded.\n" +
		"The rounded value can be summed up.", "")]
	[ORKNodeInfo("Base")]
	public class RoundingStep : BaseFormulaStep
	{
		[ORKEditorHelp("Rounding", "Rounds the current value of the formula.\n" +
			"- None: No rounding.\n" +
			"- Ceil: The value will be rounded up (e.g. 14.2 will become 15).\n" +
			"- Floor: The value will be rounded down (e.g. 14.8 will become 14).\n" +
			"- Round: The value will be rounded to the nearest integer (e.g. 14.2 will become 14, 14.8 will become 15).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Rounding rounding = Rounding.None;

		[ORKEditorHelp("Sum (1+...+n)", "The current value of the formula will be summed up, " +
			"i.e. all whole numbers starting from 1 to (including) the current formula value will be added to each other.\n" +
			"E.g. 5 will become 1+2+3+4+5=15.\n" +
			"The sum is build using the Gauss Sum ((n*(n+1))/2) where n is the current formula value (after rounding).", "")]
		[ORKEditorLayout("rounding", Rounding.None, elseCheckGroup=true, endCheckGroup=true)]
		public bool doSum = false;

		public RoundingStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			call.result = ValueHelper.GetRounded(call.result, this.rounding);
			if(Rounding.None != this.rounding && this.doSum)
			{
				int sum = (int)call.result;
				sum = (sum * (sum + 1)) / 2;
				call.result = sum;
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.rounding + (this.doSum ? ", Sum" : "");
		}
	}

	[ORKEditorHelp("Limit Value", "The current value of the formula will be limited.", "")]
	[ORKNodeInfo("Base")]
	public class LimitValueStep : BaseFormulaStep
	{
		[ORKEditorHelp("Use Minimum", "The current value will be limited by a minimum value.", "")]
		public bool useMin = false;

		[ORKEditorInfo("Minimum Value", "The value will have at least this value.", "",
			endFoldout=true)]
		[ORKEditorLayout("useMin", true, endCheckGroup=true)]
		public FormulaFloat minValue = new FormulaFloat();

		[ORKEditorHelp("Use Maximum", "The current value will be limited by a maximum value.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useMax = false;

		[ORKEditorInfo("Maximum Value", "The value will have this value at most.", "",
			endFoldout=true)]
		[ORKEditorLayout("useMax", true, endCheckGroup=true)]
		public FormulaFloat maxValue = new FormulaFloat();

		public LimitValueStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<float>("min"))
			{
				float tmp = 0;
				data.Get("min", ref tmp);
				this.minValue = new FormulaFloat(tmp);

				data.Get("max", ref tmp);
				this.maxValue = new FormulaFloat(tmp);
			}
		}

		public override int Calculate(FormulaCall call)
		{
			if(this.useMin)
			{
				float min = this.minValue.GetValue(call);
				if(call.result < min)
				{
					call.result = min;
				}
			}
			if(this.useMax)
			{
				float max = this.maxValue.GetValue(call);
				if(call.result > max)
				{
					call.result = max;
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useMin ? this.minValue.GetInfoText() : "X") + " - " + (this.useMax ? this.maxValue.GetInfoText() : "X");
		}
	}

	[ORKEditorHelp("Absolute Value", "The current value of the formula will be absolute, i.e. negative values will become positive.\n" +
			"E.g.: -10.5 will become 10.5", "")]
	[ORKNodeInfo("Base")]
	public class AbsoluteValueStep : BaseFormulaStep
	{
		public AbsoluteValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			call.result = Mathf.Abs(call.result);
			return this.next;
		}
	}

	[ORKEditorHelp("Random", "Randomly executes a next step out of a list of defined steps.", "")]
	[ORKNodeInfo("Base")]
	public class RandomStep : BaseFormulaStep
	{
		[ORKEditorInfo(hide=true, instanceCallback="buttons:randomstep")]
		public int[] random = new int[] {-1};

		public RandomStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			return this.random[UnityWrapper.Range(0, this.random.Length)];
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			return "Random " + index;
		}

		public override int GetNextCount()
		{
			return this.random.Length;
		}

		public override int GetNext(int index)
		{
			return this.random[index];
		}

		public override void SetNext(int index, int next)
		{
			this.random[index] = next;
		}
	}

	[ORKEditorHelp("Comment", "Leave a comment in your formula.\n" +
		"This step does nothing and is only for commentary purposes.", "")]
	[ORKNodeInfo("Base")]
	public class CommentStep : BaseFormulaStep
	{
		[ORKEditorHelp("Comment", "The comment.", "")]
		[ORKEditorInfo(isTextArea=true)]
		public string comment = "";

		public CommentStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			return this.next;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.comment;
		}
	}

	[ORKEditorHelp("Debug", "Prints a text to the Unity console.", "")]
	[ORKNodeInfo("Base")]
	public class DebugStep : BaseFormulaStep
	{
		[ORKEditorHelp("Debug Type", "Select the debug type will be used:\n" +
			"- Log: Printed to 'Debug.Log'.\n" +
			"- Warning: Printed to 'Debug.LogWarning'.\n" +
			"- Error: Printed to 'Debug.LogError'.", "")]
		public DebugType type = DebugType.Log;

		[ORKEditorHelp("Value Format", "Define the format the formula value will be printed with.", "")]
		public string format = "0.00";

		[ORKEditorHelp("Text", "The text that will be printed.", "")]
		[ORKEditorInfo(isTextArea=true, separator=true, label=new string[] {
			"%un = user name, %tn = found target name, % = current formula value"
		})]
		public string text = "";


		// variable settings
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables that are printed to the console:\n" +
			"- Local: Local variables are only used while calculating a formula and don't interfere with global variables. " +
			"The variable will be gone once the formula finished calculating.\n" +
			"When a formula is called from an event, the local variables are shared with the event and " +
			"will also be available in the running event (until the event ends)." +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.\n" +
			"- Selected: Variables assigned to selected data coming from an event.\n" +
			"When coming from a battle event, the variables are usually assigned to the ability or item of the action.\n" +
			"Only available when the formula was initially called by an event.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Settings")]
		public FormulaVariableOrigin variableOrigin = new FormulaVariableOrigin();

		public DebugStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("variableOrigin"))
			{
				this.variableOrigin.SetData(data);
			}
		}

		public override int Calculate(FormulaCall call)
		{
			if(DebugType.Log == this.type)
			{
				Debug.Log(this.GetText(call));
			}
			else if(DebugType.Warning == this.type)
			{
				Debug.LogWarning(this.GetText(call));
			}
			else if(DebugType.Error == this.type)
			{
				Debug.LogError(this.GetText(call));
			}
			return this.next;
		}

		private string GetText(FormulaCall call)
		{
			return TextHelper.ReplaceSpecials(
				this.text.
					Replace("%un", call.user.GetName()).
					Replace("%tn", call.target.GetName()).
					Replace("%", call.result.ToString(this.format)),
				this.variableOrigin.GetFirst(call));
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.text;
		}
	}

	[ORKEditorHelp("Check Chance", "Which step will be executed next is decided by chance.\n" +
		"The chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings).\n" +
		"If the random number is less or equal to the defined chance, 'Success' is executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Base", "Check")]
	public class CheckChanceStep : BaseFormulaCheckStep
	{
		[ORKEditorInfo(labelText="Chance")]
		public FormulaFloat chance = new FormulaFloat();

		public CheckChanceStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ORK.GameSettings.CheckRandom(this.chance.GetValue(call)))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.chance.GetInfoText();
		}
	}

	[ORKEditorHelp("Chance Fork", "Which step will be executed next is decided by chance.\n" +
		"The chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings).\n" +
		"The next step of the first defined value range, that includes the chance, will be executed.\n" +
		"If no range contains the chance, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Base", "Check")]
	public class ChanceForkStep : BaseFormulaStep
	{
		[ORKEditorArray(false, "Add Range", "Adds a range for the chance check.", "",
			"Remove", "Removes this range.", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Range", "Define the minimum and maximum value of the range.\n" +
				"If the random chance value is within the range (i.e. minimum <= chance <= maximum), " +
				"this range's next step will be executed.", ""
		})]
		public ChanceFormulaNextNode[] range = new ChanceFormulaNextNode[] {new ChanceFormulaNextNode()};

		public ChanceForkStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			int check = this.next;

			float chance = ORK.GameSettings.GetRandom();

			for(int i = 0; i < this.range.Length; i++)
			{
				if(this.range[i].Contains(chance, call))
				{
					check = this.range[i].next;
					break;
				}
			}

			return check;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1).ToString() + ": " +
					this.range[index - 1].GetInfoText();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.range.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.range[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.range[index - 1].next = next;
			}
		}
	}

	[ORKEditorHelp("Check Difficulty", "Checks the game's difficulty.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Base", "Check")]
	public class CheckDifficultyStep : BaseFormulaCheckStep
	{
		public DifficultyCheck difficultyCheck = new DifficultyCheck();

		public CheckDifficultyStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.difficultyCheck.Check())
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.difficultyCheck.ToString();
		}
	}
}
