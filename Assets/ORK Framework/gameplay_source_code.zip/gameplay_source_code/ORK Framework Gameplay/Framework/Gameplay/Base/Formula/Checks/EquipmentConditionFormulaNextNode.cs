﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Formulas
{
	public class EquipmentConditionFormulaNextNode : BaseData
	{
		[ORKEditorInfo(hide=true)]
		public int next = -1;

		// selected data
		[ORKEditorHelp("Use Selected Data", "Check for an equipment stored in selected data.", "")]
		public bool useSelectedData = false;

		[ORKEditorLayout("useSelectedData", true, autoInit=true)]
		public FormulaSelectedData selectedData;


		// equipment
		[ORKEditorHelp("Equip", "Select how the equipment part will be checked:\n" +
			"- None: The equipment part has to be unequipped.\n" +
			"- Weapon: A weapon has to be equipped.\n" +
			"- Armor: An armor has to be equipped.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public EquipSet equip = EquipSet.None;

		[ORKEditorHelp("Equipment", "Select the equipment that will be checked for.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="equip")]
		[ORKEditorLayout("equip", EquipSet.None, elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public int id = 0;

		public EquipmentConditionFormulaNextNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(this.useSelectedData &&
				data.Contains<DataObject>("selectedKey"))
			{
				this.selectedData = new FormulaSelectedData();
				this.selectedData.SetData(data);
			}
		}

		public string GetInfoText()
		{
			if(this.useSelectedData)
			{
				return this.selectedData.GetInfoText();
			}
			else if(EquipSet.Weapon == this.equip)
			{
				return ORK.Weapons.GetName(this.id) + " (Weapon)";
			}
			else if(EquipSet.Armor == this.equip)
			{
				return ORK.Armors.GetName(this.id) + " (Armor)";
			}
			else
			{
				return "Unequipped";
			}
		}
	}
}
