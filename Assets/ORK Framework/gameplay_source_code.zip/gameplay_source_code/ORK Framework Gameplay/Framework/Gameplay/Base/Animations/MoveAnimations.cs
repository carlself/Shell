﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class MoveAnimations : BaseData
	{
		[ORKEditorHelp("Walk Type", "Select the animation type used for the walk animation " +
			"(i.e. when the combatant is walking (walk speed setting of the combatant).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int walkID = 0;

		[ORKEditorHelp("Run Type", "Select the animation type used for the run animation " +
			"(i.e. when the combatant is running (run speed setting of the combatant).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int runID = 0;

		[ORKEditorHelp("Sprint Type", "Select the animation type used for the sprint animation " +
			"(i.e. when the combatant is sprinting (sprint speed setting of the combatant).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int sprintID = 0;

		public MoveAnimations()
		{

		}

		public void Stop(Combatant combatant)
		{
			combatant.Animations.Stop(this.walkID);
			combatant.Animations.Stop(this.runID);
			combatant.Animations.Stop(this.sprintID);
		}
	}
}
