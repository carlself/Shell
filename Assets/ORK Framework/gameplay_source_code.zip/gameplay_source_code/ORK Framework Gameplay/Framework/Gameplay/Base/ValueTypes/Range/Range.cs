
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class Range : BaseData, IRange
	{
		[ORKEditorHelp("Range", "The range in world units.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float range = 5;

		[ORKEditorHelp("Threshold", "The threshold is used for a smoother range check.\n" +
			"In range is 'range - threshold', out of range is 'range + threshold'.\n" +
			"Use a negative value to invert the threshold.", "")]
		public float threshold = 0;

		[ORKEditorHelp("Ignore Height Distance", "The distance along the height axis will be ignored.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		[UnityEngine.Serialization.FormerlySerializedAs("ignoreYDistance")]
		public bool ignoreHeightDistance = true;

		[ORKEditorHelp("No Combatant Radius", "The combatant radius setting of the combatants will be ignored.", "")]
		public bool ignoreRadius = false;

		public Range()
		{

		}

		public Range(float range)
		{
			this.range = range;
		}

		public Range(float range, bool ignoreHeightDistance, bool ignoreRadius, float threshold)
		{
			this.range = range;
			this.threshold = threshold;
			this.ignoreHeightDistance = ignoreHeightDistance;
			this.ignoreRadius = ignoreRadius;
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("ignoreYDistance"))
			{
				data.Get("ignoreYDistance", ref this.ignoreHeightDistance);
			}
		}

		public bool IsInfinity
		{
			get { return this.range == Mathf.Infinity; }
		}


		/*
		============================================================================
		Static ranges
		============================================================================
		*/
		public static Range Infinity = new Range(Mathf.Infinity);

		public static Range Battle = new Range(Mathf.Infinity);


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public float GetInRangeDistance(Combatant combatant)
		{
			return this.range - this.threshold + (this.ignoreRadius ? 0 : combatant.Object.BoxRadius);
		}

		public float GetOutOfRangeDistance(Combatant combatant)
		{
			return this.range + this.threshold + (this.ignoreRadius ? 0 : combatant.Object.BoxRadius);
		}

		public IRange GetInRange(Combatant combatant)
		{
			Range range = new Range();
			range.range = this.range - this.threshold;
			range.ignoreHeightDistance = this.ignoreHeightDistance;
			range.ignoreRadius = this.ignoreRadius;
			return range;
		}

		public IRange GetOutOfRange(Combatant combatant)
		{
			Range range = new Range();
			range.range = this.range + this.threshold;
			range.ignoreHeightDistance = this.ignoreHeightDistance;
			range.ignoreRadius = this.ignoreRadius;
			return range;
		}

		public Vector3 GetAngledPosition(Combatant combatant, float angle, bool localSpace, HorizontalPlaneType horizontalPlane)
		{
			if(combatant != null && combatant.GameObject != null)
			{
				Vector3 position = combatant.GameObject.transform.position;
				float distance = this.GetInRangeDistance(combatant);

				if(HorizontalPlaneType.XZ == horizontalPlane)
				{
					position += Quaternion.Euler(0, angle, 0) *
						(localSpace ?
							(Quaternion.Euler(0, combatant.GameObject.transform.eulerAngles.y, 0) *
								new Vector3(0, 0, distance)) :
							new Vector3(0, 0, distance));
				}
				else if(HorizontalPlaneType.XY == horizontalPlane)
				{
					position += Quaternion.Euler(0, 0, -angle) *
						(localSpace ?
							(Quaternion.Euler(0, 0, combatant.GameObject.transform.eulerAngles.z) *
								new Vector3(0, distance, 0)) :
							new Vector3(0, distance, 0));
				}
				return position;
			}
			return Vector3.zero;
		}


		/*
		============================================================================
		In range functions
		============================================================================
		*/
		public bool InRange(Combatant combatant, Combatant target)
		{
			if(combatant != null && combatant.GameObject != null &&
				target != null && target.GameObject != null)
			{
				return VectorHelper.Distance(combatant.GameObject.transform.position,
						target.GameObject.transform.position, this.ignoreHeightDistance) -
					(this.ignoreRadius ? 0 : (combatant.Object.BoxRadius + target.Object.BoxRadius)) <= this.range - this.threshold;
			}
			return false;
		}

		public bool InRange(Vector3 position, Combatant combatant)
		{
			if(combatant != null && combatant.GameObject != null)
			{
				return VectorHelper.Distance(combatant.GameObject.transform.position, position, this.ignoreHeightDistance) -
					(this.ignoreRadius ? 0 : combatant.Object.BoxRadius) <= this.range - this.threshold;
			}
			return false;
		}

		public bool InRange(Vector3 position, Combatant combatant, float range)
		{
			return this.InRange(position, combatant, this.ignoreRadius, range);
		}

		public bool InRange(Vector3 position, Combatant combatant, bool ignoreRadius, float range)
		{
			if(combatant != null && combatant.GameObject != null)
			{
				return VectorHelper.Distance(combatant.GameObject.transform.position, position, this.ignoreHeightDistance) -
					(ignoreRadius ? 0 : combatant.Object.BoxRadius) <= range;
			}
			return false;
		}

		public bool InRange(Vector3 position, Vector3 position2)
		{
			return VectorHelper.Distance(position, position2, this.ignoreHeightDistance) <= this.range - this.threshold;
		}

		public static float Distance(Combatant user, Combatant target, bool ignoreHeightDistance, bool ignoreRadius)
		{
			if(user != null && user.GameObject != null &&
				target != null && target.GameObject != null)
			{
				return VectorHelper.Distance(user.GameObject.transform.position,
						target.GameObject.transform.position, ignoreHeightDistance) -
					(ignoreRadius ? 0 : (user.Object.BoxRadius + target.Object.BoxRadius));
			}
			else
			{
				return Mathf.Infinity;
			}
		}


		/*
		============================================================================
		Out of range functions
		============================================================================
		*/
		public bool OutOfRange(Combatant combatant, Combatant target)
		{
			if(combatant != null && combatant.GameObject != null &&
				target != null && target.GameObject != null)
			{
				return VectorHelper.Distance(combatant.GameObject.transform.position,
						target.GameObject.transform.position, this.ignoreHeightDistance) -
					(this.ignoreRadius ? 0 : (combatant.Object.BoxRadius + target.Object.BoxRadius)) >= this.range + this.threshold;
			}
			return false;
		}

		public bool OutOfRange(Vector3 position, Combatant combatant)
		{
			if(combatant != null && combatant.GameObject != null)
			{
				return VectorHelper.Distance(combatant.GameObject.transform.position, position, this.ignoreHeightDistance) -
					(this.ignoreRadius ? 0 : combatant.Object.BoxRadius) >= this.range + this.threshold;
			}
			return false;
		}

		public bool OutOfRange(Vector3 position, Combatant combatant, float range)
		{
			if(combatant != null && combatant.GameObject != null)
			{
				return VectorHelper.Distance(combatant.GameObject.transform.position, position, this.ignoreHeightDistance) -
					(this.ignoreRadius ? 0 : combatant.Object.BoxRadius) >= this.range + this.threshold;
			}
			return false;
		}

		public bool OutOfRange(Vector3 position, Vector3 position2)
		{
			return VectorHelper.Distance(position, position2, this.ignoreHeightDistance) >= this.range + this.threshold;
		}


		/*
		============================================================================
		In range status functions
		============================================================================
		*/
		public void CheckInRangeStatus(Combatant combatant, Combatant target, bool invert, ref bool inRangeStatus)
		{
			if(this.InRange(combatant, target))
			{
				inRangeStatus = invert ? false : true;
			}
			else if(this.OutOfRange(combatant, target))
			{
				inRangeStatus = invert ? true : false;
			}
		}

		public void CheckInRangeStatus(Vector3 position, Combatant combatant, bool invert, ref bool inRangeStatus)
		{
			if(this.InRange(position, combatant))
			{
				inRangeStatus = invert ? false : true;
			}
			else if(this.OutOfRange(position, combatant))
			{
				inRangeStatus = invert ? true : false;
			}
		}

		public void CheckInRangeStatus(Vector3 position, Vector3 position2, bool invert, ref bool inRangeStatus)
		{
			if(this.InRange(position, position2))
			{
				inRangeStatus = invert ? false : true;
			}
			else if(this.OutOfRange(position, position2))
			{
				inRangeStatus = invert ? true : false;
			}
		}
	}
}
