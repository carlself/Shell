
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Formulas
{
	public class FormulaStatusOrigin : BaseData
	{
		[ORKEditorHelp("Status Origin", "Select combatant that will be the origin of the status:" +
			"- User: The user of the formula (i.e. the combatant who uses an ability, item, hit chances, etc.).\n" +
			"- Target: The target of the formula (i.e. the combatant who is targeted by the ability, item, hit chance, etc.).\n" +
			"- Player: The player combatant. If there is no player, the user will be used.\n" +
			"- Selected: A combatant stored in selected data will be used.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public StatusOrigin origin = StatusOrigin.User;

		[ORKEditorLayout("origin", StatusOrigin.Selected, endCheckGroup=true, autoInit=true)]
		public FormulaSelectedData selectedData;

		[ORKEditorHelp("Group Leader", "The group leader of the combatant will be used.\n" +
			"If disabled, the combatant will be used.", "")]
		[ORKEditorLayout("origin", StatusOrigin.Player, elseCheckGroup=true, endCheckGroup=true)]
		public bool groupLeader = false;

		public FormulaStatusOrigin()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(StatusOrigin.Selected == this.origin &&
				data.Contains<DataObject>("selectedKey"))
			{
				this.selectedData = new FormulaSelectedData();
				this.selectedData.selectedKey.SetData(data.GetFile("selectedKey"));
			}
		}

		public Combatant GetCombatant(FormulaCall call)
		{
			if(StatusOrigin.User == this.origin)
			{
				return this.groupLeader ? call.user.Group.Leader : call.user;
			}
			else if(StatusOrigin.Target == this.origin)
			{
				return this.groupLeader ? call.target.Group.Leader : call.target;
			}
			else if(StatusOrigin.Player == this.origin)
			{
				if(ORK.Game.ActiveGroup.Leader != null)
				{
					return ORK.Game.ActiveGroup.Leader;
				}
			}
			else if(StatusOrigin.Selected == this.origin)
			{
				List<Combatant> selectedList = SelectedDataHelper.GetCombatants(
					this.selectedData.GetSelectedData(call));
				for(int i = 0; i < selectedList.Count; i++)
				{
					if(selectedList[i] != null)
					{
						return this.groupLeader ? selectedList[i].Group.Leader : selectedList[i];
					}
				}
			}
			return call.user;
		}

		public string GetInfoText()
		{
			if(StatusOrigin.Player == this.origin)
			{
				return "Player";
			}
			else if(StatusOrigin.Selected == this.origin)
			{
				return this.selectedData.GetInfoText() +
					(this.groupLeader ? " (Leader)" : "");
			}
			else
			{
				return this.origin.ToString() +
					(this.groupLeader ? " (Leader)" : "");
			}
		}
	}
}
