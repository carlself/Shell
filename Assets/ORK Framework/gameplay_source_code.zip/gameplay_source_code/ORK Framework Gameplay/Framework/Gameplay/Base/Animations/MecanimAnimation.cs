
using UnityEngine;
using UnityEngineInternal;
using ORKFramework;
using System.Collections.Generic;
using System.Reflection;

namespace ORKFramework.Animations
{
	public class MecanimAnimation : BaseData
	{
		[ORKEditorHelp("Animation Type", "Select the animation type of this animation.", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int typeID = 0;

		[ORKEditorHelp("State Name", "The name of the animation state (without layer name).", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";

		[ORKEditorHelp("Layer Index", "The index of the AnimatorController layer the animation state is on.", "")]
		public int layer = 0;

		// set layer weight
		[ORKEditorHelp("Set Layer Weight", "Set the current weight of the animation's layer before playing the animation.", "")]
		public bool setLayerWeight = false;

		[ORKEditorHelp("Layer Weight", "The current weight the layer will be set to.", "")]
		[ORKEditorLayout("setLayerWeight", true, endCheckGroup=true)]
		public float layerWeight = 1;


		// duration for wait in events
		[ORKEditorHelp("Duration Type", "Select how the animation's duration will be determind:\n" +
			"- Fixed: By a defined duration time.\n" +
			"- Animation Clip: By a defined animation clip's name. " +
			"This will search for the clip in the animator's controller and use the clip's length (if found), multiplied by the animator's speed..", "")]
		[ORKEditorInfo(separator=true, warning="Mecanim doesn't report any animation durations.\n" +
			"Make sure to define a duration or the name of the animation clip for this animation to be able to use 'Wait' options when using it.")]
		public MecanimDurationType durationType = MecanimDurationType.Fixed;

		[ORKEditorHelp("Duration (s)", "The duration of the state's animation clip.\n" +
			"This value is used in game events to set the wait time for animation steps.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("durationType", MecanimDurationType.Fixed)]
		public float duration = 0;

		[ORKEditorHelp("Use Animator Speed", "Multiply the duration by the speed of the animator.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool durationUseSpeed = false;

		[ORKEditorHelp("Use State Name", "Use the defined 'State Name' as animation clip name.\n" +
			"If disabled, you can define the name of the animation clip that will be used.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("durationType", MecanimDurationType.AnimationClip)]
		public bool durationUseState = true;

		[ORKEditorHelp("Animation Clip Name", "Set the name of the animation clip.", "")]
		[ORKEditorInfo(expandWidth=true, indent=true)]
		[ORKEditorLayout("durationUseState", false, endCheckGroup=true, endGroups=2)]
		public string durationClipName = "";


		// play
		[ORKEditorHelp("Play Mode", "Select how the state will be played:\n" +
			"- None: The state will not be played directly, only through setting parameters.\n" +
			"- Play: Uses Animator.Play to play the state directly.\n" +
			"- Cross Fade: Uses Animator.CrossFade to fade between the current and this state.", "")]
		[ORKEditorInfo(separator=true)]
		public MecanimPlayMode playMode = MecanimPlayMode.None;

		[ORKEditorHelp("Transition Duration", "The duration of the transition from the source state (current state) to this state.\n" +
			"defined in normalized time (between 0 and 1) of the source state.", "")]
		[ORKEditorLayout("playMode", MecanimPlayMode.CrossFade, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float transitionDuration = 0.1f;

		[ORKEditorHelp("Set Normalized Time", "Set the normalized time of the animation state when playing it.", "")]
		[ORKEditorLayout("playMode", MecanimPlayMode.None, elseCheckGroup=true)]
		public bool setNormalizedTime = false;

		[ORKEditorHelp("Normalized Time", "The normalized time the animation state will be set to when playing (0-1).\n" +
			"E.g. 1 will be the end of the animation, 0.5 in the middle of the animation.", "")]
		[ORKEditorLayout("setNormalizedTime", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float normalizedTime = 0;

		// parameters
		[ORKEditorArray(false, "Add Parameter (Play)", "Adds a parameter that will be set when the animation is played.", "",
			"Remove", "Removes this parameter.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Set Parameter (Play)", "The parameter will be set to the defined value when the animation is played.", ""
		})]
		public MecanimParameter[] playParameter = new MecanimParameter[0];


		// stop parameters
		[ORKEditorArray(false, "Add Parameter (Stop)", "Adds a parameter that will be set when the animation is stopped.", "",
			"Remove", "Removes this parameter.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {"Set Parameter (Stop)", "The parameter will be set to the defined value when the animation is stopped.\n" +
				"This is used when a combatant animation is stopped using the event system.", ""})]
		public MecanimParameter[] stopParameter = new MecanimParameter[0];

		public MecanimAnimation()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("usePlay"))
			{
				bool tmp = false;
				data.Get("usePlay", ref tmp);
				if(tmp)
				{
					this.playMode = MecanimPlayMode.Play;
				}
			}
		}


		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public AnimInfo Play(Animator animator, bool randomTime)
		{
			if(this.setLayerWeight)
			{
				animator.SetLayerWeight(this.layer, this.layerWeight);
			}

			for(int i = 0; i < this.playParameter.Length; i++)
			{
				this.playParameter[i].Set(animator);
			}

			if(MecanimPlayMode.Play == this.playMode)
			{
				if(randomTime)
				{
					animator.Play(this.name, this.layer, UnityWrapper.Range(0.0f, 1.0f));
				}
				else if(this.setNormalizedTime)
				{
					animator.Play(this.name, this.layer, this.normalizedTime);
				}
				else
				{
					animator.Play(this.name, this.layer);
				}
			}
			else if(MecanimPlayMode.CrossFade == this.playMode)
			{
				if(randomTime)
				{
					animator.CrossFade(this.name, this.transitionDuration, this.layer, UnityWrapper.Range(0.0f, 1.0f));
				}
				else if(this.setNormalizedTime)
				{
					animator.CrossFade(this.name, this.transitionDuration, this.layer, this.normalizedTime);
				}
				else
				{
					animator.CrossFade(this.name, this.transitionDuration, this.layer);
				}
			}

			return new AnimInfo(AnimationSystem.Mecanim,
				animator.GetLayerName(this.layer) + "." + this.name,
				this.GetDuration(animator));
		}

		public void Stop(Animator animator)
		{
			for(int i = 0; i < this.stopParameter.Length; i++)
			{
				this.stopParameter[i].Set(animator);
			}
		}

		public float GetDuration(Animator animator)
		{
			float tmpDuration = 0;
			if(MecanimDurationType.Fixed == this.durationType)
			{
				tmpDuration = this.duration;
				if(this.durationUseSpeed)
				{
					tmpDuration *= animator.speed;
				}
			}
			else if(MecanimDurationType.AnimationClip == this.durationType)
			{
				tmpDuration = AnimationHelper.GetClipLength(animator,
					this.durationUseState ? this.name : this.durationClipName);
			}
			return tmpDuration;
		}
	}
}
