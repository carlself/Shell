﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GameRunningState : GameState
	{
		[ORKEditorHelp("Game Running", "Select the required game running state:\n" +
			"- Yes: The game must be started (i.e. new game or load game).\n" +
			"- No: The game mustn't be started (e.g. during the main menu or after game over).\n" +
			"- Ignore: game running state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider gameRunning = Consider.Yes;

		public GameRunningState()
		{

		}

		public GameRunningState(Consider consider) : base(consider)
		{

		}

		public override bool Check()
		{
			return (Consider.Ignore == this.gameRunning ||
					(Consider.Yes == this.gameRunning) == ORK.Game.Running) &&
				base.Check();
		}
	}
}
