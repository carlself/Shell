
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class Requirement : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of the requirement.", "")]
		[ORKEditorInfo("Base Settings", "Set the name, game state requirements and variable conditions of this requirement.", "",
			expandWidth=true)]
		public string name = "";

		// game state
		[ORKEditorInfo(separator=true, labelText="Required Game State")]
		public GameState gameState = new GameState();

		// variable conditions
		[ORKEditorInfo(separator=true, endFoldout=true, labelText="Variable Conditions")]
		public VariableCondition variables = new VariableCondition();


		// group requirements
		[ORKEditorHelp("Check Group Size", "There has to be at least the given number of active group members " +
			"(not battle group members), otherwise the requirement is not valid.", "")]
		[ORKEditorInfo("Group Requirements", "Specific combatant or group conditions must be valid.", "")]
		public bool useGroupSize = false;

		[ORKEditorHelp("Minimum Size", "The minimum size of the active group.", "")]
		[ORKEditorLayout("useGroupSize", true, endCheckGroup=true)]
		public int minGroupSize = 1;

		[ORKEditorHelp("Check Battle Size", "There has to be at least the given number of battle group members, " +
			"else the requirement is not valid.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useBattleSize = false;

		[ORKEditorHelp("Minimum Size", "The minimum size of the battle group.", "")]
		[ORKEditorLayout("useBattleSize", true, endCheckGroup=true)]
		public int minBattleSize = 1;


		// status requirements
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed needed = Needed.All;

		[ORKEditorHelp("Only Battle Group", "Only the battle group will be checked for the status requirements.\n" +
			"If disabled, the whole active group will be checked.\n" +
			"All combatants that are checked must met the status requirements, otherwise the requirement is not valid.", "")]
		public bool onlyBattle = true;

		[ORKEditorArray(false, "Add Status Requirement", "Adds a status requirement.\n" +
			"The status requirements must be valid for all members of the group.", "",
			"Remove", "Removes the status requirement", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		public StatusRequirement[] req = new StatusRequirement[0];


		// combatants
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Combatant Requirement", "Adds a required combatant.", "",
			"Remove", "Removes the required combatant.", "", isCopy=true, isMove=true,
			removeType=ORKDataType.Combatant, removeCheckField="id",
			foldout=true, foldoutText=new string[] {
				"Combatant Requirement", "Define the combatant that is required.", ""
		})]
		public CombatantRequirement[] combatant = new CombatantRequirement[0];


		// general
		[ORKEditorHelp("Has Items", "The inventory must contain at least one item.", "")]
		[ORKEditorInfo("General Requirements", "Specific inventory, log or quest conditions must be valid.", "")]
		public bool hasItems = false;

		[ORKEditorHelp("Has Equipment", "The inventory must contain at least one weapon or armor.", "")]
		public bool hasEquipment = false;

		[ORKEditorHelp("Check Equipped", "Additionally checks if one of the player group members has an equipped weapon or armor.", "")]
		[ORKEditorLayout("hasEquipment", true, endCheckGroup=true)]
		public bool checkEquipped = false;

		[ORKEditorHelp("Knows Recipes", "The group must know at least one crafting recipe.", "")]
		public bool knowsRecipes = false;

		[ORKEditorHelp("Knows Logs", "The group must know at least one log.", "")]
		public bool knowsLogs = false;

		// quest
		[ORKEditorHelp("Has Quests", "The group must have at least one quest.", "")]
		[ORKEditorInfo(separator=true, labelText="Quest Requirements")]
		public bool hasQuests = false;

		[ORKEditorHelp("Has Not Ended Quests", "The group must have at least one active or inactive quest.", "")]
		public bool hasNotEndedQuests = false;

		[ORKEditorHelp("Has Ended Quests", "The group must have at least one finished or failed quest.", "")]
		public bool hasEndedQuests = false;

		// bestiary
		[ORKEditorHelp("Has Bestiary Entries", "The bestiary must contain at least one entry.", "")]
		[ORKEditorInfo(separator=true, labelText="Other Requirements")]
		public bool hasBestiaryEntries = false;

		// items
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Item", "Adds a required item to the list.", "",
			"Remove", "Removes this item from the list.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Item Requirement", "Define the item, equipment or money that is required.", ""
		})]
		public ItemGain[] item = new ItemGain[0];

		public Requirement()
		{

		}

		public Requirement(string n)
		{
			this.name = n;
		}

		// group
		public bool CheckGroup()
		{
			// check group sizes
			if(this.useGroupSize && ORK.Game.ActiveGroup.Size < this.minGroupSize)
			{
				return false;
			}
			if(this.useBattleSize && ORK.Game.ActiveGroup.BattleSize < this.minBattleSize)
			{
				return false;
			}

			// check group status
			List<Combatant> list = this.onlyBattle ?
				ORK.Game.ActiveGroup.GetBattle() : ORK.Game.ActiveGroup.GetGroup();
			foreach(Combatant c in list)
			{
				if(c != null &&
					!StatusRequirement.Check(c, this.req, this.needed))
				{
					return false;
				}
			}
			return true;
		}

		public bool CheckCombatants()
		{
			bool check = true;
			for(int i = 0; i < this.combatant.Length; i++)
			{
				check = this.combatant[i].Check();
				if(check == false)
				{
					break;
				}
			}
			return check;
		}

		public bool CheckGeneral()
		{
			if(this.hasItems &&
				ORK.Game.ActiveGroup.Inventory.Items.IsEmpty)
			{
				return false;
			}
			if(this.hasEquipment &&
				ORK.Game.ActiveGroup.Inventory.HasEquipment() &&
				(!this.checkEquipped ||
					!ORK.Game.ActiveGroup.Inventory.HasEquippedEquipment()))
			{
				return false;
			}
			if(this.knowsRecipes && ORK.Game.ActiveGroup.Inventory.Crafting.IsEmpty)
			{
				return false;
			}
			if(this.knowsLogs && !ORK.Game.Logs.HasLogs())
			{
				return false;
			}
			// quests
			if(this.hasQuests && !ORK.Game.Quests.HasQuests())
			{
				return false;
			}
			if(this.hasNotEndedQuests && !ORK.Game.Quests.HasNotEndedQuests())
			{
				return false;
			}
			if(this.hasEndedQuests && !ORK.Game.Quests.HasEndedQuests())
			{
				return false;
			}
			// bestiary
			if(this.hasBestiaryEntries && ORK.Game.Bestiary.Count == 0)
			{
				return false;
			}
			// items
			if(this.item.Length > 0 && !ORK.Game.ActiveGroup.Inventory.Has(this.item))
			{
				return false;
			}
			return true;
		}

		// overall check
		public bool Check()
		{
			return this.gameState.Check() && this.variables.CheckVariables() &&
				this.CheckGroup() && this.CheckCombatants() && this.CheckGeneral();
		}
	}
}

