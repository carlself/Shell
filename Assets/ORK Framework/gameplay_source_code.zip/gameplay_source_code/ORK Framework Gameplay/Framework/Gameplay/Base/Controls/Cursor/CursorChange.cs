﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CursorChange : BaseData
	{
		[ORKEditorHelp("Cursor Texture", "Select the texture that will be used as mouse cursor.", "")]
		public AssetSource<Texture2D> texture = new AssetSource<Texture2D>();

		[ORKEditorHelp("Cursor Hotspot", "The offset from the top left corner of the texture to use as the target point.\n" +
				"Must be within the bounds of the cursor.", "")]
		[ORKEditorLayout("texture", null, elseCheckGroup=true)]
		public Vector2 hotSpot = Vector2.zero;

		[ORKEditorHelp("Cursor Mode", "Select the mode of the cursor:\n" +
			"- Auto: Use hardware cursors on supported platforms.\n" +
			"- Force Software: Force the use of software cursors.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public CursorMode cursorMode = CursorMode.Auto;

		public CursorChange()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<Texture>("texture"))
			{
				Texture tmp = null;
				data.Get("texture", ref tmp);
				ReferenceAssetSource<Texture2D> tmpSettings = new ReferenceAssetSource<Texture2D>();
				tmpSettings.asset = tmp as Texture2D;
				this.texture.settings = tmpSettings;
				this.texture.type = this.texture.settings.GetGenericTypeName();
			}
		}


		/*
		============================================================================
		Cursor functions
		============================================================================
		*/
		public bool SetCursor()
		{
			Texture2D cursorTexture = this.texture;
			if(cursorTexture != null)
			{
				Cursor.SetCursor(cursorTexture, this.hotSpot, this.cursorMode);
				return true;
			}
			Texture2D tmpTex = null;
			this.texture.settings.EditorAsset = tmpTex;
			return false;
		}

		public void ResetCursor()
		{
			Texture2D cursorTexture = this.texture;
			if(cursorTexture != null)
			{
				Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
			}
		}
	}
}
