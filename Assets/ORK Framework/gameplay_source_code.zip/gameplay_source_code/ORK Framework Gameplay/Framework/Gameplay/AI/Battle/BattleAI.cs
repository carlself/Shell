
using UnityEngine;
using ORKFramework;
using ORKFramework.AI.Steps;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class BattleAI : BaseNode
	{
		[ORKEditorHelp("Name", "The name of the battle AI.", "")]
		[ORKEditorInfo("AI Settings", "Set the name and base settings of the battle AI.", "",
			expandWidth=true)]
		public string name = "";

		[ORKEditorHelp("Clear Found Targets", "Clear the found targets list at the start of this battle AI.\n" +
			"Removes all targets that where found by battle AIs that where executed before this one.", "")]
		[ORKEditorInfo(endFoldout=true, separator=true)]
		public bool clearFoundTargets = false;


		// AI steps
		[ORKEditorInfo(hide=true)]
		public int startIndex = -1;

		[ORKEditorInfo(hide=true)]
		public BaseAIStep[] step = new BaseAIStep[0];

		public BattleAI()
		{

		}

		public BattleAI(string name)
		{
			this.name = name;
		}

		public BaseAction GetAction(BattleAICall call)
		{
			BaseAction action = null;
			int currentStep = this.startIndex;

			if(this.clearFoundTargets)
			{
				call.foundTargets.Clear();
			}

			while(action == null &&
				currentStep >= 0 &&
				currentStep < this.step.Length)
			{
				if(this.step[currentStep].IsEnabled)
				{
					action = this.step[currentStep].Execute(ref currentStep, call);
				}
				else
				{
					currentStep = this.step[currentStep].GetNext(0);
				}
			}

			return action;
		}

		public static List<Combatant> GetTargetList(BattleAITargetType type,
			bool excludeSelf, bool excludeFoundTargets, BattleAICall call)
		{
			List<Combatant> list = new List<Combatant>();
			if(BattleAITargetType.Self == type)
			{
				list.Add(call.user);
			}
			else if(BattleAITargetType.Ally == type)
			{
				if(excludeSelf || excludeFoundTargets)
				{
					for(int i = 0; i < call.allies.Count; i++)
					{
						if((!excludeSelf ||
								call.allies[i] != call.user) &&
							(!excludeFoundTargets ||
								!call.foundTargets.Contains(call.allies[i])))
						{
							list.Add(call.allies[i]);
						}
					}
				}
				else
				{
					list.AddRange(call.allies);
				}
			}
			else if(BattleAITargetType.Enemy == type)
			{
				if(excludeFoundTargets)
				{
					for(int i = 0; i < call.enemies.Count; i++)
					{
						if(!call.foundTargets.Contains(call.enemies[i]))
						{
							list.Add(call.enemies[i]);
						}
					}
				}
				else
				{
					list.AddRange(call.enemies);
				}
			}
			else if(BattleAITargetType.All == type)
			{
				// allies
				if(excludeSelf || excludeFoundTargets)
				{
					for(int i = 0; i < call.allies.Count; i++)
					{
						if((!excludeSelf ||
								call.allies[i] != call.user) &&
							(!excludeFoundTargets ||
								!call.foundTargets.Contains(call.allies[i])))
						{
							list.Add(call.allies[i]);
						}
					}
				}
				else
				{
					list.AddRange(call.allies);
				}
				// enemies
				if(excludeFoundTargets)
				{
					for(int i = 0; i < call.enemies.Count; i++)
					{
						if(!call.foundTargets.Contains(call.enemies[i]))
						{
							list.Add(call.enemies[i]);
						}
					}
				}
				else
				{
					list.AddRange(call.enemies);
				}
			}
			return list;
		}

		public static List<Combatant> GetPreferredTargets(Combatant user, List<Combatant> foundTargets)
		{
			if(foundTargets.Count == 0)
			{
				List<Combatant> tmp = new List<Combatant>();
				if(user.Setting.attackLastTarget &&
					user.Battle.LastTargets.Count > 0)
				{
					tmp.AddRange(user.Battle.LastTargets);
				}
				return tmp;
			}
			else
			{
				return foundTargets;
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "Battle AI Settings";
		}

		public override string GetNodeDetails()
		{
			return "";
		}

		public override string GetNextName(int index)
		{
			return "Start";
		}

		public override bool IsRemovable()
		{
			return false;
		}


		/*
		============================================================================
		Next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}

		public override int GetNext(int index)
		{
			return this.startIndex;
		}

		public override void SetNext(int index, int next)
		{
			this.startIndex = next;
		}
	}
}
