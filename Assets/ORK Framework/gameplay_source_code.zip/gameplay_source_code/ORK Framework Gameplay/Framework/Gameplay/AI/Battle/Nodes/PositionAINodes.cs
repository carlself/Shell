
using UnityEngine;
using System.Collections.Generic;
using System.Text;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Check Distance", "The distance between user and target is checked with a defined value.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckDistanceStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// distance
		[ORKEditorHelp("Ignore Height Distance", "Height differences to the targets are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		[ORKEditorInfo(separator=true, labelText="Distance")]
		public bool ignoreHeightDistance = false;

		[ORKEditorHelp("Ignore Radius", "The box radius settings of the combatants will be ignored when calculating the distance.", "")]
		public bool ignComRad = false;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();


		// check
		[ORKEditorInfo(separator=true)]
		public AIValueCheck check = new AIValueCheck();

		public CheckDistanceStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("ignY"))
			{
				data.Get("ignY", ref this.ignoreHeightDistance);
			}
			this.check.UpgradeAIFloat(data, "check", "value", "value2");
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call, call.user,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status requirements
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.check.Check(user.Object.DistanceTo(list[i],
							this.ignoreHeightDistance, this.ignComRad, this.horizontalPlane),
						call, user, list[i]))
					{
						any = true;
						if(!this.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.GetInfoText();
		}
	}

	[ORKEditorHelp("Check Angle", "The angle between user and target is checked with a defined value.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckAngleStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// angle
		[ORKEditorHelp("Use Direction", "The angle between the forward directions of user and target will be calculated.\n" +
			"E.g. the result will be 0 if both are looking into the same direction, -180/180 if they look into opposite directions.\n" +
			"If disabled, the angle between the positions will be calculated.\n" +
			"E.g. the result will be 0 if the user looks directly at the target, -180/180 if he looks away from the target.", "")]
		[ORKEditorInfo(separator=true, labelText="Angle")]
		public bool direction = false;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		[ORKEditorHelp("From Target", "The angle is calculated from target to user.\n" +
			"If disabled, the angle is calculated from user to target.", "")]
		[ORKEditorLayout("direction", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool fromTarget = false;


		// check
		[ORKEditorInfo(separator=true, warning="Angle has to be between -180 and 180")]
		public AIValueCheck check = new AIValueCheck();

		public CheckAngleStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeAIFloat(data, "check", "value", "value2");
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call, call.user,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status requirements
			if(user.GameObject != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null && list[i].GameObject != null)
					{
						float tmpVal = 0;
						if(this.direction)
						{
							tmpVal = VectorHelper.HorizontalDirectionAngle(user.GameObject.transform,
								list[i].GameObject.transform, this.horizontalPlane);
						}
						else if(this.fromTarget)
						{
							tmpVal = VectorHelper.HorizontalAngle(list[i].GameObject.transform,
								user.GameObject.transform.position, this.horizontalPlane);
						}
						else
						{
							tmpVal = VectorHelper.HorizontalAngle(user.GameObject.transform,
								list[i].GameObject.transform.position, this.horizontalPlane);
						}

						if(this.check.Check(tmpVal, call, user, list[i]))
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.GetInfoText() + (this.direction ? " Direction" : "") +
				(this.fromTarget ? " from Target" : "");
		}
	}

	[ORKEditorHelp("Check Orientation", "Checks the orientation from user to target (e.g. if the target is in front of the user).\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckOrientationStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// orientation
		[ORKEditorHelp("Orientation", "Select the orientation that'll be checked for:\n" +
			"- None: The orientation is ignored.\n" +
			"- Front: The target has to be in front of the user.\n" +
			"- Back: The target has to be in the back of the user.\n" +
			"- Left: The target has to be left of the user.\n" +
			"- Right: The target has to be right of the user.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, separator=true, labelText="Orientation")]
		public Orientation orientation = Orientation.Front;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		[ORKEditorHelp("From Target", "The orientation is checked from target to user.\n" +
			"If disabled, the orientation is checked from user to target.", "")]
		public bool fromTarget = false;

		public CheckOrientationStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call.user,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status requirements
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					Orientation check = Orientation.None;
					if(user.GameObject != null && list[i].GameObject != null)
					{
						if(this.fromTarget)
						{
							check = VectorHelper.GetOrientation(list[i].GameObject.transform,
								user.GameObject.transform, this.horizontalPlane);
						}
						else
						{
							check = VectorHelper.GetOrientation(user.GameObject.transform,
								list[i].GameObject.transform, this.horizontalPlane);
						}
					}
					if(Orientation.None == this.orientation ||
						this.orientation == check)
					{
						any = true;
						if(!this.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.orientation + (this.fromTarget ? ", from Target" : "");
		}
	}

	[ORKEditorHelp("Check Grid Distance", "The distance on a battle grid between user and target is checked with a defined value.\n" +
		"Neighbouring cells have a distance of 1, a cell between is distance of 2, etc.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckGridDistanceStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// check
		[ORKEditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		[ORKEditorInfo(separator=true)]
		public bool blockDiagonalDistance1 = false;

		[ORKEditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		public bool ignoreSizeCells = false;

		// grid formation
		[ORKEditorHelp("Check Formation", "If the user is part of a grid formation, " +
			"all formation position cells will be checked, using the lowest distance to the checked combatant.", "")]
		[ORKEditorInfo(separator=true)]
		public bool checkFormation = false;

		[ORKEditorHelp("Only Filled Positions", "Only positions that have a combatant assigned will be checked.\n" +
			"If disabled, all position cells will be checked.", "")]
		[ORKEditorLayout("checkFormation", true)]
		public bool formationOnlyFilled = true;

		[ORKEditorHelp("Only On Position", "Only positions where the assigned combatant is on the position's cell will be checked.\n" +
			"If disabled, a filled position's cell will be checked in any case.", "")]
		[ORKEditorLayout("formationOnlyFilled", true, endCheckGroup=true, endGroups=2)]
		public bool formationOnlyOnPosition = false;

		[ORKEditorInfo(separator=true)]
		public AIValueCheck check = new AIValueCheck();

		public CheckGridDistanceStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeAIFloat(data, "check", "value", "value2");
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;

			if(ORK.Battle.Grid != null &&
				call.user.Grid.Cell != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, call, call.user, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call, call.user, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any, call, call.user,
					BattleAI.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(this.checkFormation &&
				user.Group.InGridFormation)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].Grid.Cell != null)
					{
						if(user.Group.GridFormation.CheckGridDistance(list[i],
								(int)this.check.value.GetValue(call, user, list[i]),
								(int)(this.check.value2 != null ? this.check.value2.GetValue(call, user, list[i]) : 0),
								this.check.type, this.blockDiagonalDistance1, this.ignoreSizeCells,
								this.formationOnlyFilled, this.formationOnlyOnPosition))
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null && list[i].Grid.Cell != null)
					{
						if(this.ignoreSizeCells ?
							this.check.Check(
								user.Grid.Cell.CubeCoord.Distance(
									list[i].Grid.Cell.CubeCoord, this.blockDiagonalDistance1),
								call, user, list[i]) :
							user.Grid.CheckDistance(
								list[i], this.blockDiagonalDistance1,
								(int)this.check.value.GetValue(call, user, list[i]),
								(int)(this.check.value2 != null ? this.check.value2.GetValue(call, user, list[i]) : 0),
								this.check.type, null))
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.GetInfoText();
		}
	}



	[ORKEditorHelp("Is Grid Cell Diagonal", "Checks if user and target are diagonal to each other ('Square' grids only).\n" +
		"Any combatant that is diagonal will be added to the target list. " +
		"The target list will be used by actions to determine the target.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class IsGridCellDiagonalStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// check
		[ORKEditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		[ORKEditorInfo(separator=true)]
		public bool ignoreSizeCells = false;

		public IsGridCellDiagonalStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;

			if(ORK.Battle.Grid != null &&
				ORK.Battle.SystemSettings.gridSettings.IsSquare &&
				call.user.Grid.Cell != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, call, call.user, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call, call.user, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any, call, call.user,
					BattleAI.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null && list[i].Grid.Cell != null)
				{
					if(this.ignoreSizeCells ?
						CubeCoord.IsSquareDiagonal(user.Grid.Cell.CubeCoord, list[i].Grid.Cell.CubeCoord) :
						user.Grid.CheckDiagonal(list[i]))
					{
						any = true;
						if(!this.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}
	}

	[ORKEditorHelp("Rotate To Target", "Changes the user's rotation to look at the found target.", "")]
	[ORKNodeInfo("Position")]
	public class RotateToTargetStep : BaseAIStep
	{
		[ORKEditorHelp("Use Center", "Use the center position when multiple targets are available.\n" +
			"If disabled, the first available target will be used.", "")]
		public bool useCenter = false;

		public RotateToTargetStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(call.user.GameObject != null)
			{
				List<Combatant> preferredTargets = BattleAI.GetPreferredTargets(call.user, call.foundTargets);

				if(preferredTargets.Count > 0)
				{
					if(this.useCenter)
					{
						call.user.Object.LookAt(TransformHelper.GetCenterPosition(preferredTargets));
					}
					else
					{
						for(int i = 0; i < preferredTargets.Count; i++)
						{
							if(preferredTargets[i] != null &&
								preferredTargets[i].GameObject != null)
							{
								call.user.Object.LookAt(preferredTargets[i]);
								break;
							}
						}
					}
				}
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useCenter ? "Center" : "";
		}
	}

	[ORKEditorHelp("Grid Rotate To Target", "Changes the user's orientation on the grid to look at the found target.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Position")]
	public class GridRotateToTargetStep : BaseAIStep
	{
		[ORKEditorHelp("Use Center", "Use the center position when multiple targets are available.\n" +
			"If disabled, the first available target will be used.", "")]
		public bool useCenter = false;

		[ORKEditorHelp("Block Diagonal Rotation", "Diagonal cells in square grids will be ignored " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).\n" +
			"The combatant won't rotate to a diagonal direction (square grids).", "")]
		public bool blockDiagonalRotation = false;

		public GridRotateToTargetStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				call.user.Grid.Cell != null)
			{
				List<Combatant> preferredTargets = BattleAI.GetPreferredTargets(call.user, call.foundTargets);

				if(preferredTargets.Count > 0)
				{
					if(this.useCenter)
					{
						BattleGridHelper.RotateToPosition(call.user,
							TransformHelper.GetCenterPosition(preferredTargets),
							!this.blockDiagonalRotation);
					}
					else
					{
						for(int i = 0; i < preferredTargets.Count; i++)
						{
							if(preferredTargets[i] != null &&
								preferredTargets[i].GameObject != null)
							{
								BattleGridHelper.RotateToPosition(call.user,
									preferredTargets[i].GameObject.transform.position,
									!this.blockDiagonalRotation);
								break;
							}
						}
					}
				}
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useCenter ? "Center" : "";
		}
	}

	[ORKEditorHelp("Get Nearest", "Adds the nearest combatant to the target list.\n" +
	   "The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position")]
	public class GetNearestStep : BaseAIStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// distance
		[ORKEditorHelp("Ignore Height Distance", "Height differences to the targets are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		[ORKEditorInfo(separator=true, labelText="Check Distance")]
		public bool ignoreHeightDistance = false;

		[ORKEditorHelp("Ignore Radius", "The box radius settings of the combatants will be ignored when calculating the distance.", "")]
		public bool ignComRad = false;

		[ORKEditorHelp("Nearest Offset Index", "Defines which nearest combatant will be used.\n" +
			"If the index exceeds the available combatants, no combatant will be used.\n" +
			"E.g. 0 is the nearest, 1 is the 2nd nearest, etc.", "")]
		[ORKEditorLimit(0, false)]
		public int nearestOffsetIndex = 0;

		[ORKEditorHelp("Use Grid Distance", "Use the grid distance when used in battles with a battle grid.", "")]
		public bool useGridDistance = false;

		[ORKEditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		[ORKEditorLayout("useGridDistance", true)]
		public bool blockDiagonalDistance1 = false;

		[ORKEditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool ignoreSizeCells = false;

		[ORKEditorHelp("Inverse Order", "Inverse distance order.", "")]
		public bool inverseOrder = false;

		public GetNearestStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(call.user,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			currentStep = this.next;
			return null;
		}

		private void Check(Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(this.useGridDistance &&
				ORK.Battle.Grid != null &&
				user.Grid.Cell != null)
			{
				list.Sort(new CombatantGridDistanceSorter(
					user, this.blockDiagonalDistance1,
					this.ignoreSizeCells, this.inverseOrder));
			}
			else
			{
				list.Sort(new CombatantDistanceSorter(user,
					this.ignoreHeightDistance, this.ignComRad, this.inverseOrder));
			}

			Combatant nearest = this.nearestOffsetIndex < list.Count ?
				list[this.nearestOffsetIndex] : null;

			if(nearest != null &&
				!foundTargets.Contains(nearest))
			{
				foundTargets.Add(nearest);
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "";
		}
	}

	[ORKEditorHelp("In Use Range", "Checks if a combatant is within use range of a selected action of the user, " +
		"a battle range template or a custom battle range.\n" +
		"If the check is valid, 'In Range' will be executed, otherwise 'Out Of Range'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class InUseRangeStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// use range
		[ORKEditorHelp("Reverse", "Check if the user is within use range of the target.\n" +
			"If disabled, checks if the target is within use range of the user.", "")]
		[ORKEditorInfo(separator=true)]
		public bool reverse = false;

		public UseRangeCheck useRangeCheck = new UseRangeCheck();

		public InUseRangeStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;

			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call.user,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status requirements
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.reverse ?
						this.useRangeCheck.Check(list[i], user) :
						this.useRangeCheck.Check(user, list[i]))
					{
						any = true;
						if(!this.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "In Range";
			}
			else if(index == 1)
			{
				return "Out Of Range";
			}
			return "";
		}

		public override string GetNodeDetails()
		{
			return this.useRangeCheck.GetInfoText();
		}
	}

	[ORKEditorHelp("Distance Sort Targets", "Sort the found targets based on their distance to the user.", "")]
	[ORKNodeInfo("Position")]
	public class DistanceSortTargetsStep : BaseAIStep
	{
		[ORKEditorHelp("Ignore Height Distance", "Height differences to the targets are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		public bool ignoreHeightDistance = false;

		[ORKEditorHelp("Ignore Radius", "The box radius settings of the combatants will be ignored when calculating the distance.", "")]
		public bool ignComRad = false;

		[ORKEditorHelp("Use Grid Distance", "Use the grid distance when used in battles with a battle grid.", "")]
		public bool useGridDistance = false;

		[ORKEditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		[ORKEditorLayout("useGridDistance", true)]
		public bool blockDiagonalDistance1 = false;

		[ORKEditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool ignoreSizeCells = false;

		[ORKEditorHelp("Inverse Order", "Inverse the sorting.", "")]
		public bool inverseOrder = false;

		public DistanceSortTargetsStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(call.user.GameObject != null)
			{
				if(this.useGridDistance &&
					ORK.Battle.Grid != null &&
					call.user.Grid.Cell != null)
				{
					call.foundTargets.Sort(new CombatantGridDistanceSorter(
						call.user, this.blockDiagonalDistance1,
						this.ignoreSizeCells, this.inverseOrder));
				}
				else
				{
					call.foundTargets.Sort(new CombatantDistanceSorter(call.user,
						this.ignoreHeightDistance, this.ignComRad, this.inverseOrder));
				}
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.inverseOrder ? "Inverse" : "";
		}
	}

	[ORKEditorHelp("Check Grid Cell Type", "Checks if a combatant is currently on a cell of a defined grid cell type.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckGridCellTypeStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// settings
		[ORKEditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		[ORKEditorInfo(separator=true)]
		public bool ignoreSizeCells = false;


		// grid cell type
		[ORKEditorHelp("Grid Cell Type", "Select the grid cell type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridCellType, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Grid Cell Type", "Adds a grid cell type that will be used.", "",
			"Remove", "Removes the grid cell type.", "", isHorizontal=true, noRemoveCount=1)]
		public int[] gridCellTypeID = new int[1];

		public CheckGridCellTypeStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;

			if(ORK.Battle.Grid != null &&
				call.user.Grid.Cell != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, call.user, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any, call.user,
					BattleAI.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Grid.Cell != null)
				{
					if(this.ignoreSizeCells ?
						BattleGridHelper.IsCellType(list[i].Grid.Cell, this.gridCellTypeID) :
						list[i].Grid.IsOnCellType(this.gridCellTypeID))
					{
						any = true;
						if(!this.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			StringBuilder builder = new StringBuilder();
			for(int i = 0; i < this.gridCellTypeID.Length; i++)
			{
				if(i > 0)
				{
					builder.Append(", ");
				}
				builder.Append(ORK.BattleGridCellTypes.GetName(this.gridCellTypeID[i]));
			}
			return builder.ToString();
		}
	}

	[ORKEditorHelp("Get Weighted Group", "Uses the largest or smallest weighted group of combatants as targets.\n" +
		"A weighted group is based on the physical proximity between combatants, defined by a maximum distance between them.\n" +
		"The combatants of the weighted group will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position")]
	public class GetWeightedGroupStep : BaseAIStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// weighted group
		[ORKEditorHelp("Weighted Group", "Select which weighted group will used:\n" +
			"- Smallest: The weighted group with the least combatants.\n" +
			"- Largest: The weighted group with the most combatants.", "")]
		[ORKEditorInfo(separator=true)]
		public WeightedGroupType groupType = WeightedGroupType.Largest;

		[ORKEditorHelp("Same Size", "Select which group will be used if multiple groups of the same size are found:\n" +
			"- Nearest: Uses the group with the nearest combatant.\n" +
			"- Nearest Average: Uses the nearest group (average distance)\n" +
			"- Farthest: Uses the group with the farthest combatant.\n" +
			"- Farthest Average: Uses the farthest group (average distance)\n" +
			"- All: Uses all groups.", "")]
		public DistanceType distanceType = DistanceType.Nearest;


		// distance
		[ORKEditorInfo(separator=true, labelText="Maximum Distance",
			label=new string[] {
				"The maximum distance between combatants to be part of a weighted group."
		})]
		public AIFloat distance = new AIFloat();

		// grid distance
		[ORKEditorHelp("Use Grid Distance", "Use the grid distance when used in battles with a battle grid.", "")]
		public bool useGridDistance = false;

		[ORKEditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		[ORKEditorLayout("useGridDistance", true)]
		public bool blockDiagonalDistance1 = false;

		[ORKEditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		public bool ignoreSizeCells = false;

		// regular distance
		[ORKEditorHelp("Ignore Height Distance", "Height differences to the targets are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		[ORKEditorLayout(elseCheckGroup=true)]
		public bool ignoreHeightDistance = false;

		[ORKEditorHelp("Ignore Radius", "The box radius settings of the combatants will be ignored when calculating the distance.", "")]
		public bool ignComRad = false;

		[ORKEditorLayout(endCheckGroup=true)]
		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		public GetWeightedGroupStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(call, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(call, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(call, call.user,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			currentStep = this.next;
			return null;
		}

		private void Check(BattleAICall call, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			List<List<Combatant>> groups = new List<List<Combatant>>();

			// grid distance
			if(this.useGridDistance &&
				ORK.Battle.Grid != null &&
				user.Grid.Cell != null)
			{
				List<Combatant> combatants = new List<Combatant>();
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].Grid.Cell != null)
					{
						combatants.Add(list[i]);
					}
				}

				while(combatants.Count > 0)
				{
					groups.Add(this.GetWeightedGroupGrid(call, combatants));
				}
			}
			// distance
			else
			{
				List<Combatant> combatants = new List<Combatant>();
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].GameObject != null)
					{
						combatants.Add(list[i]);
					}
				}

				while(combatants.Count > 0)
				{
					groups.Add(this.GetWeightedGroup(call, combatants));
				}
			}

			// get count
			int count = 0;
			if(WeightedGroupType.Smallest == this.groupType)
			{
				count = int.MaxValue;
				for(int i = 0; i < groups.Count; i++)
				{
					if(groups[i].Count < count)
					{
						count = groups[i].Count;
					}
				}
			}
			else if(WeightedGroupType.Largest == this.groupType)
			{
				for(int i = 0; i < groups.Count; i++)
				{
					if(count < groups[i].Count)
					{
						count = groups[i].Count;
					}
				}
			}

			List<Combatant> usedGroup = null;
			if(DistanceType.Nearest == this.distanceType)
			{
				float tmpDistance = Mathf.Infinity;
				for(int i = 0; i < groups.Count; i++)
				{
					if(groups[i].Count == count)
					{
						float groupDistance = this.useGridDistance &&
							ORK.Battle.Grid != null &&
							user.Grid.Cell != null ?
								DistanceHelper.GetNearestGrid(user, groups[i],
									this.blockDiagonalDistance1, this.ignoreSizeCells) :
								DistanceHelper.GetNearest(user, groups[i], this.ignoreHeightDistance,
									this.ignComRad, this.horizontalPlane);

						if(groupDistance < tmpDistance)
						{
							tmpDistance = groupDistance;
							usedGroup = groups[i];
						}
					}
				}
			}
			else if(DistanceType.NearestAverage == this.distanceType)
			{
				float tmpDistance = Mathf.Infinity;
				for(int i = 0; i < groups.Count; i++)
				{
					if(groups[i].Count == count)
					{
						float groupDistance = this.useGridDistance &&
							ORK.Battle.Grid != null &&
							user.Grid.Cell != null ?
								DistanceHelper.GetAverageGrid(user, groups[i],
									this.blockDiagonalDistance1, this.ignoreSizeCells) :
								DistanceHelper.GetAverage(user, groups[i], this.ignoreHeightDistance,
									this.ignComRad, this.horizontalPlane);

						if(groupDistance < tmpDistance)
						{
							tmpDistance = groupDistance;
							usedGroup = groups[i];
						}
					}
				}
			}
			else if(DistanceType.Farthest == this.distanceType)
			{
				float tmpDistance = 0;
				for(int i = 0; i < groups.Count; i++)
				{
					if(groups[i].Count == count)
					{
						float groupDistance = this.useGridDistance &&
							ORK.Battle.Grid != null &&
							user.Grid.Cell != null ?
								DistanceHelper.GetFarthestGrid(user, groups[i],
									this.blockDiagonalDistance1, this.ignoreSizeCells) :
								DistanceHelper.GetFarthest(user, groups[i], this.ignoreHeightDistance,
									this.ignComRad, this.horizontalPlane);

						if(tmpDistance < groupDistance)
						{
							tmpDistance = groupDistance;
							usedGroup = groups[i];
						}
					}
				}
			}
			else if(DistanceType.FarthestAverage == this.distanceType)
			{
				float tmpDistance = 0;
				for(int i = 0; i < groups.Count; i++)
				{
					if(groups[i].Count == count)
					{
						float groupDistance = this.useGridDistance &&
							ORK.Battle.Grid != null &&
							user.Grid.Cell != null ?
								DistanceHelper.GetAverageGrid(user, groups[i],
									this.blockDiagonalDistance1, this.ignoreSizeCells) :
								DistanceHelper.GetAverage(user, groups[i], this.ignoreHeightDistance,
									this.ignComRad, this.horizontalPlane);

						if(tmpDistance < groupDistance)
						{
							tmpDistance = groupDistance;
							usedGroup = groups[i];
						}
					}
				}
			}
			else if(DistanceType.All == this.distanceType)
			{
				for(int i = 0; i < groups.Count; i++)
				{
					if(groups[i].Count == count)
					{
						for(int j = 0; j < groups[i].Count; j++)
						{
							if(!foundTargets.Contains(groups[i][j]))
							{
								foundTargets.Add(groups[i][j]);
							}
						}
					}
				}
			}

			if(usedGroup != null)
			{
				for(int i = 0; i < usedGroup.Count; i++)
				{
					if(!foundTargets.Contains(usedGroup[i]))
					{
						foundTargets.Add(usedGroup[i]);
					}
				}
			}
		}

		public List<Combatant> GetWeightedGroup(BattleAICall call, List<Combatant> combatants)
		{
			List<Combatant> group = new List<Combatant>();

			if(combatants.Count > 0)
			{
				group.Add(combatants[0]);
				combatants.RemoveAt(0);

				for(int i = 0; i < combatants.Count; i++)
				{
					for(int j = 0; j < group.Count; j++)
					{
						if(group[j].Object.DistanceTo(combatants[i], this.ignoreHeightDistance,
								this.ignComRad, this.horizontalPlane) <=
							this.distance.GetValue(call, group[j], combatants[i]))
						{
							group.Add(combatants[i]);
							combatants.RemoveAt(i--);
							i = -1;
							break;
						}
					}
				}
			}

			return group;
		}

		public List<Combatant> GetWeightedGroupGrid(BattleAICall call, List<Combatant> combatants)
		{
			List<Combatant> group = new List<Combatant>();

			if(combatants.Count > 0)
			{
				group.Add(combatants[0]);
				combatants.RemoveAt(0);

				for(int i = 0; i < combatants.Count; i++)
				{
					for(int j = 0; j < group.Count; j++)
					{
						if(this.ignoreSizeCells ?
							(group[j].Grid.Cell.CubeCoord.Distance(
									combatants[i].Grid.Cell.CubeCoord, this.blockDiagonalDistance1) <=
								this.distance.GetValue(call, group[j], combatants[i])) :
							group[j].Grid.CheckDistance(combatants[i], this.blockDiagonalDistance1,
								0, (int)this.distance.GetValue(call, group[j], combatants[i]),
								ValueCheckType.RangeInclusive, null))
						{
							group.Add(combatants[i]);
							combatants.RemoveAt(i);
							i = -1;
							break;
						}
					}
				}
			}

			return group;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.distance.GetInfoText();
		}
	}

	[ORKEditorHelp("Check Height Differences", "Checks if a combatant is above or below the user.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckHeightDifferencesStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// height check
		[ORKEditorInfo(separator=true)]
		public HeightDifferenceCheck heightCheck = new HeightDifferenceCheck();

		public CheckHeightDifferencesStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;

			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call.user,
				BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.heightCheck.Check(user, list[i]))
					{
						any = true;
						if(!this.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.heightCheck.GetInfoText();
		}
	}
}
