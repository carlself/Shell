﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Clear Found Targets", "All found targets will be removed.", "")]
	[ORKNodeInfo("Target")]
	public class ClearFoundTargetsStep : BaseAIStep
	{
		public ClearFoundTargetsStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			call.foundTargets.Clear();
			currentStep = this.next;
			return null;
		}
	}

	[ORKEditorHelp("Check Target Count", "Checks the number of found targets.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Doesn't influence the target list.", "")]
	[ORKNodeInfo("Target", "Check")]
	public class CheckTargetCountStep : BaseAICheckStep
	{
		public AIValueCheck check = new AIValueCheck();

		public CheckTargetCountStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeAIFloat(data, "check", "value");
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(this.check.Check(call.foundTargets.Count, call, call.user, call.user))
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}
	}

	[ORKEditorHelp("Use Last Targets", "Adds the last targets of the user (or other combatants) to the found targets list.", "")]
	[ORKNodeInfo("Target")]
	public class UseLastTargetsStep : BaseAIStep
	{
		[ORKEditorHelp("Target Origin", "Select which combatant's last targets will be used:\n" +
			"- User: The user of this battle AI.\n" +
			"- Leader: The leader of the user's group.\n" +
			"- Group: Members of the user's battle group.\n" +
			"- Allies: The allies of the user.\n" +
			"- Enemies: The enemies of the user.\n" +
			"- Found Targets: The already found targets.", "")]
		public BattleAITargetOrigin targetOrigin = BattleAITargetOrigin.User;

		public UseLastTargetsStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(BattleAITargetOrigin.User == this.targetOrigin)
			{
				this.Add(call.user.Battle.LastTargets, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Leader == this.targetOrigin)
			{
				this.Add(call.user.Group.Leader.Battle.LastTargets, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Group == this.targetOrigin)
			{
				List<Combatant> group = call.user.Group.GetBattle();
				for(int i = 0; i < group.Count; i++)
				{
					this.Add(group[i].Battle.LastTargets, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Allies == this.targetOrigin)
			{
				for(int i = 0; i < call.allies.Count; i++)
				{
					this.Add(call.allies[i].Battle.LastTargets, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Enemies == this.targetOrigin)
			{
				for(int i = 0; i < call.enemies.Count; i++)
				{
					this.Add(call.enemies[i].Battle.LastTargets, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.FoundTargets == this.targetOrigin)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				for(int i = 0; i < tmp.Count; i++)
				{
					this.Add(tmp[i].Battle.LastTargets, call.foundTargets);
				}
			}

			currentStep = this.next;
			return null;
		}

		private void Add(List<Combatant> targets, List<Combatant> foundTargets)
		{
			if(targets != null)
			{
				for(int i = 0; i < targets.Count; i++)
				{
					if(targets[i] != null &&
						!foundTargets.Contains(targets[i]))
					{
						foundTargets.Add(targets[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetOrigin.ToString();
		}
	}

	[ORKEditorHelp("Use Attacked By", "Adds the combatants that attacked the user (or other combatants) to the found targets list.", "")]
	[ORKNodeInfo("Target")]
	public class UseAttackedByStep : BaseAIStep
	{
		[ORKEditorHelp("Target Origin", "Select which combatant's attacked by list will be used:\n" +
			"- User: The user of this battle AI.\n" +
			"- Leader: The leader of the user's group.\n" +
			"- Group: Members of the user's battle group.\n" +
			"- Allies: The allies of the user.\n" +
			"- Enemies: The enemies of the user.\n" +
			"- Found Targets: The already found targets.", "")]
		public BattleAITargetOrigin targetOrigin = BattleAITargetOrigin.User;

		public UseAttackedByStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(BattleAITargetOrigin.User == this.targetOrigin)
			{
				this.Add(call.user.Battle.AttackedBy, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Leader == this.targetOrigin)
			{
				this.Add(call.user.Group.Leader.Battle.AttackedBy, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Group == this.targetOrigin)
			{
				List<Combatant> group = call.user.Group.GetBattle();
				for(int i = 0; i < group.Count; i++)
				{
					this.Add(group[i].Battle.AttackedBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Allies == this.targetOrigin)
			{
				for(int i = 0; i < call.allies.Count; i++)
				{
					this.Add(call.allies[i].Battle.AttackedBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Enemies == this.targetOrigin)
			{
				for(int i = 0; i < call.enemies.Count; i++)
				{
					this.Add(call.enemies[i].Battle.AttackedBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.FoundTargets == this.targetOrigin)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				for(int i = 0; i < tmp.Count; i++)
				{
					this.Add(tmp[i].Battle.AttackedBy, call.foundTargets);
				}
			}

			currentStep = this.next;
			return null;
		}

		private void Add(List<Combatant> targets, List<Combatant> foundTargets)
		{
			if(targets != null)
			{
				for(int i = 0; i < targets.Count; i++)
				{
					if(targets[i] != null &&
						!foundTargets.Contains(targets[i]))
					{
						foundTargets.Add(targets[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetOrigin.ToString();
		}
	}

	[ORKEditorHelp("Use Killed By", "Adds the combatant that killed the user to the found targets list.\n" +
		"This is only available if the combatant was previously killed by someone in battle.", "")]
	[ORKNodeInfo("Target")]
	public class UseKilledByStep : BaseAIStep
	{
		[ORKEditorHelp("Target Origin", "Select which combatant's attacked by list will be used:\n" +
			"- User: The user of this battle AI.\n" +
			"- Leader: The leader of the user's group.\n" +
			"- Group: Members of the user's battle group.\n" +
			"- Allies: The allies of the user.\n" +
			"- Enemies: The enemies of the user.\n" +
			"- Found Targets: The already found targets.", "")]
		public BattleAITargetOrigin targetOrigin = BattleAITargetOrigin.User;

		public UseKilledByStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(BattleAITargetOrigin.User == this.targetOrigin)
			{
				this.Add(call.user.Battle.KilledBy, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Leader == this.targetOrigin)
			{
				this.Add(call.user.Group.Leader.Battle.KilledBy, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Group == this.targetOrigin)
			{
				List<Combatant> group = call.user.Group.GetBattle();
				for(int i = 0; i < group.Count; i++)
				{
					this.Add(group[i].Battle.KilledBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Allies == this.targetOrigin)
			{
				for(int i = 0; i < call.allies.Count; i++)
				{
					this.Add(call.allies[i].Battle.KilledBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Enemies == this.targetOrigin)
			{
				for(int i = 0; i < call.enemies.Count; i++)
				{
					this.Add(call.enemies[i].Battle.KilledBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.FoundTargets == this.targetOrigin)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				for(int i = 0; i < tmp.Count; i++)
				{
					this.Add(tmp[i].Battle.KilledBy, call.foundTargets);
				}
			}

			currentStep = this.next;
			return null;
		}

		private void Add(Combatant target, List<Combatant> foundTargets)
		{
			if(target != null &&
				!foundTargets.Contains(target))
			{
				foundTargets.Add(target);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetOrigin.ToString();
		}
	}

	[ORKEditorHelp("Use Combatant", "Adds the combatant's group/individual target, last target, " +
		"attacked by target, killed by target or linked combatant to the found targets list.", "")]
	[ORKNodeInfo("Target")]
	public class UseCombatantStep : BaseAIStep
	{
		[ORKEditorHelp("Target Origin", "Select which combatant's attacked by list will be used:\n" +
			"- User: The user of this battle AI.\n" +
			"- Leader: The leader of the user's group.\n" +
			"- Group: Members of the user's battle group.\n" +
			"- Allies: The allies of the user.\n" +
			"- Enemies: The enemies of the user.\n" +
			"- Found Targets: The already found targets.", "")]
		public BattleAITargetOrigin targetOrigin = BattleAITargetOrigin.User;

		[ORKEditorInfo(separator=true)]
		public SelectCombatantSettings selectCombatant = new SelectCombatantSettings();

		public UseCombatantStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(BattleAITargetOrigin.User == this.targetOrigin)
			{
				this.selectCombatant.Get(call.user, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Leader == this.targetOrigin)
			{
				this.selectCombatant.Get(call.user.Group.Leader, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Group == this.targetOrigin)
			{
				List<Combatant> group = call.user.Group.GetBattle();
				for(int i = 0; i < group.Count; i++)
				{
					this.selectCombatant.Get(group[i], call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Allies == this.targetOrigin)
			{
				for(int i = 0; i < call.allies.Count; i++)
				{
					this.selectCombatant.Get(call.allies[i], call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Enemies == this.targetOrigin)
			{
				for(int i = 0; i < call.enemies.Count; i++)
				{
					this.selectCombatant.Get(call.enemies[i], call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.FoundTargets == this.targetOrigin)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				for(int i = 0; i < tmp.Count; i++)
				{
					this.selectCombatant.Get(tmp[i], call.foundTargets);
				}
			}

			currentStep = this.next;
			return null;
		}

		private void Add(Combatant user, List<Combatant> foundTargets)
		{
			if(user != null)
			{
				this.selectCombatant.Get(user, foundTargets);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetOrigin.ToString() + ": " + this.selectCombatant.GetInfoText();
		}
	}

	[ORKEditorHelp("Store Targets", "Store the currently found targets list.\n" +
		"Targets are stored using a 'target key' to allow storing different target lists.\n" +
		"You can store targets for the group or the user (individual combatant), " +
		"storing targets for the group allow all group members to access the targets.", "")]
	[ORKNodeInfo("Target")]
	public class StoreTargetsStep : BaseAIStep
	{
		[ORKEditorHelp("Group Target", "Store the targets as group targets.\n" +
			"All members of the group have access to the group targets.\n" +
			"If disabled, the targets are stored for the user.", "")]
		public bool useGroup = false;

		[ORKEditorHelp("Change Type", "Select how the found targets will change the stored targets:\n" +
			"- Add: Adds them to the stored targets.\n" +
			"- Remove: Removes them from the stored targets.\n" +
			"- Clear: Removes all stored targets of the defined key.\n" +
			"- Set: Sets them as the stored targets, overriding previously stored targets.", "")]
		public ListChangeType changeType = ListChangeType.Set;


		// key
		[ORKEditorInfo(separator=true, labelText="Target Key")]
		public AIString targetKey = new AIString();

		public StoreTargetsStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(this.useGroup)
			{
				call.user.Group.SelectedTargets.ChangeStoredTargets(
					this.targetKey.GetValue(call), call.foundTargets, this.changeType);
			}
			else
			{
				call.user.SelectedTargets.ChangeStoredTargets(
					this.targetKey.GetValue(call), call.foundTargets, this.changeType);
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useGroup ? "Group: " : "User: ") + this.changeType +
				" " + this.targetKey.GetInfoText();
		}
	}

	[ORKEditorHelp("Load Targets", "Loads previously stored targets into the found targets list.", "")]
	[ORKNodeInfo("Target")]
	public class LoadTargetsStep : BaseAIStep
	{
		[ORKEditorHelp("Group Target", "Load the targets from group targets.\n" +
			"All members of the group have access to the group targets.\n" +
			"If disabled, the targets are loaded from the user.", "")]
		public bool useGroup = false;

		[ORKEditorHelp("Change Type", "Select how the loaded targets will change the found targets:\n" +
			"- Add: Adds them to the found targets.\n" +
			"- Remove: Removes them from the found targets.\n" +
			"- Clear: Removes all found targets.\n" +
			"- Set: Sets them as the found targets, overriding previously found targets.", "")]
		public ListChangeType changeType = ListChangeType.Set;


		// key
		[ORKEditorInfo(separator=true, labelText="Target Key")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, elseCheckGroup=true, endCheckGroup=true)]
		public AIString targetKey = new AIString();

		public LoadTargetsStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				call.foundTargets.Clear();
			}
			else
			{
				if(ListChangeType.Set == this.changeType)
				{
					call.foundTargets.Clear();
				}

				List<Combatant> targets = this.useGroup ?
					call.user.Group.SelectedTargets.GetStoredTargets(this.targetKey.GetValue(call)) :
					call.user.SelectedTargets.GetStoredTargets(this.targetKey.GetValue(call));

				if(targets != null)
				{
					if(ListChangeType.Set == this.changeType)
					{
						call.foundTargets.AddRange(targets);
					}
					else
					{
						if(ListChangeType.Add == this.changeType)
						{
							for(int i = 0; i < targets.Count; i++)
							{
								if(targets[i] != null &&
									!call.foundTargets.Contains(targets[i]))
								{
									call.foundTargets.Add(targets[i]);
								}
							}
						}
						else if(ListChangeType.Remove == this.changeType)
						{
							for(int i = 0; i < targets.Count; i++)
							{
								if(targets[i] != null &&
									call.foundTargets.Contains(targets[i]))
								{
									call.foundTargets.Remove(targets[i]);
								}
							}
						}
					}
				}
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useGroup ? "Group: " : "User: ") + this.changeType +
				(ListChangeType.Clear == this.changeType ? "" : " " + this.targetKey.GetInfoText());
		}
	}

	[ORKEditorHelp("Has Stored Targets", "Checks if stored targets of a defined key exist, " +
		"optionally also checking for status requirements (e.g. not being dead).\n" +
		"Can also remove combatants from the stored targets that don't match the requirements.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Target", "Check")]
	public class HasStoredTargetsStep : BaseAICheckStep
	{
		[ORKEditorHelp("Group Target", "Load the targets from group targets.\n" +
			"All members of the group have access to the group targets.\n" +
			"If disabled, the targets are loaded from the user.", "")]
		public bool useGroup = false;


		// key
		[ORKEditorInfo(separator=true, labelText="Target Key")]
		public AIString targetKey = new AIString();


		// status
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed needed = Needed.All;

		[ORKEditorHelp("Remove Not Matching", "Remove combatants from the stored targets that don't match the status requirements.", "")]
		public bool removeNotMatching = false;

		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "",
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, noRemoveCount=0,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		public StatusRequirement[] req = new StatusRequirement[0];

		public HasStoredTargetsStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(this.useGroup ?
				call.user.Group.SelectedTargets.HasStoredTargets(
					this.targetKey.GetValue(call), this.needed, this.req, this.removeNotMatching) :
				call.user.SelectedTargets.HasStoredTargets(
					this.targetKey.GetValue(call), this.needed, this.req, this.removeNotMatching))
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useGroup ? "Group: " : "User: ") + this.targetKey.GetInfoText() +
				(this.removeNotMatching ? ", remove not matching" : "");
		}
	}

	[ORKEditorHelp("Change Selected Target", "Changes the group/individual target of the user using the currently found targets.", "")]
	[ORKNodeInfo("Target")]
	public class ChangeSelectedTargetStep : BaseAIStep
	{
		[ORKEditorInfo(labelText="Index", label=new string[] {
			"The index of the group/individual target that will be changed.",
			"No target will be changed if this exceeds the defined group/individual target settings."
		})]
		public AIFloat index = new AIFloat();

		[ORKEditorHelp("Group/Individual Target", "If enabled, the combatant's group target will be changed.\n" +
			"If disabled, the combatant's individual target will be changed.", "")]
		[ORKEditorInfo(separator=true)]
		public bool changeGroupTarget = true;

		[ORKEditorHelp("Use Requirements", "Use the target requirements of the group/individual target settings.", "")]
		public bool useRequirements = true;

		[ORKEditorHelp("Remove Target", "Removes the currently set target combatant.\n" +
			"There'll be no target currently set on this target index.", "")]
		public bool remove = false;

		public ChangeSelectedTargetStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			int targetIndex = (int)this.index.GetValue(call, call.user, call.user);
			TargetSelection[] settings = this.changeGroupTarget ?
				ORK.Battle.TargetSettings.groupTargetSelection :
				ORK.Battle.TargetSettings.individualTargetSelection;

			if(targetIndex >= 0 &&
				targetIndex < settings.Length)
			{
				for(int i = 0; i < call.foundTargets.Count; i++)
				{
					if(call.foundTargets[i] != null &&
						(!this.useRequirements ||
							settings[targetIndex].CheckTargetRequirements(call.foundTargets[i])))
					{
						if(this.changeGroupTarget)
						{
							call.user.Group.SelectedTargets[targetIndex] = call.foundTargets[i];
						}
						else
						{
							call.user.SelectedTargets[targetIndex] = call.foundTargets[i];
						}
						break;
					}
				}
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.changeGroupTarget ? "Group " : "Individual ") +
				this.index.GetInfoText() + (this.remove ? ": Remove" : "");
		}
	}
}
