﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AISelectedDataOrigin : BaseData
	{
		// variable settings
		[ORKEditorHelp("Data Origin", "Select the origin of the selected data:\n" +
			"- Local: Local data is only used in a running event and don't interfere with global data. " +
			"The data will be gone once the event ends.\n" +
			"- Global: Global data is persistent and available everywhere, everytime.\n" +
			"- Object: Object data is bound to objects in the scene by an object ID (using an 'Object Variables' component).\n" +
			"- Object ID: Object data is bound to objects in the scene by an object ID (using a defined object ID).\n\n" +
			"Selected data is not saved in save games.", "")]
		public SelectedDataOrigin origin = SelectedDataOrigin.Local;


		// object
		[ORKEditorHelp("Use Found Targets", "Change the object variables on the targets found by previous steps.\n" +
			"If disabled, you need to define the target that will be changed.", "")]
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("origin", SelectedDataOrigin.Object)]
		public bool onFound = false;

		[ORKEditorHelp("Target", "Select which combatant's or combatant group's object variables will be changed:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("onFound", false, endCheckGroup=true)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, endGroups=2, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;



		// object ID
		[ORKEditorInfo(labelText="Object ID", indent=true)]
		[ORKEditorLayout("origin", SelectedDataOrigin.ObjectID, endCheckGroup=true, autoInit=true)]
		public AIString objectID;

		public AISelectedDataOrigin()
		{

		}

		public string GetInfoText()
		{
			return this.origin.ToString();
		}


		/*
		============================================================================
		Handler functions
		============================================================================
		*/
		public List<SelectedDataHandler> Get(BattleAICall call)
		{
			List<SelectedDataHandler> handlers = new List<SelectedDataHandler>();
			this.Get(call, handlers);
			return handlers;
		}

		public void Get(BattleAICall call, List<SelectedDataHandler> handlers)
		{
			if(SelectedDataOrigin.Local == this.origin)
			{
				if(!handlers.Contains(call.SelectedData))
				{
					handlers.Add(call.SelectedData);
				}
			}
			else if(SelectedDataOrigin.Global == this.origin)
			{
				if(!handlers.Contains(ORK.Game.SelectedData))
				{
					handlers.Add(ORK.Game.SelectedData);
				}
			}
			else if(SelectedDataOrigin.Object == this.origin)
			{
				List<Combatant> list = this.onFound ?
					call.foundTargets :
					BattleAI.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call);
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						!handlers.Contains(list[i].SelectedData))
					{
						handlers.Add(list[i].SelectedData);
					}
				}
			}
			else if(SelectedDataOrigin.ObjectID == this.origin)
			{
				SelectedDataHandler handler = ORK.Game.Scene.GetObjectSelectedData(this.objectID.GetValue(call));
				if(!handlers.Contains(handler))
				{
					handlers.Add(handler);
				}
			}
		}

		public SelectedDataHandler GetFirst(BattleAICall call)
		{
			if(SelectedDataOrigin.Local == this.origin)
			{
				return call.SelectedData;
			}
			else if(SelectedDataOrigin.Global == this.origin)
			{
				return ORK.Game.SelectedData;
			}
			else if(SelectedDataOrigin.Object == this.origin)
			{
				List<Combatant> list = this.onFound ?
					call.foundTargets :
					BattleAI.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call);
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						return list[i].SelectedData;
					}
				}
			}
			else if(SelectedDataOrigin.ObjectID == this.origin)
			{
				return ORK.Game.Scene.GetObjectSelectedData(this.objectID.GetValue(call));
			}
			return null;
		}


		/*
		============================================================================
		Clear functions
		============================================================================
		*/
		public void Clear(BattleAICall call)
		{
			if(SelectedDataOrigin.Local == this.origin)
			{
				call.SelectedData.Clear();
			}
			else if(SelectedDataOrigin.Global == this.origin)
			{
				ORK.Game.SelectedData.Clear();
			}
			else if(SelectedDataOrigin.Object == this.origin)
			{
				List<Combatant> list = this.onFound ?
					call.foundTargets :
					BattleAI.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call);
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].HasSelectedData)
					{
						list[i].SelectedData.Clear();
					}
				}
			}
			else if(SelectedDataOrigin.ObjectID == this.origin)
			{
				string tmpID = this.objectID.GetValue(call);
				if(ORK.Game.Scene.ObjectSelectedDataExist(tmpID))
				{
					ORK.Game.Scene.GetObjectSelectedData(tmpID).Clear();
				}
			}
		}

		public void Clear(BattleAICall call, string selectedKey)
		{
			List<SelectedDataHandler> handlers = this.Get(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				if(handlers[i] != null)
				{
					handlers[i].Change(selectedKey, null, ListChangeType.Clear);
				}
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public int GetCount(BattleAICall call, string selectedKey)
		{
			int count = 0;
			List<SelectedDataHandler> handlers = this.Get(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				if(handlers[i] != null)
				{
					count += handlers[i].GetCount(selectedKey);
				}
			}
			return count;
		}

		public List<object> GetSelectedData(BattleAICall call, string selectedKey)
		{
			List<object> list = new List<object>();
			List<SelectedDataHandler> handlers = this.Get(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				if(handlers[i] != null)
				{
					List<object> tmpList = handlers[i].Get(selectedKey);
					if(tmpList != null)
					{
						list.AddRange(tmpList);
					}
				}
			}
			return list;
		}

		public void Change(BattleAICall call, string selectedKey, object data, ListChangeType changeType)
		{
			List<SelectedDataHandler> handlers = this.Get(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				if(handlers[i] != null)
				{
					handlers[i].Change(selectedKey, data, changeType);
				}
			}
		}
	}
}
