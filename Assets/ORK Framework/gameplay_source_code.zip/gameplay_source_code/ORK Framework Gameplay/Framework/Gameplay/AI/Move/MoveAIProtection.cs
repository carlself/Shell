﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class MoveAIProtection : BaseData
	{
		[ORKEditorHelp("Use Protection", "The protection settings are enabled.\n" +
			"The combatant will move between a target (enemy) and a member of its own group.\n" +
			"Protection can only be used when there is at least 1 additional member in the combatant's group.", "")]
		public bool enabled = false;

		[ORKEditorHelp("Stopped Look At Target", "Look at the target while the combatant is stopped.", "")]
		[ORKEditorLayout("enabled", true)]
		public bool stoppedLookAtTarget = false;


		// detection event
		[ORKEditorHelp("Detection Game Event", "Select a game event that will be started when the combatant detects a target and starts protecting members from it.\n" +
			"The combatant will be used as 'Event Object' actor, the detected target as 'Starting Object' actor.", "")]
		[ORKEditorInfo(separator=true)]
		public AssetSource<ORKGameEvent> detectionGameEvent = new AssetSource<ORKGameEvent>();

		[ORKEditorHelp("Wait", "Wait for the detection game event to finish before starting to protect members from it.", "")]
		[ORKEditorLayout("detectionGameEvent.HasAsset", true, endCheckGroup=true)]
		[ORKEditorInfo(indent=true)]
		public bool detectionWaitForEvent = false;


		// protection range
		[ORKEditorHelp("Use Protection Range", "The combatant will only protect within a range of its start position " +
			"(i.e. the position it has been spawned at).\n" +
			"When leaving the protection range, the combatant will return to its start position." +
			"If disabled, there is no limit to the protection range.", "")]
		[ORKEditorInfo("Protection Range", "Optionally only protect within a defined range of the combatant's start position.", "")]
		public bool useRange = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useRange", true, endCheckGroup=true, autoInit=true)]
		public RangeValue range;


		// protection distance
		[ORKEditorInfo("Stop Range", "The combatant will stay within the defined range to the target (or protected member).", "")]
		public RangeValue stopRange = new RangeValue(3, true, true, 0);

		[ORKEditorHelp("From Protected", "Stay within the defined range to the protected member instead of the target.", "")]
		[ORKEditorInfo(separator=true)]
		public bool stopRangeFromProtected = false;

		[ORKEditorHelp("Use Action Range", "The use range of a selected action is used when moving into range.\n" +
			"A combatant will only move into range when the used action is out of range to the target.\n" +
			"If the action doesn't have a use range, the stop range will be used.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool useActionStopRange = false;


		// target conditions
		[ORKEditorHelp("Conditions Needed", "Select if all or just one condition must be valid to protect a group member from the target.", "")]
		[ORKEditorInfo("Protection Conditions (Target)", "Optionally only use protection when defined conditions are valid (checking the detected target).", "",
			isEnumToolbar=true, toolbarWidth=75)]
		public Needed neededTarget = Needed.One;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Protection Condition", "Adds a protection condition to check the detected target.\n" +
			"You can use multiple conditions to determine if the combatant protects a group member from the target.", "",
			"Remove", "Removes this protection condition.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Protection Condition (Target)", "Protection conditions determine if the combatant protects a group member from the target.", ""
			})]
		public MoveCondition[] conditionTarget = new MoveCondition[0];


		// member conditions
		[ORKEditorHelp("Conditions Needed", "Select if all or just one condition must be valid to protect a group member.", "")]
		[ORKEditorInfo("Protection Conditions (Member)", "Optionally only protect a member of the combatant's group when defined conditions are valid (checking the group members).", "",
			isEnumToolbar=true, toolbarWidth=75)]
		public Needed neededMember = Needed.One;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorArray(false, "Add Protection Condition", "Adds a protection condition to check the group members.\n" +
			"You can use multiple conditions to determine if the combatant protects a group member.", "",
			"Remove", "Removes this protection condition.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Protection Condition", "Protection conditions determine if the combatant protects a group member.", ""
			})]
		public MoveCondition[] conditionMember = new MoveCondition[0];

		public MoveAIProtection()
		{

		}


		/*
		============================================================================
		Protection functions
		============================================================================
		*/
		public bool CheckProtectFrom(Combatant combatant, Combatant target)
		{
			if(this.enabled && combatant.IsAggressive)
			{
				if(this.conditionTarget != null && this.conditionTarget.Length > 0)
				{
					for(int i = 0; i < this.conditionTarget.Length; i++)
					{
						if(this.conditionTarget[i].IsValid(combatant, target))
						{
							if(Needed.One == this.neededTarget)
							{
								return true;
							}
						}
						else if(Needed.All == this.neededTarget)
						{
							return false;
						}
					}

					if(Needed.All == this.neededTarget)
					{
						return true;
					}
					else if(Needed.One == this.neededTarget)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public Combatant GetProtectedMember(MoveAIComponent moveAI)
		{
			List<Combatant> group = moveAI.Combatant.Group.GetBattle();
			if(group.Count > 1)
			{
				Combatant protect = null;
				float distance = Mathf.Infinity;
				for(int i = 0; i < group.Count; i++)
				{
					if(moveAI.Combatant != group[i] &&
						this.CheckProtectMember(moveAI.Combatant, group[i]))
					{
						float tmpDistance = moveAI.Combatant.Object.DistanceTo(group[i],
							true, false, moveAI.settings.horizontalPlane);
						if(tmpDistance < distance)
						{
							distance = tmpDistance;
							protect = group[i];
						}
					}
				}
				return protect;
			}
			return null;
		}

		public bool CheckProtectMember(Combatant combatant, Combatant member)
		{
			if(this.enabled && combatant.IsAggressive)
			{
				if(this.conditionMember != null && this.conditionMember.Length > 0)
				{
					for(int i = 0; i < this.conditionMember.Length; i++)
					{
						if(this.conditionMember[i].IsValid(combatant, member))
						{
							if(Needed.One == this.neededMember)
							{
								return true;
							}
						}
						else if(Needed.All == this.neededMember)
						{
							return false;
						}
					}

					if(Needed.All == this.neededMember)
					{
						return true;
					}
					else if(Needed.One == this.neededMember)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public bool IsInRange(Vector3 startPosition, Combatant combatant)
		{
			return !this.useRange ||
				this.range == null ||
				this.range.InRange(startPosition, combatant);
		}

		public bool IsOutOfRange(Vector3 startPosition, Combatant combatant)
		{
			return this.useRange &&
				this.range != null &&
				this.range.OutOfRange(startPosition, combatant);
		}

		public void Use(MoveAIComponent moveAI)
		{
			if(this.enabled)
			{
				Vector3 targetPosition = this.GetTargetPosition(moveAI);

				// reached position
				if(moveAI.ProtectStopRange.InRange(targetPosition, moveAI.Combatant, true, 0.1f))
				{
					moveAI.targetPosTimeout = -1;
					moveAI.Stop();
					return;
				}

				// out of range
				if(this.IsOutOfRange(moveAI.startPosition, moveAI.Combatant))
				{
					moveAI.targetLostTimeout = -1;
					moveAI.ClearTarget(false);

					moveAI.SetMode(MoveAIMode.Waypoint);
					moveAI.SetMovePosition(moveAI.startPosition);
					return;
				}
			}

			if(!moveAI.IsTargetLost())
			{
				moveAI.UpdateTargetPosition(true);
			}
		}


		/*
		============================================================================
		Target functions
		============================================================================
		*/
		public Vector3 GetTargetPosition(MoveAIComponent moveAI)
		{
			if(this.enabled &&
				moveAI.TargetCombatant != null &&
				moveAI.TargetCombatant.GameObject != null &&
				moveAI.ProtectedCombatant != null &&
				moveAI.ProtectedCombatant.GameObject != null)
			{
				if(this.stopRangeFromProtected &&
					(!this.useActionStopRange || !moveAI.HasActionRange))
				{
					return Vector3.MoveTowards(
						moveAI.ProtectedCombatant.GameObject.transform.position,
						moveAI.TargetCombatant.GameObject.transform.position,
						moveAI.ProtectStopRange.GetInRangeDistance(moveAI.ProtectedCombatant));
				}
				else
				{
					return Vector3.MoveTowards(
						moveAI.TargetCombatant.GameObject.transform.position,
						moveAI.ProtectedCombatant.GameObject.transform.position,
						moveAI.ProtectStopRange.GetInRangeDistance(moveAI.TargetCombatant));
				}
			}
			else
			{
				return moveAI.Combatant.GameObject.transform.position;
			}
		}
	}
}
