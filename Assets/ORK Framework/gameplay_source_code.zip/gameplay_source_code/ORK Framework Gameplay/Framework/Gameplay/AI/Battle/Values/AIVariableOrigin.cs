﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIVariableOrigin : BaseData
	{
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in the current run of a combatant's battle AI " +
			"and don't interfere with global variables. The variable will be gone once combatant's battle AI finished.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.\n" +
			"- Selected: Variables assigned to selected data.", "")]
		public VariableOrigin origin = VariableOrigin.Global;


		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID of the used object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;

		[ORKEditorHelp("Use Found Targets", "Change the object variables on the targets found by previous steps.\n" +
			"If disabled, you need to define the target that will be changed.", "")]
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true)]
		public bool onFound = false;

		[ORKEditorHelp("Target", "Select which combatant's or combatant group's object variables will be changed:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("onFound", false, endCheckGroup=true)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		// object ID
		[ORKEditorInfo(labelText="Object ID", label=new string[] {
			"Define the object ID of the object variables.",
			"If the object ID doesn't exist yet, it will be created."
		})]
		[ORKEditorLayout(autoInit=true, elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public AIString objectID;


		// selected data
		[ORKEditorLayout("origin", VariableOrigin.Selected, endCheckGroup=true, autoInit=true)]
		public AISelectedData selectedData;

		public AIVariableOrigin()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(VariableOrigin.Selected == this.origin &&
				data.Contains<DataObject>("selectedKey"))
			{
				this.selectedData = new AISelectedData();
				this.selectedData.SetData(data);
			}
			if(VariableOrigin.Object == this.origin &&
				!this.useObject &&
				data.Contains<string>("objectID"))
			{
				string tmp = "";
				data.Get("objectID", ref tmp);
				this.objectID = new AIString(tmp);
			}
		}

		public string GetInfoText()
		{
			if(VariableOrigin.Object == this.origin)
			{
				return this.origin.ToString() + ": " +
					(this.useObject ?
						this.onFound ? "Found Targets" : this.targetType.ToString() :
						this.objectID.GetInfoText());
			}
			else if(VariableOrigin.Selected == this.origin)
			{
				return this.origin.ToString() + ": " + this.selectedData.GetInfoText();
			}
			else
			{
				return this.origin.ToString();
			}
		}


		/*
		============================================================================
		Handler functions
		============================================================================
		*/
		public bool IsSingle
		{
			get
			{
				return VariableOrigin.Local == this.origin ||
					VariableOrigin.Global == this.origin ||
					(VariableOrigin.Object == this.origin && !this.useObject);
			}
		}

		public VariableHandler GetSingle(BattleAICall call)
		{
			if(VariableOrigin.Local == this.origin)
			{
				return call.Variables;
			}
			else if(VariableOrigin.Global == this.origin)
			{
				return ORK.Game.Variables;
			}
			else if(VariableOrigin.Object == this.origin)
			{
				if(!this.useObject)
				{
					return ORK.Game.Scene.GetObjectVariables(this.objectID.GetValue(call));
				}
			}
			return null;
		}

		public List<VariableHandler> GetMulti(BattleAICall call)
		{
			if(VariableOrigin.Object == this.origin)
			{
				if(this.useObject)
				{
					List<VariableHandler> handlers = new List<VariableHandler>();
					List<Combatant> list = this.onFound ?
						call.foundTargets :
						BattleAI.GetTargetList(this.targetType,
							this.targetExcludeSelf, this.targetExcludeFoundTargets,
							call);
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							handlers.Add(list[i].Variables);
						}
					}
					return handlers;
				}
			}
			else if(VariableOrigin.Selected == this.origin)
			{
				List<VariableHandler> handlers = new List<VariableHandler>();
				List<SelectedDataHandler> dataList = this.selectedData.Get(call);
				for(int i = 0; i < dataList.Count; i++)
				{
					if(dataList[i] != null)
					{
						SelectedDataHelper.GetVariableHandlers(
							dataList[i].Get(this.selectedData.selectedKey.GetValue(call)),
							ref handlers);
					}
				}
				return handlers;
			}
			return null;
		}

		public VariableHandler GetFirst(BattleAICall call)
		{
			if(VariableOrigin.Local == this.origin)
			{
				return call.Variables;
			}
			else if(VariableOrigin.Global == this.origin)
			{
				return ORK.Game.Variables;
			}
			else if(VariableOrigin.Object == this.origin)
			{
				if(this.useObject)
				{
					List<Combatant> list = this.onFound ?
						call.foundTargets :
						BattleAI.GetTargetList(this.targetType,
							this.targetExcludeSelf, this.targetExcludeFoundTargets,
							call);
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							return list[i].Variables;
						}
					}
				}
				else
				{
					return ORK.Game.Scene.GetObjectVariables(this.objectID.GetValue(call));
				}
			}
			else if(VariableOrigin.Selected == this.origin)
			{
				List<SelectedDataHandler> dataList = this.selectedData.Get(call);
				for(int i = 0; i < dataList.Count; i++)
				{
					if(dataList[i] != null)
					{
						VariableHandler handler = SelectedDataHelper.GetFirstVariableHandler(
							dataList[i].Get(this.selectedData.selectedKey.GetValue(call)));
						if(handler != null)
						{
							return handler;
						}
					}
				}
			}
			return null;
		}


		/*
		============================================================================
		Change functions
		============================================================================
		*/
		public void ChangeFloat(BattleAICall call, string key, float value, FormulaOperator floatOperator)
		{
			if(VariableOrigin.Local == this.origin)
			{
				call.Variables.ChangeFloat(key, value, floatOperator);
			}
			else if(VariableOrigin.Global == this.origin)
			{
				ORK.Game.Variables.ChangeFloat(key, value, floatOperator);
			}
			else if(VariableOrigin.Object == this.origin)
			{
				if(this.useObject)
				{
					List<Combatant> list = this.onFound ?
						call.foundTargets :
						BattleAI.GetTargetList(this.targetType,
							this.targetExcludeSelf, this.targetExcludeFoundTargets,
							call);
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							list[i].Variables.ChangeFloat(key, value, floatOperator);
						}
					}
				}
				else
				{
					ORK.Game.Scene.GetObjectVariables(this.objectID.GetValue(call)).ChangeFloat(key, value, floatOperator);
				}
			}
			else if(VariableOrigin.Selected == this.origin)
			{
				List<VariableHandler> handlers = new List<VariableHandler>();
				List<SelectedDataHandler> dataList = this.selectedData.Get(call);
				for(int i = 0; i < dataList.Count; i++)
				{
					if(dataList[i] != null)
					{
						SelectedDataHelper.GetVariableHandlers(
							dataList[i].Get(this.selectedData.selectedKey.GetValue(call)),
							ref handlers);
					}
				}
				for(int i = 0; i < handlers.Count; i++)
				{
					handlers[i].ChangeFloat(key, value, floatOperator);
				}
			}
		}
	}
}
