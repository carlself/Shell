
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class BattleAISelection : BaseData
	{
		[ORKEditorHelp("Battle AI", "Select the battle AI that will be used.\n" +
			"If no action is found in this battle AI, the next battle AI will be used.\n" +
			"If no battle AI finds an action, the base attack will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleAI)]
		public int battleAI = 0;


		// chance
		[ORKEditorInfo("Chance (%)", "The chance this battle AI will be used.", "",
			endFoldout=true)]
		public FloatValue chanceValue = new FloatValue(100);


		// requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions.", "")]
		[ORKEditorInfo("Requirements", "Using this battle AI can depend on status requirements and " +
			"game variable conditions.\n" +
			"The combatant using the battle AI is used for status checks and object game variables.", "")]
		public bool useRequirements = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useRequirements", true, endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement requirement;

		public BattleAISelection()
		{

		}

		/*
		============================================================================
		Action handling functions
		============================================================================
		*/
		public bool CanUse(Combatant user)
		{
			return ORK.GameSettings.CheckRandom(this.chanceValue.GetValue(user, user)) &&
				(!this.useRequirements || this.requirement.Check(user));
		}

		public BaseAction GetAction(BattleAICall call)
		{
			if(this.battleAI >= 0 &&
				this.battleAI < ORK.BattleAIs.Count &&
				this.CanUse(call.user))
			{
				return ORK.BattleAIs.Get(this.battleAI).GetAction(call);
			}
			return null;
		}
	}
}
