﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class BattleAICall
	{
		public Combatant user;

		public List<Combatant> allies;

		public List<Combatant> enemies;

		public List<Combatant> foundTargets = new List<Combatant>();

		private VariableHandler localVariables;

		private SelectedDataHandler selectedData;

		public bool checkTime = true;

		public bool checkUseCosts = true;

		public BattleAICall(Combatant user, List<Combatant> allies, List<Combatant> enemies,
			bool checkTime, bool checkUseCosts)
		{
			this.user = user;
			this.allies = allies;
			this.enemies = enemies;
			this.checkTime = checkTime;
			this.checkUseCosts = checkUseCosts;
		}

		public VariableHandler Variables
		{
			get
			{
				if(this.localVariables == null)
				{
					this.localVariables = new VariableHandler(false);
				}
				return this.localVariables;
			}
		}

		public SelectedDataHandler SelectedData
		{
			get
			{
				if(this.selectedData == null)
				{
					this.selectedData = new SelectedDataHandler();
				}
				return this.selectedData;
			}
		}
	}
}
